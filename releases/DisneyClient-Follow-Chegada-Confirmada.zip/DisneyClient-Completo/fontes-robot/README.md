# Robot com chegada confirmada e relogio por ponto

A fonte canonica e fontes-autoplay/RoutePlayer.as. RoutePlayerNative.as e gerada
pelo build. RouteFeedback le posicao/velocidade e confirma visitas; RouteInputPacer
limita os comandos a 33ms. NativeMotion nao reposiciona o jogador.

Veja ../CHEGADA-CONFIRMADA-LEIA-ME.txt e ../PROVA-DE-CHEGADA.json.
Os relatorios anteriores documentam builds historicos.

Build: python fontes-robot/build.py --ffdec /caminho/ffdec
Testes: RUFFLE_DIR=/caminho/ruffle node fontes-robot/run_tests.cjs
Requer Java 21, FFDec 26.4.0, Node/Playwright, Chromium e Ruffle 0.7.1.
