package disney {
 import flash.display.MovieClip;import flash.events.KeyboardEvent;import flash.geom.Point;import flash.text.TextField;import flash.utils.ByteArray;import flash.external.ExternalInterface;
 public class RgbMouseTests {
  private static var count:int=0;
  private static function check(ok:Boolean,text:String):void{if(!ok)throw new Error(text);count++;}
  private static function walk(x:int,l:Boolean,r:Boolean,j:Boolean,delay:int):Array{return [{x:x,y:1102,vx:345,vy:65036,mr:r,ml:l,jump:j,frame:2},"walk",delay];}
  public static function run(display:MovieClip):void{try{
   var root:MovieClip=new MovieClip();display.addChild(root);root.stage.focus=root.stage;
   var writes:int=0;var syncs:int=0;var keys:Array=[];
   var body:Object={velocity:{vx:7,vy:-3},setPosition:function(p:Point,a:Number):Boolean{writes++;throw new Error("forbidden route reposition");}};
   var player:Object={x:30,y:330.6,body:body,clip:true,dead:false,left:false,right:false,down:false,side:true,jump:function(...args):void{},crouch:function(...args):void{},stand:function(...args):void{}};
   var map:Object={number:{value:123},container:{mirror:false}};
   root.Keys={player:"mouse",player_physics:"body",player_clip:"clip",is_dead:"dead",player_moving_left:"left",player_moving_right:"right",jump:"jump",is_down:"down",crouch:"crouch",crouch2:"stand",static_side:"side",physics_state:"velocity",physics_state_vx:"vx",physics_state_vy:"vy",bot_set_position:"setPosition",b2vec2:"Point",app_domain:{applicationDomain:{getDefinition:function(n:String):Class{throw new Error("route must not create teleport vector");}}},map_class:{current:map,width:800},map_instance:"current",bot_map_code_object:"number",bot_map_code_value:"value",obj_container:"container",bot_reverse:"mirror",bot_map_width:"width",move_class:{free:true},move_free:"free",timer_class:{locked:false},timer_prop:"locked",packet_handler_class:{receive:function(bytes:ByteArray):void{syncs++;throw new Error("forbidden initial teleport packet");}},packet_handler:"receive"};
   root.tfm={mouse:player};root.Interface={status_field:new TextField()};root.auto_play=true;
   root.stage.addEventListener(KeyboardEvent.KEY_DOWN,function(e:KeyboardEvent):void{if(NativeMotion.isSynthetic(root))keys.push({code:e.keyCode,down:true});});
   root.stage.addEventListener(KeyboardEvent.KEY_UP,function(e:KeyboardEvent):void{if(NativeMotion.isSynthetic(root))keys.push({code:e.keyCode,down:false});});
   var route:Array=[walk(100,false,true,false,0),walk(200,true,false,true,100),walk(300,false,false,false,10),["hole",100]];
   var before:String=com.adobe.serialization.json.JSON.encode(route);
   var bot:RoutePlayerNative=new RoutePlayerNative(root);bot.setRoutes({"@123":route});bot.setTiming(new RouteTiming(1,false));
   bot.advance(0);bot.advance(249);check(keys.length==0,"original startup wait is preserved");
   bot.advance(300);check(player.right && !player.left,"first reached anchor commits RIGHT");check(bot.message.indexOf("1/4")>=0,"first anchor advances exactly one index");
   check(writes==0 && syncs==0,"startup never repositions or injects a sync");
   bot.advance(333);bot.advance(399);check(bot.message.indexOf("1/4")>=0,"next recorded 100ms delay starts at actual anchor arrival");
   bot.advance(400);check(bot.message.indexOf("aguardando chegada ao ponto 2/4")>=0,"expired timer activates second target but does not consume it");
   check(player.x==30 && writes==0,"unreached target cannot snap the player to its coordinates");
   bot.advance(600);bot.advance(1000);bot.advance(2000);check(bot.message.indexOf("aguardando chegada ao ponto 2/4")>=0 && bot.message.indexOf("pausado")<0,"long arrival delay neither skips target nor trips the old 500ms timeout");
   var jumpDowns:int=0;for each(var key:Object in keys)if(key.code==38 && key.down)jumpDowns++;check(jumpDowns==0,"UP is not committed a full ground segment before the takeoff target");
   player.x=60;bot.advance(2100);check(bot.message.indexOf("executando @123 | 2/4")>=0,"real arrival advances the second target exactly once");
   jumpDowns=0;for each(key in keys)if(key.code==38 && key.down)jumpDowns++;check(jumpDowns==1,"arrival commits the recorded jump once");
   bot.advance(2110);bot.advance(2132);check(bot.message.indexOf("executando @123 | 2/4")>=0,"33ms interval still applies after delayed arrival");
   bot.advance(2133);check(bot.message.indexOf("aguardando chegada ao ponto 3/4")>=0,"third target stays pending until its physical position is visited");
   bot.advance(2500);check(bot.message.indexOf("aguardando chegada ao ponto 3/4")>=0,"third target cannot finish merely because original route time expired");
   player.x=90;bot.advance(2600);check(bot.message.indexOf("executando @123 | 3/4")>=0,"physical third-point arrival advances the index");
   check(writes==0 && syncs==0 && player.x==90 && player.y==330.6,"all coordinate changes came from test physics, never from Robot");
   check(body.velocity.vx==7 && body.velocity.vy==-3,"arrival checks do not overwrite native VX or VY");
   bot.advance(2699);check(bot.message.indexOf("3/4")>=0,"next 100ms timer restarts at arrival 2600, not the old route deadline");
   bot.advance(2700);check(bot.message.indexOf("confirmacao")>=0,"terminal marker runs only after the arrival-based delay");
   bot.advance(10000);check(player.x==90 && writes==0 && syncs==0,"terminal wait cannot teleport to finish");
   check(com.adobe.serialization.json.JSON.encode(route)==before,"original route JSON remains unchanged");
   root.auto_play=false;bot.advance(10001);check(!player.left && !player.right,"disable releases keys immediately");
   player.x=30;root.auto_play=true;bot.advance(11000);bot.advance(11250);check(player.right && writes==0 && syncs==0,"reactivation clears pending target and timing state");
   player.dead=true;bot.advance(11251);check(!player.right,"death releases held keys");player.dead=false;bot.advance(11400);bot.advance(11650);check(player.right && writes==0 && syncs==0,"respawn starts a fresh arrival clock without teleport");
   root.auto_play=false;bot.advance(11651);
   player.x=30;root.auto_play=true;var repeat:RoutePlayerNative=new RoutePlayerNative(root);
   repeat.setRoutes({"@123":[walk(100,false,true,false,0),walk(100,true,false,false,100),["hole",100]]});repeat.setTiming(new RouteTiming(1,false));
   repeat.advance(20000);repeat.advance(20250);player.x=60;repeat.advance(20350);
   check(repeat.message.indexOf("aguardando chegada ao ponto 2/3")>=0,"a previous visit to repeated coordinates cannot falsely confirm a later target");
   player.x=30;repeat.advance(20400);check(repeat.message.indexOf("2/3")>=0 && repeat.message.indexOf("aguardando chegada")<0,"return target requires a fresh actual arrival");
   root.auto_play=false;repeat.advance(20401);
   // Independent keyboard/acceleration model: physics moves the player, not the Robot.
   player.x=30;player.y=330.6;body.velocity.vx=0;body.velocity.vy=0;root.auto_play=true;
   var departure:Array=walk(100,false,true,false,0);departure[0].vx=0;departure[0].vy=0;
   var middle:Array=walk(200,false,true,false,100);middle[0].vy=0;
   var stop:Array=walk(300,false,false,false,100);stop[0].vx=0;stop[0].vy=0;
   var sim:RoutePlayerNative=new RoutePlayerNative(root);sim.setRoutes({"@123":[departure,middle,stop,["hole",200]]});sim.setTiming(new RouteTiming(1,false));sim.advance(21000);
   var completed:Boolean=false;var lastArrival:int=-1;
   for(var tick:int=21016;tick<26000;tick+=16){
    var vx:Number=body.velocity.vx;var acceleration:Number=12*0.016;
    if(player.right)vx=Math.min(3.45,vx+acceleration);
    else if(player.left)vx=Math.max(-3.45,vx-acceleration);
    else vx=vx>0 ? Math.max(0,vx-acceleration) : Math.min(0,vx+acceleration);
    body.velocity.vx=vx;player.x+=vx*30*0.016;var physicalX:Number=player.x;sim.advance(tick);
    check(player.x==physicalX && body.velocity.vx==vx,"keyboard physics simulation never receives a position or velocity write");
    if(lastArrival<0 && sim.message.indexOf("executando @123 | 3/4")>=0)lastArrival=tick;
    if(lastArrival>=0 && tick<lastArrival+200)check(sim.message.indexOf("confirmacao")<0,"terminal delay counts from physical arrival in independent movement simulation");
    if(sim.message.indexOf("confirmacao")>=0){completed=true;break;}
   }
   check(completed && lastArrival>=0,"native-key model reaches all three physical checkpoints before the terminal marker");
   check(writes==0 && syncs==0,"independent movement simulation never invokes teleport or sync handlers");
   root.auto_play=false;sim.advance(26001);
   ExternalInterface.call("recordTest","PASS: "+count+" arrival-clock, ordered-step, 33ms and no-teleport checks");
  }catch(error:Error){ExternalInterface.call("recordTest","FAIL: "+error.message+" #"+error.errorID);}}
 }
}
