"""Rebuild production SWF + two test fixtures with Java 21 and FFDec 26.4.0."""
import argparse,os,pathlib,shutil,subprocess,tempfile
HERE=pathlib.Path(__file__).resolve().parent
ROOT=HERE.parent

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--ffdec',type=pathlib.Path,required=True,help='Directory containing ffdec.jar and lib/')
    parser.add_argument('--output',type=pathlib.Path,default=ROOT/'DisneyClient/public/ChargeurTransformice.swf')
    parser.add_argument('--fixtures',type=pathlib.Path,default=HERE/'fixtures')
    args=parser.parse_args()
    import split_routes
    print(split_routes.split(ROOT/'DisneyClient/public/rotas_decodificadas.json',ROOT/'DisneyClient/public/rotas'))
    cp=str(args.ffdec.resolve()/'ffdec.jar')+os.pathsep+str(args.ffdec.resolve()/'lib/*')
    def java(script,*arguments):subprocess.run(['java','-cp',cp,str(script),*map(str,arguments)],check=True,cwd=ROOT)
    # Canonical source files retain the original user-facing names. New ABC names
    # avoid replacing/removing existing method IDs in the supplied loader.
    text=(ROOT/'fontes-follow/FollowControllerV13.as').read_text()
    (HERE/'FollowControllerV13Shared.as').write_text(text.replace('FollowControllerV13','FollowControllerV13Shared'))
    text=(ROOT/'fontes-autoplay/RoutePlayer.as').read_text()
    text=text.replace('class RoutePlayer','class RoutePlayerNative').replace('new RoutePlayer(', 'new RoutePlayerNative(').replace('var r:RoutePlayer=', 'var r:RoutePlayerNative=').replace('function RoutePlayer(', 'function RoutePlayerNative(')
    (HERE/'RoutePlayerNative.as').write_text(text)
    shutil.copyfile(ROOT/'fontes-visual/AstroVisual.as',HERE/'AstroVisual.as')
    shutil.copyfile(ROOT/'fontes-fly/FlyController.as',HERE/'FlyController.as')
    shutil.copyfile(ROOT/'fontes-followautobest/FollowAutoBest.as',HERE/'FollowAutoBest.as')
    for name in ['MusicPlayer','LocalServerLog','FollowPlayersPanel','MenuShell','SettingsControlsUI','PerformanceControlsUI']:
        shutil.copyfile(ROOT/'fontes-interface'/(name+'.as'),HERE/(name+'.as'))
    with tempfile.TemporaryDirectory() as folder:
        compiled=pathlib.Path(folder)/'compiled.swf'
        java(HERE/'PatchRobot.java',HERE/'loader-base.swf',HERE,compiled)
        cleaned=pathlib.Path(folder)/'cleaned.swf'
        java(HERE/'LegacyRemoval.java',compiled,cleaned)
        shutil.copyfile(cleaned,compiled)
        java(HERE/'VerifyRobot.java',HERE/'loader-base.swf',compiled)
        args.fixtures.mkdir(parents=True,exist_ok=True)
        builder=ROOT/'fontes-rolagem/BuildScrollFixture.java'
        java(builder,compiled,HERE/'RobotTests.as',args.fixtures/'RobotTests.swf')
        java(builder,compiled,HERE/'FollowRegressionTests.as',args.fixtures/'FollowRegression.swf')
        java(builder,compiled,ROOT/'fontes-visual/VisualTests.as',args.fixtures/'VisualTests.swf')
        java(builder,compiled,ROOT/'fontes-fly/FlyTests.as',args.fixtures/'FlyTests.swf')
        java(builder,compiled,ROOT/'fontes-followautobest/AutoBestTests.as',args.fixtures/'AutoBestTests.swf')
        java(builder,compiled,ROOT/'fontes-interface/InterfaceTests.as',args.fixtures/'InterfaceTests.swf')
        java(builder,compiled,ROOT/'fontes-interface/MusicTests.as',args.fixtures/'MusicTests.swf')
        args.output.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(compiled,args.output)
    print('Production SWF and fixtures built. Run run_tests.cjs separately.')
if __name__=='__main__':main()
