package disney {
 import flash.display.MovieClip;

 // Read-only feedback. All actuation remains in NativeMotion.movement().
 public class RouteFeedback {
  public static const RADIUS:Number=24;
  public static const CONFIRM_RADIUS:Number=8;
  public var hitAt:Number;
  private var history:Array=[];
  private var current:Object;
  private var correction:int=0;
  private var boundary:Number=-1;
  public var source:String="aguardando";

  public function reset():void {history=[];current=null;correction=0;boundary=-1;hitAt=NaN;source="aguardando";}
  private function read(o:Object,key:*):* {
   try {if(o && key!=null && key in o)return o[key];}catch(ignored:Error){}
   return null;
  }
  private function component(o:Object,a:*,b:*):Number {
   var v:* = read(o,a);if(v==null)v=read(o,b);
   return v is Number && isFinite(Number(v)) ? Number(v) : NaN;
  }
  public function observe(player:Object,body:Object,k:Object,now:Number):Object {
   var x:Number=Number(player.x);var y:Number=Number(player.y);
   try {
    var transform:Function=read(body,k.get_x_form) as Function;
    if(transform!=null){var t:Object=transform.apply(body,[]);var pos:Object=t ? t.position : null;
     var px:Number=component(pos,k.pos_x,null);var py:Number=component(pos,k.pos_y,null);
     if(isFinite(px) && isFinite(py)){x=px*30;y=py*30;}
    }
   }catch(ignoredTransform:Error){}
   if(!isFinite(x) || !isFinite(y))throw new Error("Posicao local indisponivel",2601);
   var vx:Number=NaN;var vy:Number=NaN;
   try {
    var getter:Function=read(body,k.get_linear_velocity) as Function;
    var velocity:Object=getter!=null ? getter.apply(body,[]) : read(body,k.physics_state);
    vx=component(velocity,k.pos_x,k.physics_state_vx);
    vy=component(velocity,k.pos_y,k.physics_state_vy);
   }catch(ignoredVelocity:Error){}
   source="nativa";
   if(!isFinite(vx) || !isFinite(vy)){
    source="estimada";
    if(current && now>current.time && now-current.time<=250){
     var seconds:Number=(now-current.time)/1000;
     vx=(x-current.x)/(30*seconds);vy=(y-current.y)/(30*seconds);
    }else{vx=0;vy=0;source="aguardando";}
   }
   current={x:x,y:y,vx:vx,vy:vy,time:now,phase:vy < -0.35 ? "subindo" : (vy > 0.35 ? "caindo" : "apoio")};history.push(current);
   while(history.length>512)history.shift();
   return current;
  }
  public function state():Object {return current;}
  // Circle entry plus forward progress along the incoming route segment.
  // Returns the earliest actual visit, not the timestamp of the recorded step.
  private function entry(a:Object,b:Object,target:Object,previous:Object,since:Number):Number {
   var elapsed:Number=b.time-a.time;
   var lo:Number=elapsed>0 ? Math.max(0,(since-a.time)/elapsed) : 0;
   var hi:Number=1;
   if(lo>hi || b.time<since)return NaN;
   var sx:Number=b.x-a.x;var sy:Number=b.y-a.y;var length2:Number=sx*sx+sy*sy;
   var mx:Number=a.x-target.x;var my:Number=a.y-target.y;
   var radius2:Number=CONFIRM_RADIUS*CONFIRM_RADIUS;
   if(length2<=0){if(mx*mx+my*my>radius2)return NaN;}
   else {
    var linear:Number=2*(mx*sx+my*sy);
    var constant:Number=mx*mx+my*my-radius2;
    var discriminant:Number=linear*linear-4*length2*constant;
    if(discriminant<0)return NaN;
    var root:Number=Math.sqrt(Math.max(0,discriminant));
    lo=Math.max(lo,(-linear-root)/(2*length2));
    hi=Math.min(hi,(-linear+root)/(2*length2));
   }
   if(previous){
    var ux:Number=target.x-previous.x;var uy:Number=target.y-previous.y;
    var distance:Number=Math.sqrt(ux*ux+uy*uy);
    if(distance>0.000001){
     ux/=distance;uy/=distance;
     var before:Number=mx*ux+my*uy;
     var progress:Number=sx*ux+sy*uy;
     var tolerance:Number=Math.min(2,Math.max(0.5,distance*0.1));
     if(Math.abs(progress)<0.000000001){if(before < -tolerance)return NaN;}
     else if(progress>0)lo=Math.max(lo,(-tolerance-before)/progress);
     else hi=Math.min(hi,(-tolerance-before)/progress);
    }
   }
   if(lo>hi+0.00000001 || hi<0 || lo>1)return NaN;
   lo=Math.max(0,Math.min(1,lo));
   return a.time+lo*elapsed;
  }
  public function checkpoint(target:Object,since:Number,previous:Object=null):Boolean {
   hitAt=NaN;if(!current)return false;
   var from:int=0;var to:int=history.length;
   while(from<to){var middle:int=int((from+to)/2);if(history[middle].time<since)from=middle+1;else to=middle;}
   for(var i:int=from;i<history.length;i++){
    var b:Object=history[i];
    var a:Object=i>0 ? history[i-1] : b;
    var sx:Number=b.x-a.x;var sy:Number=b.y-a.y;
    var span:Number=b.time-a.time;
    // Cropping at 'since' keeps the unconsumed part of the same frame's path.
    // Large external repositions never become synthetic swept segments.
    if(span>250 || span<=0 || sx*sx+sy*sy>4096)a=b;
    var visited:Number=entry(a,b,target,previous,since);
    if(isFinite(visited)){hitAt=visited;return true;}
   }
   return false;
  }
  public function crossedAt(now:Number):void {boundary=Math.max(boundary,now);}
  public function changeInputs():void {correction=0;}
  public function since():Number {return boundary;}

  // Position and VX are read from the live body; all output is native input.
  // No recorded timing, interpolation curve, recovery timer or future-VY gate.
  public function controls(target:Object):Object {
   if(!target || !current)return {left:false,right:false,jump:false};
   var l:Boolean=Boolean(target.ml);var r:Boolean=Boolean(target.mr);
   var jump:Boolean=Boolean(target.jump);
   var positionError:Number=target.x-current.x;
   var magnitude:Number=Math.abs(Number(target.vx));
   // An after-collision velocity pointing backwards must not pull the mouse
   // away from a still-unvisited target. It supplies speed magnitude only.
   var wantedVX:Number=Number(target.vx);
   if(positionError>0.5)wantedVX=magnitude;
   else if(positionError < -0.5)wantedVX=-magnitude;
   else if(l!=r)wantedVX=l ? -magnitude : magnitude;
   var velocityError:Number=wantedVX-current.vx;
   var effort:Number=0.045*positionError+0.8*velocityError;
   if(Math.abs(effort)>=0.8)correction=effort<0 ? -1 : 1;
   else if(Math.abs(effort)<=0.25)correction=0;
   // A small remaining displacement must not stall inside the input deadband.
   if(Math.abs(positionError)>0.5 && Math.abs(current.vx)<0.35 && Math.abs(effort)<0.8)correction=positionError<0 ? -1 : 1;
   if(correction<0){l=true;r=false;}
   else if(correction>0){l=false;r=true;}
   return {left:l,right:r,jump:jump};
  }

 }
}
