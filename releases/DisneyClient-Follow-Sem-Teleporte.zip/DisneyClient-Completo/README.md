# krakitos

Build atual: **Robot ESPACIAL + logs de conexao**, baseada no ZIP do commit `226ce1965580a6591e8fb42263a0cb4671794140`.

O Robot le a posicao e a velocidade ao vivo e corrige esquerda/direita pelos controles nativos. Os delays gravados sao ignorados; os pontos orientam o caminho por chegada ou passagem real. Nao escreve coordenadas/VX/VY, nao sincroniza a posicao inicial e nao pula pontos por timeout.

O backend registra desconexoes observadas pelo Flash em `logs-client/disconnects.jsonl`, com codigo, canal, usuario, mapa e estado do Robot. Se o jogo nao informar a razao, `game_server_reason` fica `null`; o evento nao permite afirmar sozinho que houve kick.

- [Atualizacao para a instalacao existente](Atualizacao-Robot-Espacial-Logs.zip)
- [Pacote completo](DisneyClient-Follow.zip)
- [SWF avulsa](ChargeurTransformice.swf)
- [Instalacao](LEIA-ME-ATUALIZACAO.txt)
- [Movimentacao](ROBOT-ESPACIAL-LEIA-ME.txt)
- [Logs na VPS](LOGS-CONEXAO-LEIA-ME.txt)
- [Validacao do Robot](fontes-robot/VALIDACAO-ESPACIAL.json)
- [Validacao dos logs](fontes-conexao/VALIDACAO-LOGS.json)

Feche o Flash e pare o backend. Extraia o ZIP de atualizacao dentro da pasta existente `DisneyClient-Completo` e reinicie seu inicializador habitual. E necessario atualizar **a SWF e `DisneyClient/api/diagnostics.py`** para receber os novos logs remotos. O patch preserva `.env`, configuracoes e saves. Na aba Robot, confira o prefixo `Robot ESPACIAL:`.

As oito suites locais passaram com 762 verificacoes no Ruffle/Chromium, mais 15 testes Python do endpoint de logs. A biblioteca completa de rotas foi validada sem alteracoes. Esses testes usam modelos sinteticos; uma partida na fisica real e o comportamento de desconexao ainda precisam de validacao no jogo. A VPS nao foi atualizada remotamente.

O ZIP completo contem as fontes e dependencias de compilacao do projeto; as pastas do repositorio publicam um recorte das alteracoes. As verificacoes historicas se referem as respectivas builds antigas.
