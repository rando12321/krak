package disney {
 // Coalesces Robot input changes before the native game handles/sends them.
 // No socket queue, encryption changes, heartbeat delay or artificial lag.
 public class RouteInputPacer {
  public static const INTERVAL:int=33;
  private var emitted:Object;
  private var at:Number=0;
  public function reset():void{emitted=null;at=0;}
  public function allow(input:Object,now:Number):Boolean{
   if(!input || !isFinite(now))return false;
   if(emitted && input.left==emitted.left && input.right==emitted.right && input.jump==emitted.jump)return false;
   if(emitted && now>=at && now-at<INTERVAL)return false;
   emitted={left:Boolean(input.left),right:Boolean(input.right),jump:Boolean(input.jump)};at=now;return true;
  }
 }
}
