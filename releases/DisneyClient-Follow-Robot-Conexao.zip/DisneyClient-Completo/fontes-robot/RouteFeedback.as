package disney {
 import flash.display.MovieClip;

 // Read-only feedback. All actuation remains in NativeMotion.movement().
 public class RouteFeedback {
  public static const RADIUS:Number=24;
  public static const CONFIRM_RADIUS:Number=8;
  public var hitAt:Number;
  private var history:Array=[];
  private var current:Object;
  private var correction:int=0;
  private var boundary:Number=-1;
  private var frameSeconds:Number=1/60;
  private var braking:Number=12;
  private var gravity:Number=10;
  private var jumpStarted:Boolean=false;
  public var source:String="aguardando";

  public function reset():void {history=[];current=null;correction=0;boundary=-1;hitAt=NaN;source="aguardando";frameSeconds=1/60;braking=12;gravity=10;jumpStarted=false;}
  private function read(o:Object,key:*):* {
   try {if(o && key!=null && key in o)return o[key];}catch(ignored:Error){}
   return null;
  }
  private function component(o:Object,a:*,b:*):Number {
   var v:* = read(o,a);if(v==null)v=read(o,b);
   return v is Number && isFinite(Number(v)) ? Number(v) : NaN;
  }
  public function observe(player:Object,body:Object,k:Object,now:Number,inputs:Object=null):Object {
   var x:Number=Number(player.x);var y:Number=Number(player.y);
   try {
    var transform:Function=read(body,k.get_x_form) as Function;
    if(transform!=null){var t:Object=transform.apply(body,[]);var pos:Object=t ? t.position : null;
     var px:Number=component(pos,k.pos_x,null);var py:Number=component(pos,k.pos_y,null);
     if(isFinite(px) && isFinite(py)){x=px*30;y=py*30;}
    }
   }catch(ignoredTransform:Error){}
   if(!isFinite(x) || !isFinite(y))throw new Error("Posicao local indisponivel",2601);
   var vx:Number=NaN;var vy:Number=NaN;
   try {
    var getter:Function=read(body,k.get_linear_velocity) as Function;
    var velocity:Object=getter!=null ? getter.apply(body,[]) : read(body,k.physics_state);
    vx=component(velocity,k.pos_x,k.physics_state_vx);
    vy=component(velocity,k.pos_y,k.physics_state_vy);
   }catch(ignoredVelocity:Error){}
   source="nativa";
   if(!isFinite(vx) || !isFinite(vy)){
    source="estimada";
    if(current && now>current.time && now-current.time<=250){
     var seconds:Number=(now-current.time)/1000;
     vx=(x-current.x)/(30*seconds);vy=(y-current.y)/(30*seconds);
    }else{vx=0;vy=0;source="aguardando";}
   }
   if(current && now>current.time && now-current.time<=100){
    var dt:Number=(now-current.time)/1000;
    frameSeconds=0.75*frameSeconds+0.25*dt;
    var observedGravity:Number=(vy-current.vy)/dt;
    if(source=="nativa" && Math.abs(current.vy)>0.7 && Math.abs(vy)>0.7 && observedGravity>=2 && observedGravity<=25)
     gravity=0.85*gravity+0.15*observedGravity;
    if(source=="nativa" && inputs && Math.abs(current.vx)>0.5 &&
       ((current.vx>0 && inputs.left && !inputs.right) || (current.vx<0 && inputs.right && !inputs.left))){
     var deceleration:Number=(Math.abs(current.vx)-Math.abs(vx))/dt;
     // Ignore impacts, bounces and ambiguous external impulses.
     if(current.vx*vx>0 && deceleration>=2 && deceleration<=40)braking=0.8*braking+0.2*deceleration;
    }
   }
   current={x:x,y:y,vx:vx,vy:vy,time:now,phase:vy < -0.35 ? "subindo" : (vy > 0.35 ? "caindo" : "apoio")};history.push(current);
   while(history.length>512)history.shift();
   return current;
  }
  public function state():Object {return current;}
  // Circle entry plus forward progress along the incoming route segment.
  // Returns the earliest actual visit, not the timestamp of the recorded step.
  private function entry(a:Object,b:Object,target:Object,previous:Object,since:Number):Number {
   // The same coordinate can occur on ascent and descent. Do not consume a
   // future landing checkpoint during the outward half of the jump.
   if(Number(target.vy)<-0.7 && Number(a.vy)>0.7 && Number(b.vy)>0.7)return NaN;
   if(Number(target.vy)>0.7 && Number(a.vy)<-0.7 && Number(b.vy)<-0.7)return NaN;
   var elapsed:Number=b.time-a.time;
   var lo:Number=elapsed>0 ? Math.max(0,(since-a.time)/elapsed) : 0;
   var hi:Number=1;
   if(lo>hi || b.time<since)return NaN;
   var sx:Number=b.x-a.x;var sy:Number=b.y-a.y;var length2:Number=sx*sx+sy*sy;
   var mx:Number=a.x-target.x;var my:Number=a.y-target.y;
   var radius2:Number=CONFIRM_RADIUS*CONFIRM_RADIUS;
   if(length2<=0){if(mx*mx+my*my>radius2)return NaN;}
   else {
    var linear:Number=2*(mx*sx+my*sy);
    var constant:Number=mx*mx+my*my-radius2;
    var discriminant:Number=linear*linear-4*length2*constant;
    if(discriminant<0)return NaN;
    var root:Number=Math.sqrt(Math.max(0,discriminant));
    lo=Math.max(lo,(-linear-root)/(2*length2));
    hi=Math.min(hi,(-linear+root)/(2*length2));
   }
   if(previous){
    var ux:Number=target.x-previous.x;var uy:Number=target.y-previous.y;
    var distance:Number=Math.sqrt(ux*ux+uy*uy);
    if(distance>0.000001){
     ux/=distance;uy/=distance;
     var before:Number=mx*ux+my*uy;
     var progress:Number=sx*ux+sy*uy;
     var tolerance:Number=Math.min(2,Math.max(0.5,distance*0.1));
     if(Math.abs(progress)<0.000000001){if(before < -tolerance)return NaN;}
     else if(progress>0)lo=Math.max(lo,(-tolerance-before)/progress);
     else hi=Math.min(hi,(-tolerance-before)/progress);
    }
   }
   if(lo>hi+0.00000001 || hi<0 || lo>1)return NaN;
   lo=Math.max(0,Math.min(1,lo));
   return a.time+lo*elapsed;
  }
  public function checkpoint(target:Object,since:Number,previous:Object=null):Boolean {
   hitAt=NaN;if(!current)return false;
   var from:int=0;var to:int=history.length;
   while(from<to){var middle:int=int((from+to)/2);if(history[middle].time<since)from=middle+1;else to=middle;}
   for(var i:int=from;i<history.length;i++){
    var b:Object=history[i];
    var a:Object=i>0 ? history[i-1] : b;
    var sx:Number=b.x-a.x;var sy:Number=b.y-a.y;
    var span:Number=b.time-a.time;
    // Cropping at 'since' keeps the unconsumed part of the same frame's path.
    // Large external repositions never become synthetic swept segments.
    if(span>250 || span<=0 || sx*sx+sy*sy>4096)a=b;
    var visited:Number=entry(a,b,target,previous,since);
    if(isFinite(visited)){hitAt=visited;return true;}
   }
   return false;
  }
  public function crossedAt(now:Number):void {boundary=Math.max(boundary,now);}
  public function changeInputs():void {correction=0;jumpStarted=false;}
  public function since():Number {return boundary;}

  // Samples describe the state AT a waypoint. Keep the incoming command
  // until arrival; do not apply a future reversal at the previous waypoint.
  public function controls(target:Object,previous:Object=null):Object {
   if(!target || !current)return {left:false,right:false,jump:false};
   var incoming:Object=previous ? previous : target;
   var l:Boolean=Boolean(incoming.ml);var r:Boolean=Boolean(incoming.mr);
   var jump:Boolean=Boolean(incoming.jump);
   var dx:Number=target.x-current.x;
   var direction:Number=dx<0 ? -1 : 1;
   var desired:Number=Math.abs(Number(target.vx));
   if(previous){
    var span:Number=Math.abs(target.x-previous.x);
    var progress:Number=span>0.5 ? Math.max(0,Math.min(1,1-Math.abs(dx)/span)) : 1;
    desired=Math.abs(Number(previous.vx))*(1-progress)+desired*progress;
    // A resting departure snapshot is not a command to stay at rest.
    if(desired<0.35 && Math.abs(dx)>2 && (l!=r || target.ml!=target.mr))desired=3.45;
   }
   var wantedVX:Number=desired*direction;
   if(Math.abs(dx)<=0.5)wantedVX=l!=r ? (l ? -desired : desired) : Number(target.vx);
   // Limit the approach speed when the recording actually stops here.
   // v^2 = v_end^2 + 2*a*distance, with units converted from pixels to metres.
   if(previous && Math.abs(Number(target.vx))<0.35 && !target.ml && !target.mr){
    var stopping:Number=Math.sqrt(Number(target.vx)*Number(target.vx)+2*braking*Math.max(0,Math.abs(dx)-1)/30);
    wantedVX=direction*Math.min(Math.abs(wantedVX),stopping);
   }
   // Predict one measured frame ahead to brake before overshooting.
   var horizon:Number=Math.max(0.008,Math.min(0.05,frameSeconds));
   var predictedError:Number=dx-(current.vx-wantedVX)*30*horizon;
   var effort:Number=0.045*predictedError+0.8*(wantedVX-current.vx);
   if(Math.abs(effort)>=0.8)correction=effort<0 ? -1 : 1;
   else if(Math.abs(effort)<=0.25)correction=0;
   if(Math.abs(dx)>0.5 && Math.abs(current.vx)<0.35 && Math.abs(effort)<0.8)correction=direction;
   if(correction<0){l=true;r=false;}
   else if(correction>0){l=false;r=true;}
   if(previous && Boolean(target.jump)!=Boolean(previous.jump)){
    if(target.jump){
     // Reconstruct the takeoff from the first rising sample. This allows an
     // elevated checkpoint without jumping a whole segment too early.
     var flight:Number=Math.max(0,Math.min(0.5,(Number(target.vy)+5)/gravity));
     var launchX:Number=target.x-Number(target.vx)*30*flight;
     var launchY:Number=target.y-30*(-5*flight+0.5*gravity*flight*flight);
     var travel:Number=target.x-previous.x;
     var nearLaunch:Boolean=Math.abs(launchX-current.x)<=Math.max(2,Math.abs(current.vx)*30*horizon);
     var passedLaunch:Boolean=travel>0 ? current.x>=launchX : (travel<0 ? current.x<=launchX : nearLaunch);
     var grounded:Boolean=Math.abs(current.vy)<0.35;
     var plausible:Boolean=Number(target.vy)<=-0.35 && Number(target.vy)>=-5.35 && Math.abs(launchY-current.y)<=8;
     jumpStarted=jumpStarted || (plausible && (nearLaunch || passedLaunch)) ||
          (grounded && !plausible && target.y<current.y-8 && Math.abs(travel)<2);
     jump=jumpStarted;
    }else{
     // Releasing UP does not force vertical velocity; release at the sample.
     jump=Boolean(previous.jump);
    }
   }
   return {left:l,right:r,jump:jump};
  }

 }
}
