package disney {
 import flash.display.MovieClip;import flash.display.DisplayObject;import flash.display.InteractiveObject;import flash.events.Event;import flash.events.KeyboardEvent;import flash.events.IOErrorEvent;import flash.events.SecurityErrorEvent;import flash.net.URLLoader;import flash.net.URLRequest;import flash.text.TextField;import flash.utils.Dictionary;import flash.utils.getTimer;import flash.utils.ByteArray;
 public class RoutePlayerNative {
  private var managed:Boolean=false;private var managedOn:Boolean=false;private var worldSpace:Boolean=false;
  private static var instances:Dictionary=new Dictionary(true);
  private var inputPacer:RouteInputPacer=new RouteInputPacer();private var commandState:Object;private var lastControl:Object={left:false,right:false,jump:false};private var feedback:RouteFeedback=new RouteFeedback();private var focused:Boolean=true;private var roundToken:String="";private var restartPending:Boolean=false;private var lastState:Object;
  private var remote:Boolean=true;private var loadingCode:String="";private var failedCode:String="";private var cacheOrder:Array=[];private var root:MovieClip;private var motion:NativeMotion;private var routes:Object;private var loadError:String="";private var loader:URLLoader;
  private var map:Object;private var player:Object;private var body:Object;private var code:String="";private var aliveBefore:Boolean=false;
  private var sequence:Array;private var index:int=0;private var enabled:Boolean=false;private var attempted:Boolean=false;private var running:Boolean=false;private var paused:Boolean=false;
  private var mirror:Boolean=false;private var width:Number=800;private var pauseMessage:String="Robot: pausado; reative para reiniciar";private var won:Boolean=false;private var entering:Boolean=false;private var failure:String="";public var message:String="Robot: aguardando jogo";
  public function RoutePlayerNative(value:MovieClip,external:Boolean=false){managed=external;root=value;motion=NativeMotion.get(value);if(!managed)motion.observeWith(packet);routes={};}
  public function setManagedActive(value:Boolean):void{if(!managed)return;managedOn=value;if(!value){cancelLoad();reset(getTimer());enabled=false;}}
  public function setWorldSpace(value:Boolean):void{worldSpace=value;}
  public static function attach(value:MovieClip):void{
   if(!value || !value.stage || instances[value])return;var r:RoutePlayerNative=new RoutePlayerNative(value);instances[value]=r;r.loadRoutes();
   value.stage.addEventListener(Event.ACTIVATE,function(e:Event):void{r.setFocused(true);});
   value.stage.addEventListener(Event.DEACTIVATE,function(e:Event):void{r.setFocused(false);});
   value.stage.addEventListener(Event.ENTER_FRAME,function(e:Event):void{r.advance(getTimer());},false,1000);
   value.stage.addEventListener(KeyboardEvent.KEY_DOWN,function(e:KeyboardEvent):void{
    if(NativeMotion.isSynthetic(value))return;
    if(value.stage.focus is TextField && TextField(value.stage.focus).type=="input")return;
    if(value["auto_play_disable_on_move"] && [37,38,39,40,65,68,83,87].indexOf(e.keyCode)>=0)r.pause();
   });
  }
  // Compatibility entry point: arming the loader performs no I/O or catalog parsing.
  public function loadRoutes():void{remote=true;failedCode="";loadError="";}
  private function cancelLoad():void{if(loader){try{loader.close();}catch(e:Error){}loader=null;}loadingCode="";}
  private function requestRoute(which:String):void{
   if(loadingCode==which || failedCode==which)return;cancelLoad();loadingCode=which;loadError="";
   var current:URLLoader=new URLLoader();loader=current;
   current.addEventListener(Event.COMPLETE,function(e:Event):void{
    if(loader!==current)return;
    try{var text:String=String(current.data);if(text.length>262144)throw new Error("Route file too large",2520);routes[which]=decodeRoute(text);current.data="";cacheOrder.push(which);while(cacheOrder.length>4){var old:String=String(cacheOrder.shift());if(old!=which)delete routes[old];}loader=null;loadingCode="";}
    catch(error:Error){failedCode=which;loadError="rota invalida #"+error.errorID;loader=null;loadingCode="";}
   });
   var fail:Function=function(e:Event):void{if(loader!==current)return;failedCode=which;loadError="nao foi possivel carregar public/rotas/"+which.substr(1)+".json";loader=null;loadingCode="";};
   current.addEventListener(IOErrorEvent.IO_ERROR,fail);current.addEventListener(SecurityErrorEvent.SECURITY_ERROR,fail);
   try{current.load(new URLRequest(String(root["host_url"])+"public/rotas/"+which.substr(1)+".json"));}catch(error:Error){fail(new Event("error"));}
  }
  public function setRoutes(value:Object):void{
   if(!value || value is Array)throw new Error("Route dictionary required",2501);
   var total:int=0;for(var name:String in value){if(!/^@(?:[0-9]+|a|v)$/.test(name) || !(value[name] is Array))throw new Error("Invalid map route",2502);total++;}
   if(total==0)throw new Error("Empty route dictionary",2503);cancelLoad();remote=false;routes=value;loadError="";
  }
  private function status(text:String):void{text="Robot ESPACIAL: "+text.replace(/^Robot: /,"");message=text;var ui:Object=root["Interface"];if(ui && ui["status_field"])ui["status_field"].text=text;}
  private function release():void{inputPacer.reset();motion.release(this);lastControl={left:false,right:false,jump:false};}
  public function pause():void{if(!enabled)return;release();running=false;paused=true;pauseMessage="Robot: pausado pela tecla; reative para reiniciar";status(pauseMessage);}
  private function reset(now:int):void{commandState=null;feedback.reset();release();running=false;attempted=false;paused=false;failure="";won=false;entering=false;sequence=null;index=0;lastState=null;restartPending=false;}
  public function setFocused(value:Boolean):void{focused=value;if(!value)release();}
  public function setTiming(policy:RouteTiming):void{} // compatibility: no random pauses or coordinate offsets
  private static function integer(value:*,minimum:Number,maximum:Number):Boolean{return value is Number && isFinite(Number(value)) && Number(value)==Math.floor(Number(value)) && Number(value)>=minimum && Number(value)<=maximum;}
  public static function decodeRoute(text:String):Array{return validate(com.adobe.serialization.json.JSON.decode(text) as Array);}
  public static function validate(route:Array):Array{
   if(!route || route.length==0 || route.length>100000)throw new Error("Invalid route",2001);var result:Array=[];
   for each(var step:Array in route){
    if(!step || (step.length!=2 && step.length!=3))throw new Error("Invalid step shape",2002);
    var action:String=String(step[step.length-2]);var delay:* =step[step.length-1];
    if(!integer(delay,0,3600000))throw new Error("Invalid delay",2002);
    if(["walk","cheese","hole","crouch","duck","emote"].indexOf(action)<0)throw new Error("Unknown action",2003);
    if(step.length==2 && action!="cheese" && action!="hole")throw new Error("Missing payload",2004);
    var payload:Object=step.length==3 ? step[0] : null;
    if(action=="walk"){
     if(!payload || payload is Array)throw new Error("Invalid movement",2004);
     if(!integer(payload.x,-2147483648,4294967295) || !integer(payload.y,-2147483648,4294967295) || !integer(payload.vx,-32768,65535) || !integer(payload.vy,-32768,65535) || !integer(payload.frame,-128,255))throw new Error("Invalid native numbers",2004);
     if(!(payload.mr is Boolean)||!(payload.ml is Boolean)||!(payload.jump is Boolean))throw new Error("Invalid direction flags",2004);
    }
    if((action=="crouch" || action=="duck") && !integer(payload,0,1))throw new Error("Invalid crouch",2004);
    result.push([payload,action,Number(delay)]);
   }return result;
  }
  public function packet(bytes:ByteArray):void{
   if(!enabled || bytes.bytesAvailable<2)return;
   var c:int=bytes.readUnsignedByte();var cc:int=bytes.readUnsignedByte();
   if(c==5 && cc==2){restartPending=true;return;}
   var k:Object=root["Keys"];var local:Object=k && root["tfm"] ? root["tfm"][k.player] : null;
   if(c==144 && cc==2){bytes.readUTF();if(bytes.bytesAvailable>=4 && local && k.player_id && int(local[k.player_id])==bytes.readInt())restartPending=true;return;}
   if(!attempted || (!running && !entering) || c!=8 || cc!=6 || bytes.bytesAvailable<5)return;
   bytes.readUnsignedByte();var id:int=bytes.readInt();
   if(local && k.player_id && k.player_id in local && int(local[k.player_id])==id){won=true;entering=true;running=false;release();}
  }
  public function advance(now:int):void{try{update(now);}catch(error:Error){release();if(error.errorID==2601){running=false;paused=true;pauseMessage="Robot: pausado | "+error.message+" | "+code;status(pauseMessage);return;}running=false;attempted=true;failure="Robot: erro #"+error.errorID+"; reative para tentar novamente";status(failure);}}
  private function update(now:int):void{
   var oldUi:Object=root["Interface"];var preview:DisplayObject=oldUi ? oldUi["preview_button"] as DisplayObject : null;
   if(preview){preview.visible=false;if(preview is InteractiveObject)InteractiveObject(preview).mouseEnabled=false;}

   var active:Boolean=managed ? managedOn : Boolean(root["auto_play"]);
   if(!active){cancelLoad();release();running=false;enabled=false;attempted=false;paused=false;failure="";status("Robot: desligado");return;}
   var k:Object=root["Keys"];var game:Object=root["tfm"];if(!k || !game){status("Robot: aguardando jogo");return;}
   if(!enabled){failedCode="";loadError="";enabled=true;if(!managed)FollowControllerV13Shared.stopForRobot(root);reset(now);}
   for each(var symbol:String in ["bot_map_code_object","bot_map_code_value","bot_reverse","bot_map_width","player_physics"]){if(!k[symbol]){release();status("Robot: simbolo ausente: "+symbol);return;}}
   var nextMap:Object=k.map_class ? k.map_class[k.map_instance] : null;var nextPlayer:Object=game[k.player];var nextBody:Object=nextPlayer ? nextPlayer[k.player_physics] : null;
   if(!nextMap || !nextPlayer){if(entering && nextMap===map){release();status(won ? "Robot: vitoria confirmada; aguardando renascer" : "Robot: aguardando confirmacao da toca");return;}reset(now);map=null;player=null;body=null;aliveBefore=false;status("Robot: aguardando mapa/jogador");return;}
   var numberObject:Object=nextMap[k.bot_map_code_object];var number:Number=numberObject ? Number(numberObject[k.bot_map_code_value]) : NaN;
   if(!isFinite(number)||number<=0||number!=Math.floor(number)){release();status("Robot: aguardando codigo @ do mapa");return;}
   var nextCode:String="@"+number.toFixed(0);var alive:Boolean=Boolean(nextBody) && Boolean(nextPlayer[k.player_clip]) && !nextPlayer[k.is_dead];
   var token:String="current_round_code" in root ? String(root["current_round_code"]) : "";
   if(restartPending || token!=roundToken || nextMap!==map || nextCode!=code || (alive && (!aliveBefore || nextPlayer!==player || nextBody!==body)))reset(now);
   roundToken=token;map=nextMap;player=nextPlayer;body=nextBody;code=nextCode;aliveBefore=alive;root["current_map_code"]=code;root["current_map_code_int"]=int(number);
   if(entering){release();running=false;if(won)status("Robot: vitoria confirmada; aguardando proxima rodada");else status("Robot: aguardando confirmacao nativa da toca");return;}
   if(motion.finished()){release();running=false;status("Robot: toca confirmada; aguardando renascer");return;}
   if(!alive){release();running=false;attempted=false;status("Robot: aguardando renascer | "+code);return;}
   if(!focused || root.stage.focus is TextField && TextField(root.stage.focus).type=="input"){
    if(running){pause();pauseMessage="Robot: foco perdido; reative para uma nova tentativa";status(pauseMessage);}else{release();status("Robot: aguardando foco/edicao de texto");}return;
   }
   if(paused){status(pauseMessage);return;}
   if(failure!=""){status(failure);return;}
   width=Number(k.map_class[k.bot_map_width]);if(!isFinite(width)||width<1||width>100000)throw new Error("Invalid map width",2504);
   mirror=!worldSpace && Boolean(map[k.obj_container][k.bot_reverse]);
   if(!k.move_class || !k.move_class[k.move_free] || (k.timer_class && k.timer_class[k.timer_prop])){
    if(running)reset(now);status("Robot: aguardando liberacao da rodada | "+code);return;
   }
   if(!routes){status("Robot: "+(loadError!="" ? loadError : "carregando rotas_decodificadas.json"));return;}
   if(!attempted){
    var saved:Object=routes[code];if(!saved){if(remote){requestRoute(code);status("Robot: "+(loadError!="" ? loadError : "carregando rota "+code));}else status("Robot: sem rota para "+code);return;}
    sequence=saved is String ? decodeRoute(String(saved)) : validate(saved as Array);index=0;attempted=true;running=true;

   }
   if(!running){status("Robot: rota finalizada | "+code+" | aguardando proximo mapa");return;}
   feedback.observe(player,body,k,now,lastControl);
   var count:int=0;
   while(running && count<256){
    var step:Array=sequence[index];
    if(!apply(step,k,now)){drive(now);return;}
    index++;count++;
    if(entering)break;
    if(index>=sequence.length){running=false;release();break;}
   }
   if(running && !entering)drive(now);
   if(entering){status("Robot: aguardando confirmacao nativa da toca");return;}
   status(running ? "Robot: executando "+code+" | "+index+"/"+sequence.length : "Robot: rota finalizada | "+code);
  }
  private function drive(now:int):void{
   if(!commandState)return;
   var control:Object=feedback.controls(commandState,lastState);
   if(inputPacer.allow(control,now)){motion.movement(this,control.left,control.right,control.jump);lastControl=control;}
  }
  public static function decodeMovement(p:Object):Object{
   // ByteArray conversion deliberately matches Statements.step from the loader:
   // unsigned JSON integers round-trip through signed int32/int16 wire fields.
   var b:ByteArray=new ByteArray();b.writeInt(Number(p.x));b.writeInt(Number(p.y));b.writeShort(Number(p.vx));b.writeShort(Number(p.vy));b.position=0;
   return {x:b.readInt()/100*30,y:b.readInt()/100*30,vx:b.readShort()/100,vy:b.readShort()/100,frame:int(p.frame)<<24>>24,mr:Boolean(p.mr),ml:Boolean(p.ml),jump:Boolean(p.jump)};
  }
  private function apply(step:Array,k:Object,now:int):Boolean{
   var action:String=String(step[1]);
   if(action=="walk"){
    var p:Object=decodeMovement(step[0]);
    if(mirror){p.x=width-p.x;p.vx=-p.vx;var oldRight:Boolean=p.mr;p.mr=p.ml;p.ml=oldRight;}
    // Spatial mode: select the target as soon as the preceding target is visited.
    // The stored delay never schedules or blocks native input.
    if(!commandState || commandState.ml!=p.ml || commandState.mr!=p.mr || commandState.jump!=p.jump)feedback.changeInputs();
    commandState=p;
    var since:Number=feedback.since();
    if(!feedback.checkpoint(p,since,lastState)){
     var observed:Object=feedback.state();
     status("Robot: ponto "+(index+1)+"/"+sequence.length+" | dx "+Math.round(p.x-observed.x)+" dy "+Math.round(p.y-observed.y)+" | "+observed.phase+" | v "+feedback.source);
     return false;
    }
    feedback.crossedAt(feedback.hitAt);lastState=p;
    // Commit the sampled input only after the corresponding position is visited.
    // The final command is coalesced in drive(); dense samples cannot emit a burst.
   }else if(action=="crouch" || action=="duck")motion.crouch(this,Number(step[0])!=0);
   // Cheese remains a passive marker; the native game collects it.
   else if(action=="cheese"){}
   else if(action=="hole"){entering=true;running=false;release();}
   return true;
  }
 }
}
