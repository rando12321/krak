# Python / diagnostics.py / Python 3.11 / authenticated Flash connection diagnostics, without packet or token contents
from aiohttp import web
from datetime import datetime,timezone
from pathlib import Path
import json
import time
import re
from .common import authorize

EVENTS={'guard_ready','frame_error','socket_close','io_error','security_error','physics','teleport','socket_disconnected'}
OPTIONS={'teleport','auto_play','recording','change_jump_delay','change_jump_height','change_jump_speed','change_movement_speed','mass_reduction','insta_death','insta_win','no_delay','no_bulle','soft_mode','macro'}

CONNECTION_EVENTS={'socket_close','socket_disconnected','io_error','security_error'}

def sanitize(value,limit):
    value=re.sub(r'https?://[^\s<>]+','[url]',value,flags=re.I)
    value=re.sub(r'((?:access_token|flash_token|password|authorization)\s*[:=]\s*)[^\s,;]+',r'\1[redacted]',value,flags=re.I)
    return re.sub(r'[\x00-\x1f\x7f]',' ',value)[:limit]

def append_log(target,record):
    target.parent.mkdir(exist_ok=True,parents=True)
    if target.exists() and target.stat().st_size>5*1024*1024:
        target.replace(target.with_name(target.stem+'.previous'+target.suffix))
    with target.open('a',encoding='utf-8') as handle:handle.write(json.dumps(record,ensure_ascii=True)+'\n')

class Diagnostics(web.View):
    async def post(self):
        row=await authorize(self.request)
        if self.request.content_length and self.request.content_length>16384:
            raise web.HTTPRequestEntityTooLarge(max_size=16384,actual_size=self.request.content_length)
        values=await self.request.post()
        event=values.get('event','');channel=values.get('channel','')
        if event not in EVENTS or channel not in {'main','bulle','client'}:raise web.HTTPBadRequest()
        try:
            code=int(values.get('code',0));elapsed=int(values.get('elapsed',0))
        except (TypeError,ValueError):raise web.HTTPBadRequest()
        if not -65535<=code<=65535 or not -2147483648<=elapsed<=2147483647:raise web.HTTPBadRequest()
        option_text=values.get('options','')
        if not isinstance(option_text,str) or len(option_text)>512:raise web.HTTPBadRequest()
        options=option_text.split(',') if option_text else []
        if any(name not in OPTIONS for name in options):raise web.HTTPBadRequest()
        extra={}
        if event=='physics':
            feature=values.get('feature');reason=values.get('reason')
            if feature not in {'mass','speed','round'} or reason not in {'fault','restore_pending','restored','enabled','off','paused_cheese','paused_dead','left_with_cheese','left_without_cheese','old_body_removed','native_mass_changed','paused_input'}:raise web.HTTPBadRequest()
            extra={'feature':feature,'reason':reason}
            if feature=='speed' and 'guard_build' in values:
                if values['guard_build']!='sdds-speed-edit-v2' or values.get('input_valid') not in {'0','1'}:raise web.HTTPBadRequest()
                extra.update(guard_build=values['guard_build'],input_valid=values['input_valid']=='1')
                if 'speed_value' in values:
                    try:speed=float(values['speed_value'])
                    except (TypeError,ValueError):raise web.HTTPBadRequest()
                    if not 0<speed<=9.9:raise web.HTTPBadRequest()
                    extra['speed_value']=speed
        if event=='teleport':
            reason=values.get('reason');build=values.get('build')
            if channel!='client' or reason not in {'ready','enabled','disabled','focus_field','waiting_player','requested','returned','after_200ms','error'} or build not in {'sdds-legacy-teleport-diag-v4','sdds-legacy-teleport-codec-v5'}:
                raise web.HTTPBadRequest()
            try:
                press=int(values.get('press',0))
            except (ValueError,TypeError):raise web.HTTPBadRequest()
            if not 0<=press<=1000000000:raise web.HTTPBadRequest()
            extra={'reason':reason,'build':build,'press':press}
            for name in ('x','y','target_x','target_y'):
                if name in values:
                    try:value=int(values[name])
                    except (ValueError,TypeError):raise web.HTTPBadRequest()
                    if not -10000000<=value<=10000000:raise web.HTTPBadRequest()
                    extra[name]=value
            if 'alive' in values:
                if values['alive'] not in {'0','1'}:raise web.HTTPBadRequest()
                extra['alive']=values['alive']=='1'
        # These are observations from the authenticated client, not an
        # authoritative explanation supplied by the game server.
        for field,limit in [('message',1000),('nickname',60),('robot_status',220),('map',16),('client_id',80),('event_id',100),('build',80)]:
            if field in values:
                value=values[field]
                if not isinstance(value,str) or len(value)>max(limit*4,1000):raise web.HTTPBadRequest()
                extra[field]=sanitize(value,limit)
        if 'map' in extra and extra['map'] and not re.fullmatch(r'@[0-9]{1,12}',extra['map']):raise web.HTTPBadRequest()
        for flag in ('current_socket','main_connected'):
            if flag in values:
                if values[flag] not in {'0','1'}:raise web.HTTPBadRequest()
                extra[flag]=values[flag]=='1'
        event_id=extra.get('event_id','')
        if event_id and not re.fullmatch(r'[A-Za-z0-9_-]{1,100}',event_id):raise web.HTTPBadRequest()
        now=time.monotonic();key=(row['user_id'],'connection') if event in CONNECTION_EVENTS else ((row['user_id'],'teleport') if event=='teleport' else row['user_id']);rates=self.request.app['diagnostics_rate']
        seen=rates.setdefault(('connection_event_ids',),{})
        for old,stamp in list(seen.items()):
            if now-stamp>600:seen.pop(old,None)
        dedup=(row['user_id'],event_id)
        if event_id and dedup in seen:return web.json_response({'saved':True,'duplicate':True})
        if len(seen)>=4096:seen.pop(next(iter(seen)))
        start,count=rates.get(key,(now,0))
        if now-start>=60:start,count=now,0
        if count>=(120 if event=='teleport' or event in CONNECTION_EVENTS else 30):raise web.HTTPTooManyRequests()
        rates[key]=(start,count+1)
        record={'user_id':row['user_id'],'client_ip':self.request.remote,'time':datetime.now(timezone.utc).isoformat(),'event':event,'code':code,'channel':channel,'elapsed_ms':elapsed,'active_options':options}
        record.update(extra)
        folder=Path(self.request.app['root']).parent/'logs-client'
        if event in CONNECTION_EVENTS:
            record.update(reason_source='flash_event',game_server_reason=None)
            record['reason']={'socket_close':'connection_closed_without_game_reason','socket_disconnected':'connection_lost_without_close_event','io_error':'network_io_error','security_error':'flash_security_error'}[event]
            append_log(folder/'disconnects.jsonl',record)
        append_log(folder/'flash-diagnostics.jsonl',record)
        if event_id:seen[dedup]=now
        return web.json_response({'saved':True})
