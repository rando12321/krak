package disney {
 import flash.display.*;import flash.events.*;import flash.net.*;import flash.text.*;import flash.utils.*;import flash.external.ExternalInterface;
 public class RgbMouseTests {
  private static var count:int=0;
  private static function check(ok:Boolean,message:String):void{if(!ok)throw new Error(message);count++;}
  public static function run(display:MovieClip):void{try{
   var r:MovieClip=new MovieClip();display.addChild(r);var frames:int=0;var failNext:Boolean=false;
   r.loop_game=function(e:Event):void{frames++;if(failNext){failNext=false;throw new Error("Missing optional test property",1069);}};
   r.host_url="";r.access_token="TEST";r.tfmdisney={data:{flash_token:"FLASH"}};
   r.current_map_code="@123";r.auto_play=true;r.Interface={status_field:new TextField()};r.Interface.status_field.text="Robot ESPACIAL: ponto 3";
   var main:Socket=new Socket();var bulle:Socket=new Socket();
   r.Keys={socket_class:{main:{sock:main},room:{sock:bulle}},main_socket_instance:"main",bulle_socket_instance:"room",socket_name:"sock",player:"self",player_name:"nick"};r.tfm={self:{nick:"Self#0001"}};
   ConnectionDiagnostics.attach(r);
   var ready:Object=ConnectionDiagnostics.lastEvent(r);
   check(ready.event=="guard_ready" && ready.nickname=="Self#0001" && ready.map=="@123","startup metadata identifies local player and map");
   check(ready.options=="auto_play" && ready.robot_status.indexOf("ESPACIAL")>=0,"logs include active option and Robot state");
   check(!ready.hasOwnProperty("access_token") && !ready.hasOwnProperty("flash_token"),"credentials are excluded from diagnostic payload");
   main.dispatchEvent(new IOErrorEvent(IOErrorEvent.IO_ERROR,false,false,"Error #2031: Socket Error. URL: http://example.test/?access_token=SECRET",2031));
   var io:Object=ConnectionDiagnostics.lastEvent(r);
   check(io.event=="io_error" && io.channel=="main" && io.code==2031,"native IO event retains channel and observed error code");
   check(io.message.indexOf("SECRET")<0 && io.message.indexOf("http://")<0,"client redacts credential-bearing URLs before transport");
   bulle.dispatchEvent(new SecurityErrorEvent(SecurityErrorEvent.SECURITY_ERROR,false,false,"Error #2048: test security error",2048));
   var security:Object=ConnectionDiagnostics.lastEvent(r);
   check(security.channel=="bulle" && security.code==2048,"independent socket callbacks retain their own channel");
   r.Keys.socket_class.main={sock:new Socket()};main.dispatchEvent(new Event(Event.CLOSE));
   var closed:Object=ConnectionDiagnostics.lastEvent(r);
   check(closed.event=="socket_close" && closed.channel=="main" && closed.current_socket=="0","old socket close is distinguished from currently registered connection");
   check(closed.message=="" && !closed.hasOwnProperty("game_server_reason"),"socket close does not fabricate a game-server kick reason");
   check(closed.client_id==ready.client_id && closed.event_id!=ready.event_id,"session correlation is stable and event IDs are unique");
   failNext=true;r.stage.dispatchEvent(new Event(Event.ENTER_FRAME));
   check(ConnectionDiagnostics.lastEvent(r).event=="frame_error" && ConnectionDiagnostics.lastEvent(r).code==1069,"frame fault is recorded separately from network closure");
   r.stage.dispatchEvent(new Event(Event.ENTER_FRAME));check(frames>=2,"original frame function continues after a reported fault");
   check(!main.connected && !bulle.connected,"observer does not connect or replace native sockets");
   var pendingBefore:int=ConnectionDiagnostics.pending(r);r.access_token="";
   main.dispatchEvent(new IOErrorEvent(IOErrorEvent.IO_ERROR,false,false,"Error #2032: unauthenticated fixture event",2032));
   check(ConnectionDiagnostics.pending(r)==pendingBefore,"unauthenticated event cannot be queued under a later account");r.access_token="TEST";
   var tries:int=0;
   var poll:Function=function():void{
    var loader:URLLoader=new URLLoader();
    loader.addEventListener(Event.COMPLETE,function(e:Event):void{try{
     var events:Array=com.adobe.serialization.json.JSON.decode(String(loader.data)) as Array;
     if(events.length<5 || ConnectionDiagnostics.pending(r)>0){if(++tries>30)throw new Error("diagnostic HTTP queue did not flush");setTimeout(poll,100);return;}
     var foundIO:Boolean=false;var foundClose:Boolean=false;var foundFrame:Boolean=false;
     for each(var record:Object in events){
      if(record.client_id!=ready.client_id)continue;
      if(record.event=="io_error")foundIO=record.code=="2031" && String(record.message).indexOf("SECRET")<0;
      if(record.event=="socket_close")foundClose=record.current_socket=="0";
      if(record.event=="frame_error")foundFrame=record.code=="1069";
     }
     check(foundIO && foundClose && foundFrame,"native diagnostic queue delivers typed events through authenticated HTTP");
     check(ConnectionDiagnostics.pending(r)==0,"successful requests release pending events");
     ExternalInterface.call("recordTest","PASS: "+count+" connection observer, redaction and HTTP transport checks");
    }catch(error:Error){ExternalInterface.call("recordTest","FAIL: connection "+error.message+" #"+error.errorID);}});
    loader.addEventListener(IOErrorEvent.IO_ERROR,function(e:IOErrorEvent):void{ExternalInterface.call("recordTest","FAIL: connection fixture HTTP unavailable");});
    loader.load(new URLRequest("diagnostics-fixture"));
   };setTimeout(poll,200);
  }catch(error:Error){ExternalInterface.call("recordTest","FAIL: connection "+error.message+" #"+error.errorID);}}
 }
}
