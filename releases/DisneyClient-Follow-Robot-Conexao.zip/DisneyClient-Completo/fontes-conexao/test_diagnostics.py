"""Authenticated diagnostics tests with a temporary log directory and HTTP server."""
import importlib.util
import json
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch
from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer

ROOT = Path(__file__).resolve().parents[1]
package = types.ModuleType('diagnostic_test_api')
package.__path__ = [str(ROOT / 'DisneyClient/api')]
sys.modules[package.__name__] = package
spec = importlib.util.spec_from_file_location('diagnostic_test_api.diagnostics', ROOT / 'DisneyClient/api/diagnostics.py')
diagnostics = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = diagnostics
spec.loader.exec_module(diagnostics)


class DiagnosticsTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name) / 'DisneyClient'
        self.root.mkdir()

        @web.middleware
        async def remote(request, handler):
            return await handler(request.clone(remote='198.51.100.23'))

        async def auth(request):
            token = request.query.get('access_token')
            if token not in {'TEST7', 'TEST8'}:
                raise web.HTTPUnauthorized()
            return {'user_id': int(token[-1])}

        self.auth = patch.object(diagnostics, 'authorize', auth)
        self.auth.start()
        self.app = web.Application(middlewares=[remote])
        self.app['root'] = self.root
        self.app['diagnostics_rate'] = {}
        self.app.router.add_view('/client_diagnostics', diagnostics.Diagnostics)
        self.client = TestClient(TestServer(self.app))
        await self.client.start_server()

    async def asyncTearDown(self):
        await self.client.close()
        self.auth.stop()
        self.tmp.cleanup()

    async def post(self, **values):
        data = {'event': 'socket_close', 'channel': 'main', 'code': '0', 'elapsed': '100', 'options': 'auto_play', 'event_id': 'session_1'}
        data.update(values)
        return await self.client.post('/client_diagnostics?access_token=TEST7', data=data)

    def records(self, name='disconnects.jsonl'):
        path = self.root.parent / 'logs-client' / name
        return [json.loads(line) for line in path.read_text().splitlines()] if path.exists() else []

    async def test_remote_authenticated_client_is_logged(self):
        response = await self.post(nickname='Self#0001', map='@123', current_socket='1')
        self.assertEqual(response.status, 200)
        record = self.records()[0]
        self.assertEqual(record['user_id'], 7)
        self.assertEqual(record['client_ip'], '198.51.100.23')
        self.assertEqual(record['nickname'], 'Self#0001')
        self.assertEqual(record['map'], '@123')

    async def test_no_auth_cannot_write_logs(self):
        response = await self.client.post('/client_diagnostics', data={'event': 'socket_close', 'channel': 'main'})
        self.assertEqual(response.status, 401)
        self.assertFalse(self.records())

    async def test_close_does_not_invent_game_kick_reason(self):
        await self.post()
        record = self.records()[0]
        self.assertEqual(record['reason'], 'connection_closed_without_game_reason')
        self.assertIsNone(record['game_server_reason'])
        self.assertEqual(record['reason_source'], 'flash_event')

    async def test_network_error_keeps_observed_code_and_message(self):
        response = await self.post(event='io_error', code='2031', message='Error #2031: Socket Error.')
        self.assertEqual(response.status, 200)
        record = self.records()[0]
        self.assertEqual(record['code'], 2031)
        self.assertEqual(record['reason'], 'network_io_error')
        self.assertEqual(record['message'], 'Error #2031: Socket Error.')

    async def test_poll_disconnect_is_supported(self):
        response = await self.post(event='socket_disconnected')
        self.assertEqual(response.status, 200)
        self.assertEqual(self.records()[0]['reason'], 'connection_lost_without_close_event')

    async def test_replaced_socket_is_distinguished(self):
        await self.post(channel='bulle', current_socket='0', main_connected='1')
        record = self.records()[0]
        self.assertFalse(record['current_socket'])
        self.assertTrue(record['main_connected'])
        self.assertEqual(record['channel'], 'bulle')

    async def test_credentials_and_urls_are_redacted(self):
        await self.post(message='URL http://example.test/?access_token=SECRET password=HIDDEN\nError #2031', robot_status='flash_token=PRIVATE')
        text = json.dumps(self.records())
        for secret in ('SECRET', 'HIDDEN', 'PRIVATE', 'http://example.test'):
            self.assertNotIn(secret, text)
        self.assertIn('[redacted]', text)

    async def test_event_retry_is_deduplicated(self):
        await self.post()
        response = await self.post()
        self.assertTrue((await response.json())['duplicate'])
        self.assertEqual(len(self.records()), 1)
        self.assertEqual(len(self.records('flash-diagnostics.jsonl')), 1)

    async def test_event_ids_are_scoped_to_authenticated_user(self):
        await self.post(user_id='999')
        await self.client.post('/client_diagnostics?access_token=TEST8', data={'event': 'socket_close', 'channel': 'main', 'event_id': 'session_1'})
        self.assertEqual([record['user_id'] for record in self.records()], [7, 8])

    async def test_frame_error_is_not_classified_as_disconnect(self):
        response = await self.post(event='frame_error', channel='client', code='1069', message='Missing native property')
        self.assertEqual(response.status, 200)
        self.assertFalse(self.records())
        self.assertEqual(self.records('flash-diagnostics.jsonl')[0]['code'], 1069)

    async def test_old_guard_payload_remains_compatible(self):
        response = await self.client.post('/client_diagnostics?access_token=TEST7', data={'event': 'guard_ready', 'channel': 'client', 'code': '0', 'elapsed': '10', 'options': ''})
        self.assertEqual(response.status, 200)
        self.assertEqual(self.records('flash-diagnostics.jsonl')[0]['event'], 'guard_ready')

    async def test_invalid_metadata_is_rejected(self):
        for values in ({'event': 'invented_kick'}, {'channel': '../main'}, {'code': '999999'}, {'map': '../../private'}, {'current_socket': 'yes'}, {'event_id': '../file'}, {'options': 'unrecognized'}):
            response = await self.post(**values)
            self.assertEqual(response.status, 400, values)
        self.assertFalse(self.records())

    async def test_payload_limit(self):
        response = await self.post(message='x' * 20000)
        self.assertEqual(response.status, 413)

    async def test_rate_limit_keeps_log_bounded(self):
        for index in range(120):
            response = await self.post(event_id='rate_' + str(index))
            self.assertEqual(response.status, 200)
        self.assertEqual((await self.post(event_id='rate_over')).status, 429)
        self.assertEqual(len(self.records()), 120)

    async def test_rotation_preserves_previous_log(self):
        target = self.root.parent / 'logs-client' / 'disconnects.jsonl'
        target.parent.mkdir()
        target.write_bytes(b'x' * (5 * 1024 * 1024 + 1))
        await self.post()
        self.assertTrue(target.with_name('disconnects.previous.jsonl').is_file())
        self.assertEqual(len(self.records()), 1)


if __name__ == '__main__':
    unittest.main()
