package disney {
 import flash.display.MovieClip;
 import flash.events.*;
 import flash.net.*;
 import flash.text.*;
 import flash.utils.*;

 // Observes existing sockets only. Never closes, delays, replaces or writes them.
 public class ConnectionDiagnostics {
  private static var instances:Dictionary=new Dictionary(true);
  private var root:MovieClip;
  private var status:TextField;
  private var seen:Dictionary=new Dictionary(true);
  private var channels:Object={};
  private var faults:Object={};
  private var queue:Array=[];
  private var loader:URLLoader;
  private var sentAt:int=0;
  private var scanAt:int=0;
  private var counter:uint=0;
  private var client:String;
  private var last:Object;
  public function ConnectionDiagnostics(value:MovieClip){root=value;client="flash_"+getTimer()+"_"+uint(Math.random()*4294967295).toString(16);}
  private static function read(o:Object,key:*):*{try{if(o && key!=null && key in o)return o[key];}catch(ignored:Error){}return null;}
  public static function lastEvent(value:MovieClip):Object{var d:ConnectionDiagnostics=instances[value] as ConnectionDiagnostics;return d ? d.last : null;}
  public static function pending(value:MovieClip):int{var d:ConnectionDiagnostics=instances[value] as ConnectionDiagnostics;return d ? d.queue.length : 0;}
  public static function attach(value:MovieClip):void{
   if(!value || !value.stage || instances[value])return;
   var d:ConnectionDiagnostics=new ConnectionDiagnostics(value);instances[value]=d;
   d.status=new TextField();d.status.name="sddsConnectionStatus";
   d.status.defaultTextFormat=new TextFormat("_sans",11,0xD5E2F4);d.status.background=true;d.status.backgroundColor=0x182235;d.status.height=24;d.status.selectable=true;d.status.mouseEnabled=false;
   d.status.text="Rede nativa | logs de conexao na VPS";value.stage.addChild(d.status);d.fit();
   value.stage.addEventListener(Event.RESIZE,function(e:Event):void{d.fit();});
   var nativeLoop:Function=read(value,"loop_game") as Function;
   if(nativeLoop!=null)value.stage.removeEventListener(Event.ENTER_FRAME,nativeLoop);
   value.stage.addEventListener(Event.ENTER_FRAME,function(e:Event):void{
    try{if(nativeLoop!=null)nativeLoop.apply(value,[e]);}
    catch(error:Error){
     d.status.text="Falha do client #"+error.errorID+" | "+String(error.message).substr(0,180);
     var now:int=getTimer();var key:String=String(error.errorID);
     if(!(key in d.faults) || now-Number(d.faults[key])>=30000){d.faults[key]=now;d.report("frame_error",error.errorID,"client",error.message,false);}
    }
    d.tick();
   });
   d.scan();d.report("guard_ready",0,"client","",false);
  }
  private function fit():void{if(!root.stage)return;status.x=8;status.y=Math.max(40,root.stage.stageHeight-28);status.width=Math.max(240,root.stage.stageWidth-16);}
  private function auth():String{
   var settings:Object=read(root,"tfmdisney");var data:Object=read(settings,"data");
   var access:* =read(root,"access_token");var flash:* =read(data,"flash_token");
   if(!access || !flash)return "";
   return "access_token="+encodeURIComponent(String(access))+"&flash_token="+encodeURIComponent(String(flash));
  }
  private static function clean(value:String):String{
   value=String(value || "");
   value=value.replace(/https?:\/\/[^\s<>]+/gi,"[url]");
   return value.replace(/((?:access_token|flash_token|password|authorization)\s*[:=]\s*)[^\s,;]+/gi,"$1[redacted]");
  }
  private function nativeSocket(channel:String):Socket{
   var k:Object=read(root,"Keys");var cls:Object=read(k,"socket_class");
   var wrapper:Object=read(cls,read(k,channel=="main" ? "main_socket_instance" : "bulle_socket_instance"));
   if(wrapper is Socket)return wrapper as Socket;
   var actual:Object=read(wrapper,read(k,"socket_name"));
   return actual is Socket ? actual as Socket : channels[channel] as Socket;
  }
  private function report(kind:String,code:int,channel:String,message:String,current:Boolean):void{
   var options:Array=[];
   for each(var name:String in ["auto_play","recording","change_jump_delay","change_jump_height","change_jump_speed","change_movement_speed","mass_reduction","insta_death","insta_win","no_delay","no_bulle","soft_mode","macro"])if(read(root,name))options.push(name);
   var ui:Object=read(root,"Interface");var field:Object=read(ui,"status_field");
   var map:String=String(read(root,"current_map_code") || "");if(!/^@[0-9]{1,12}$/.test(map))map="";
   var k:Object=read(root,"Keys");var player:Object=read(read(root,"tfm"),read(k,"player"));
   var nickname:String=clean(String(read(player,read(k,"player_name")) || "")).substr(0,60);
   var payload:Object={nickname:nickname,event:kind,code:code,channel:channel,elapsed:getTimer(),options:options.join(","),client_id:client,event_id:client+"_"+(++counter),build:"native-diagnostics-v2",map:map,robot_status:clean(String(read(field,"text") || "")).substr(0,220),message:clean(message).substr(0,1000),current_socket:current ? "1" : "0"};
   var main:Socket=nativeSocket("main");payload.main_connected=main && main.connected ? "1" : "0";
   last=payload;
   // A connection event without a session must not be attributed to a future login.
   if(auth()=="" && kind!="guard_ready")return;
   if(queue.length>=16)queue.splice(loader ? 1 : 0,1);
   queue.push({payload:payload,attempts:0,retry:0,auth:auth()});pump();
  }
  private function finish(current:URLLoader,success:Boolean,statusCode:int):void{
   if(loader!==current)return;loader=null;
   if(queue.length){
    var item:Object=queue[0];
    if(success || statusCode==401 || statusCode==403 || item.attempts>=3)queue.shift();
    else item.retry=getTimer()+(statusCode==429 ? 30000 : 5000);
   }
  }
  private function pump():void{
   if(loader || !queue.length)return;
   var item:Object=queue[0];if(getTimer()<Number(item.retry))return;
   var credentials:String=String(item.auth || "");if(credentials=="")credentials=auth();if(credentials=="")return;
   // Retry under the original session identity; never assign its event to a new login.
   item.auth=credentials;item.attempts++;
   var variables:URLVariables=new URLVariables();for(var key:String in item.payload)variables[key]=item.payload[key];
   var host:String=String(read(root,"host_url") || "");if(host!="" && host.charAt(host.length-1)!="/")host+="/";
   var request:URLRequest=new URLRequest(host+"client_diagnostics?"+credentials);request.method=URLRequestMethod.POST;request.data=variables;
   var current:URLLoader=new URLLoader();loader=current;sentAt=getTimer();var statusCode:int=0;
   current.addEventListener(HTTPStatusEvent.HTTP_STATUS,function(e:HTTPStatusEvent):void{statusCode=e.status;});
   current.addEventListener(Event.COMPLETE,function(e:Event):void{finish(current,statusCode<400,statusCode);});
   var fail:Function=function(e:Event):void{finish(current,false,statusCode);};
   current.addEventListener(IOErrorEvent.IO_ERROR,fail);current.addEventListener(SecurityErrorEvent.SECURITY_ERROR,fail);
   try{current.load(request);}catch(ignored:Error){finish(current,false,statusCode);}
  }
  private function errorCode(e:Event):int{
   var value:* =read(e,"errorID");if(value!=null)return int(value);
   var match:Object=/#([0-9]+)/.exec(String(read(e,"text") || ""));return match ? int(match[1]) : 0;
  }
  private function bind(socket:Socket,channel:String):void{
   channels[channel]=socket;if(seen[socket])return;
   var state:Object={was:socket.connected,closed:false,channel:channel};seen[socket]=state;
   socket.addEventListener(Event.CONNECT,function(e:Event):void{state.was=true;state.closed=false;});
   socket.addEventListener(Event.CLOSE,function(e:Event):void{
    state.closed=true;status.text="Socket "+channel+" encerrado | motivo nao informado pelo jogo";
    report("socket_close",0,channel,"",nativeSocket(channel)===socket);
   });
   socket.addEventListener(IOErrorEvent.IO_ERROR,function(e:IOErrorEvent):void{
    status.text="Erro de rede "+channel+" #"+errorCode(e);report("io_error",errorCode(e),channel,e.text,nativeSocket(channel)===socket);
   });
   socket.addEventListener(SecurityErrorEvent.SECURITY_ERROR,function(e:SecurityErrorEvent):void{
    status.text="Erro de seguranca "+channel+" #"+errorCode(e);report("security_error",errorCode(e),channel,e.text,nativeSocket(channel)===socket);
   });
  }
  private function observe(wrapper:Object,channel:String,k:Object):void{
   if(!wrapper)return;
   if(wrapper is Socket){bind(wrapper as Socket,channel);return;}
   var direct:Object=read(wrapper,read(k,"socket_name"));
   if(direct is Socket){bind(direct as Socket,channel);return;}
   try{
    var description:XML=describeType(wrapper);
    for each(var variable:XML in description.variable){var value:Object=read(wrapper,String(variable.@name));if(value is Socket)bind(value as Socket,channel);}
    for each(var accessor:XML in description.accessor){if(String(accessor.@access)=="writeonly")continue;value=read(wrapper,String(accessor.@name));if(value is Socket)bind(value as Socket,channel);}
   }catch(ignored:Error){}
  }
  private function scan():void{
   var k:Object=read(root,"Keys");var cls:Object=read(k,"socket_class");
   observe(read(cls,read(k,"main_socket_instance")),"main",k);observe(read(cls,read(k,"bulle_socket_instance")),"bulle",k);
   for(var socket:Object in seen){var state:Object=seen[socket];var nativeSocket:Socket=socket as Socket;
    if(state.was && !nativeSocket.connected && !state.closed){state.closed=true;report("socket_disconnected",0,state.channel,"",this.nativeSocket(state.channel)===nativeSocket);}
    state.was=nativeSocket.connected;
   }
  }
  private function tick():void{
   var now:int=getTimer();if(now>=scanAt){scanAt=now+1000;try{scan();}catch(ignored:Error){}}
   if(loader && now-sentAt>15000){var old:URLLoader=loader;try{old.close();}catch(ignoredClose:Error){}finish(old,false,0);}
   pump();
  }
 }
}
