@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 goto usar_py
where python >nul 2>nul
if not errorlevel 1 goto usar_python
echo Instale Python 3.11 ou superior e abra este arquivo novamente.
pause
exit /b 1
:usar_py
py -3 "%~dp0extrair_e_iniciar.py" %*
goto resultado
:usar_python
python "%~dp0extrair_e_iniciar.py" %*
:resultado
if errorlevel 1 (
    echo.
    echo O client nao iniciou. Leia a mensagem acima.
    pause
    exit /b 1
)
exit /b 0
