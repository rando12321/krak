"""Read-only evidence from supplied routes; never changes maps or the game."""
import argparse, collections, hashlib, json, statistics
from pathlib import Path


def signed16(value):
    return ((int(value) + 32768) % 65536 - 32768) / 100


def signed32(value):
    return (int(value) + 2147483648) % 4294967296 - 2147483648


def summary(values):
    values = sorted(values)
    if not values:
        return {"samples": 0}
    return {"samples": len(values), "p10": values[int((len(values)-1)*.1)],
            "median": statistics.median(values), "p90": values[int((len(values)-1)*.9)]}


def analyze(path):
    raw = path.read_bytes()
    routes = json.loads(raw)
    counts = collections.Counter()
    gravity, travel_ratios, padding = [], [], []
    for code, route in routes.items():
        previous = None
        time = 0
        last_walk = None
        extra = 0
        for row in route:
            time += row[-1]
            counts['source_steps'] += 1
            if row[-2] != 'walk':
                continue
            p = row[0]
            counts['walks'] += 1
            counts['walks_with_positive_delay_below_33ms'] += 0 < row[-1] < 33
            counts['walks_with_zero_delay'] += row[-1] == 0
            if previous:
                a, before = previous
                dt = (time-before)/1000
                vx0, vx1 = signed16(a['vx']), signed16(p['vx'])
                vy0, vy1 = signed16(a['vy']), signed16(p['vy'])
                counts['horizontal_flag_changes'] += (p['ml'],p['mr']) != (a['ml'],a['mr'])
                counts['flag_opposes_current_velocity'] += p['ml'] != p['mr'] and abs(vx1) > .5 and ((p['mr'] and vx1 < 0) or (p['ml'] and vx1 > 0))
                if .03 < dt < .5:
                    dx = (signed32(p['x'])-signed32(a['x']))*.3
                    dy = (signed32(p['y'])-signed32(a['y']))*.3
                    if vy1 > vy0 and abs(dy-30*(vy0+vy1)*.5*dt) < max(2,abs(dy)*.1):
                        g = (vy1-vy0)/dt
                        if 4 < g < 20:
                            gravity.append(g)
                    if abs(vx0-vx1) < .1 and abs(vx0) > .2 and abs(dx) > 1 and dx*vx0 > 0:
                        travel_ratios.append(dx/(vx0*30*dt))
            previous = p,time
        # The historical minimum was applied to walk consumption, not wire packets.
        time = 0
        for row in route:
            time += row[-1]
            if row[-2] == 'walk':
                if last_walk is not None:
                    extra += max(0,33-(time-last_walk))
                last_walk = time
            if row[-2] == 'hole':
                break
        padding.append((extra,code))
    amounts = sorted(value for value,_ in padding)
    first_six = routes['@298424'][:6]
    times, total = [], 0
    for row in first_six:
        total += row[-1]
        times.append(total)
    a,b = first_six[4][0],first_six[5][0]
    distance = abs((signed32(b['x'])-signed32(a['x']))*.3)
    wrong_speed = (abs(signed16(a['vx']))+abs(signed16(b['vx'])))*15
    return {'route_library_sha256': hashlib.sha256(raw).hexdigest(), 'maps': len(routes),
            'counts': dict(counts), 'gravity_from_consistent_ballistic_pairs_m_s2': summary(gravity),
            'distance_over_velocity_times_recorded_seconds': summary(travel_ratios),
            'historical_33ms_padding_ms': {'median': statistics.median(amounts),
                'p95': amounts[int(len(amounts)*.95)], 'maximum': max(padding),
                'map_298424': next(value for value,code in padding if code=='@298424'),
                'interpretation': 'theoretical extra time from minimum walk spacing, excluding rendering/network effects'},
            'map_298424': {'first_six_source_deadlines_ms': times,
                'sixth_segment_recorded_ms': first_six[5][-1],
                'wrong_endpoint_average_conversion_ms': distance/wrong_speed*1000,
                'reason_not_to_use_endpoint_average': 'collision/impulse endpoint speed does not represent cruise velocity'},
            'limits': 'Recorded remote-state packets are not a complete input log; geometry, collisions, wind, gravity modifiers and network jitter are not fully invertible.'}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('routes',nargs='?',type=Path,default=Path(__file__).resolve().parents[1]/'DisneyClient/public/rotas_decodificadas.json')
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    text=json.dumps(analyze(args.routes),ensure_ascii=False,indent=2)+'\n'
    if args.output:
        args.output.write_text(text)
    else:
        print(text,end='')


if __name__=='__main__':
    main()
