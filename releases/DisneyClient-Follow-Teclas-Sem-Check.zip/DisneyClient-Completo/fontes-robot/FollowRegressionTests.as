package disney {
 import flash.display.MovieClip;import flash.events.KeyboardEvent;import flash.utils.ByteArray;import flash.external.ExternalInterface;import flash.text.TextField;import flash.geom.Point;
 public class RgbMouseTests {
  private static var count:int=0;
  private static function check(ok:Boolean,name:String):void{if(!ok)throw new Error(name);count++;}
  public static function run(display:MovieClip):void{
   var result:String;
   try{
    var root:MovieClip=new MovieClip();display.addChild(root);root.stage.focus=root.stage;var inputs:Object={};var writes:int=0;var packets:int=0;
    root.stage.addEventListener(KeyboardEvent.KEY_DOWN,function(e:KeyboardEvent):void{inputs[e.keyCode]=true;});root.stage.addEventListener(KeyboardEvent.KEY_UP,function(e:KeyboardEvent):void{inputs[e.keyCode]=false;});
    var body:Object={velocity:{vx:1.25,vy:-0.75},place:function(p:Point,a:Number):Boolean{writes++;throw new Error("forbidden position write");}};
    var local:Object={nick:"Self#0001",x:20,y:30,body:body,clip:true,dead:false,left:false,right:false,down:false,side:false,jump:function(...args):void{},crouch:function(...args):void{},stand:function(...args):void{}};
    var target:Object={nick:"Target#0000",x:345,y:180,body:{},clip:true,dead:false,jumpActive:false,left:false,right:true};
    root.Keys={player:"self",player_list:"players",player_name:"nick",player_physics:"body",player_clip:"clip",is_dead:"dead",is_jumping:"jumpActive",player_moving_left:"left",player_moving_right:"right",jump:"jump",is_down:"down",crouch:"crouch",crouch2:"stand",static_side:"side",bot_set_position:"place",app_domain:{applicationDomain:{getDefinition:function(name:String):Class{return Point;}}},b2vec2:"Point",packet_handler_class:{receive:function(bytes:ByteArray):void{packets++;throw new Error("forbidden teleport packet");}},packet_handler:"receive",map_class:{current:{number:{code:123}}},map_instance:"current",bot_map_code_object:"number",bot_map_code_value:"code"};
    root.tfm={self:local,players:[target]};root.Interface={};root.auto_play=true;root.current_round_code=1;
    var motion:NativeMotion=NativeMotion.get(root);var owner:Object={};motion.place(owner,999,888);check(writes==0 && local.x==20 && local.y==30,"compatibility place cannot reposition player or body");motion.synchronizeCurrent();check(packets==0,"compatibility sync cannot send a teleport packet");motion.followSample(owner,false,true,true,500,600);check(inputs[39] && inputs[38],"shared Follow path still emits native movement and jump keys");check(local.x==20 && local.y==30 && writes==0,"shared Follow sample does not copy target coordinates");check(body.velocity.vx==1.25 && body.velocity.vy==-0.75,"native driver does not overwrite velocity");motion.release(owner);check(!inputs[39] && !inputs[38],"release still clears native keys");
    var follow:FollowControllerV13Shared=new FollowControllerV13Shared(root);check(follow.command("/follow Target#0000"),"Follow command remains available");follow.update(0);check(inputs[39] && !inputs[37],"Follow steers toward a target using keys");check(writes==0 && packets==0 && local.x==20 && local.y==30,"initial Follow acquisition sends no position write or teleport packet");
    target.x=-100;target.jumpActive=true;target.right=false;target.left=true;follow.update(20);check(inputs[37] && !inputs[39] && inputs[38],"direction change and jump still follow the target");check(local.x==20 && local.y==30 && writes==0,"live target changes never snap local coordinates");
    root.Keys.map_class.current={number:{code:124}};follow.update(40);check(packets==0 && writes==0,"round change does not resynchronize by teleport");
    local.body=null;follow.update(60);check(!inputs[37] && !inputs[38],"unavailable body releases native input");local.body=body;follow.update(80);check(inputs[37] && packets==0 && writes==0,"respawn reacquires with keys rather than teleport");
    delete root.Keys.packet_handler_class;delete root.Keys.packet_handler;root.Keys.map_class.current={number:{code:125}};follow.update(100);check(inputs[37],"Follow no longer requires teleport packet mappings");
    var field:TextField=new TextField();field.type="input";root.addChild(field);root.stage.focus=field;follow.update(120);check(!inputs[37] && !inputs[38],"chat focus still releases input");root.stage.focus=root.stage;
    follow.command("/follow off");follow.update(140);check(writes==0 && packets==0 && !inputs[37] && !inputs[39] && !inputs[38],"turning Follow off preserves position and releases keys");
    result="PASS: "+count+" no-teleport/native-key assertions";
   }catch(error:Error){result="FAIL: "+error.message+" #"+error.errorID;}
   trace(result);ExternalInterface.call("recordTest",result);
  }
 }
}
