# Robot por teclas e linha do tempo absoluta

O executor nao le a posicao ou velocidade do jogador atual. Nao existe check de
chegada, espera por coordenadas ou teleporte de correcao. As fontes do controle
por chegada e do minimo artificial de 33ms foram removidas.

Fonte canonica: fontes-autoplay/RoutePlayer.as. RoutePlayerNative.as e gerada.
RouteKeyTimeline.as compila os prazos e as teclas usando dados gravados.
NativeMotion.movement continua sendo o caminho de teclas internas do jogo.

Leia ../TECLAS-SEM-CHECK-LEIA-ME.txt, ../ESTUDO-FISICA-E-TEMPO.md e
../VALIDACAO-TECLAS-SEM-CHECK.json. Relatorios anteriores sao historicos.

Build: python fontes-robot/build.py --ffdec /caminho/ffdec
Teste: RUFFLE_DIR=/caminho/ruffle node fontes-robot/run_tests.cjs
Analise: python fontes-robot/analyze_recorded_physics.py
Requer Java 21, FFDec 26.4.0, Node/Playwright, Chromium e Ruffle 0.7.1.
