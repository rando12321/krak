package disney {
 import flash.display.MovieClip;import flash.events.*;import flash.text.TextField;import flash.external.ExternalInterface;import flash.utils.*;import flash.net.*;
 public class RgbMouseTests {
  private static var count:int=0;
  private static function check(ok:Boolean,text:String):void{if(!ok)throw new Error(text);count++;}
  private static function walk(delay:int,l:Boolean=false,r:Boolean=true,j:Boolean=false,vx:int=345,vy:int=0,x:Number=100,y:Number=1102,frame:int=0):Array{return [{x:x,y:y,vx:vx,vy:vy,mr:r,ml:l,jump:j,frame:frame},"walk",delay];}
  private static function fixture(display:MovieClip,route:Array):Object{
   var root:MovieClip=new MovieClip();display.addChild(root);root.stage.focus=root.stage;
   var player:NoPositionMouse=new NoPositionMouse();var keys:Array=[];var map:Object={number:{value:123},container:{reverse:false}};
   root.Keys={player:"mouse",player_id:"id",player_physics:"body",player_clip:"clip",is_dead:"dead",player_moving_left:"left",player_moving_right:"right",jump:"jump",is_down:"down",crouch:"crouch",crouch2:"stand",static_side:"side",map_class:{current:map},map_instance:"current",bot_map_code_object:"number",bot_map_code_value:"value",obj_container:"container",bot_reverse:"reverse",move_class:{free:true},move_free:"free",timer_class:{locked:false},timer_prop:"locked"};
   root.tfm={mouse:player};root.Interface={status_field:new TextField()};root.host_url="";root.auto_play=true;root.auto_play_disable_on_move=true;root.current_round_code=1;
   root.stage.addEventListener(KeyboardEvent.KEY_DOWN,function(e:KeyboardEvent):void{if(NativeMotion.isSynthetic(root))keys.push({code:e.keyCode,down:true,at:getTimer()});});
   root.stage.addEventListener(KeyboardEvent.KEY_UP,function(e:KeyboardEvent):void{if(NativeMotion.isSynthetic(root))keys.push({code:e.keyCode,down:false,at:getTimer()});});
   var bot:RoutePlayerNative=new RoutePlayerNative(root);bot.setRoutes({"@123":route});bot.setTiming(new RouteTiming(1,true));
   return {root:root,player:player,bot:bot,keys:keys,map:map};
  }
  private static function stop(f:Object,now:int):void{f.root.auto_play=false;f.bot.advance(now);}
  private static function downs(f:Object,code:int):int{var n:int=0;for each(var e:Object in f.keys)if(e.code==code && e.down)n++;return n;}
  public static function run(display:MovieClip):void{try{
   check(RouteKeyTimeline.signed16(65191)==-3.45 && RouteKeyTimeline.signed16(65036)==-5,"unsigned wire VX/VY decode into signed physical units");
   check(RouteKeyTimeline.signed16(65535)==RouteKeyTimeline.signed16(-1),"signed and unsigned recordings decode identically");
   var decoded:Object=RoutePlayerNative.decodeMovement(walk(0,false,true,false,65191,65036,4294967295)[0]);check(Math.abs(decoded.x+0.3)<0.000001 && decoded.vx==-3.45,"int32 position wrap remains record-only decoding");
   var f:Object=fixture(display,[walk(100),walk(10,true,false,true,65191,65036),walk(5,true,false,true,65191,65041),walk(5,false,false,false),["hole",80]]);
   f.bot.advance(0);check(f.bot.nextDeadline==100 && f.keys.length==0,"first recorded delay is preserved without extra 250ms startup wait");
   f.bot.advance(99);check(f.keys.length==0,"first input never fires before its absolute deadline");f.bot.advance(100);check(f.player.right && f.bot.completedSourceSteps==1,"first key state fires at 100ms without reading live position");
   var held:int=f.keys.length;f.bot.advance(105);check(f.keys.length==held,"held native keys are not repeated on every frame");
   f.bot.advance(110);check(f.player.left && !f.player.right && downs(f,38)==1,"LEFT plus UP fires after 10ms rather than being delayed to a 33ms minimum");
   check(f.bot.nextDeadline==115 && f.bot.completedSourceSteps==2,"next deadline stays anchored to the original epoch");held=f.keys.length;f.bot.advance(115);check(f.keys.length==held && f.bot.completedSourceSteps==3,"same held state consumes its sample without extra key events");
   f.bot.advance(120);check(!f.player.left && !f.player.right && f.bot.nextDeadline==200,"5ms neutral transition and original terminal deadline are preserved");
   f.bot.advance(200);check(f.bot.message.indexOf("confirmacao")>=0,"terminal marker releases keys and waits for native victory");check(f.player.reads==0 && f.player.writes==0,"executor never reads or writes live x/y even with deliberately throwing accessors");check(f.player.body.reads==0 && f.player.body.writes==0,"executor never reads or writes live body velocity or position");stop(f,201);
   var dense:Array=[];for(var i:int=0;i<100;i++)dense.push(walk(10,i%2==1,i%2==0));dense.push(["hole",100]);
   f=fixture(display,dense);f.bot.advance(0);
   for(var tick:int=17;tick<1000;tick+=17){f.bot.advance(tick);var expected:int=Math.min(100,int(tick/10));check(f.bot.completedSourceSteps==expected,"late frames process every due source sample in order");check(f.bot.nextDeadline==(expected<100 ? (expected+1)*10 : 1100),"frame lateness never moves the next absolute deadline");}
   f.bot.advance(1001);check(f.bot.completedSourceSteps==100 && f.bot.nextDeadline==1100,"100 sub33ms samples finish without accumulated artificial drift");check(f.bot.maximumLateness<=16,"irregular 17ms update cadence has bounded per-event lateness, not cumulative drift");f.bot.advance(1099);check(f.bot.message.indexOf("confirmacao")<0,"terminal timer remains on the source clock");f.bot.advance(1100);check(f.bot.message.indexOf("confirmacao")>=0,"terminal deadline remains exactly 1100ms");stop(f,1101);
   f=fixture(display,[walk(0,true,false,false,345),walk(100,false,true,false,65191),["hole",100]]);f.bot.advance(0);check(f.player.left,"LEFT flag is preserved even while VX is still positive");f.bot.advance(100);check(f.player.right,"RIGHT flag is preserved while VX is negative during braking");stop(f,101);
   f=fixture(display,[walk(0,true,false),["hole",100]]);f.map.container.reverse=true;f.bot.advance(0);check(f.player.right && !f.player.left,"mirrored map reverses keys rather than coordinates");stop(f,1);
   f=fixture(display,[walk(0,true,false),["hole",100]]);f.map.container.reverse=true;f.bot.setWorldSpace(true);f.bot.advance(0);check(f.player.left && !f.player.right,"world-space AutoBest recording is not mirrored twice");stop(f,1);
   f=fixture(display,[walk(100,false,true,true,345,65036,100,1102,1),walk(300,false,true,true,345,65036,200,1102,2),walk(100,false,true,false),["hole",100]]);f.bot.advance(0);f.bot.advance(100);f.bot.advance(400);check(downs(f,38)==2,"fresh VY impulse while jump remains true generates a new native UP edge");held=f.keys.length;f.bot.advance(401);check(f.keys.length==held,"a reconstructed impulse is not repeated on subsequent frames");stop(f,402);
   var delayed:Array=[walk(0,false,true,false,345,0,1000,1000),walk(200,false,true,true,345,65236,1069,920),["hole",100]];
   var p:Object=RouteKeyTimeline.build(RoutePlayerNative.validate(delayed));check(p.inferredJumps==1 && p.groups[0].at==0 && p.groups[0].jumpImpulse,"late rising sample reconstructs takeoff from VY/gravity instead of firing UP late");
   f=fixture(display,delayed);f.bot.advance(0);check(downs(f,38)==1 && f.player.right,"reconstructed takeoff preserves simultaneous horizontal direction");stop(f,1);
   var discontinuous:Array=[walk(0,false,true,false,345,0,1000,1000),walk(200,false,true,true,345,65236,1069,500),["hole",100]];p=RouteKeyTimeline.build(RoutePlayerNative.validate(discontinuous));check(p.inferredJumps==0,"inconsistent height does not cause a guessed early takeoff");
   f=fixture(display,[walk(0,true,false),walk(0,false,true),walk(0,false,true),["hole",100]]);f.bot.advance(0);check(f.bot.completedSourceSteps==3 && downs(f,37)==0 && downs(f,39)==1,"same-timestamp duplicate states are coalesced without a burst of obsolete directions");stop(f,1);
   f=fixture(display,[walk(0),walk(100,true,false),["hole",100]]);f.bot.advance(0);f.bot.setFocused(false);f.bot.advance(20);check(!f.player.right,"focus loss releases native input");f.bot.advance(200);f.bot.setFocused(true);f.bot.advance(220);check(f.player.right && f.bot.nextDeadline==300,"explicit focus suspension shifts the epoch once instead of accumulating frame delay");f.bot.advance(300);check(f.player.left,"source sequence resumes after explicit focus suspension");stop(f,301);
   f=fixture(display,[walk(0),walk(100,true,false),["hole",100]]);f.bot.advance(0);f.root.current_round_code=2;f.bot.advance(50);check(f.bot.nextDeadline==150 && f.bot.completedSourceSteps==1,"new round clears old timeline and starts a fresh epoch");f.player.dead=true;f.bot.advance(51);check(!f.player.right,"death releases native keys");f.player.dead=false;f.bot.advance(120);check(f.player.right && f.bot.nextDeadline==220,"respawn restarts without any coordinate sync");
   var birth:ByteArray=new ByteArray();birth.writeByte(144);birth.writeByte(2);birth.writeUTF("Self#0001");birth.writeInt(7);birth.position=1;NativeMotion.observe(f.root,birth);f.bot.advance(230);check(birth.position==1 && f.bot.nextDeadline==330,"birth packet resets clock with packet cursor preserved");
   var won:ByteArray=new ByteArray();won.writeByte(8);won.writeByte(6);won.writeByte(0);won.writeInt(7);won.position=1;NativeMotion.observe(f.root,won);f.bot.advance(240);check(won.position==1 && f.bot.message.indexOf("vitoria confirmada")>=0 && !f.player.right,"native victory releases controls without forged victory packets");stop(f,241);
   verifyTimers(display,function():void{verifyCorpus(display);});
  }catch(error:Error){ExternalInterface.call("recordTest","FAIL after "+count+" checks: "+error.message+" #"+error.errorID+" "+error.getStackTrace());}}
  private static function verifyTimers(display:MovieClip,finished:Function):void{
   var f:Object=fixture(display,[walk(0),walk(45,true,false),walk(45,false,false),["hole",50]]);f.bot.useTimers(true);var start:int=getTimer();f.bot.advance(start);var polls:int=0;
   var poll:Function=function():void{try{
    polls++;if(f.bot.message.indexOf("confirmacao")<0){if(polls>200 || getTimer()-start>2000)throw new Error("automatic timer stalled: "+f.bot.message);setTimeout(poll,20);return;}
    check(f.bot.completedSourceSteps==4 && getTimer()>=start+140,"automatic single timer runs all deadlines without manual ENTER_FRAME calls");
    check(downs(f,39)==1 && downs(f,37)==1 && !f.player.right && !f.player.left,"timer delivers each native direction once and releases terminal state");
    for each(var event:Object in f.keys)if(event.code==37 && event.down)check(event.at>=start+45,"timer cannot emit a direction before its source deadline");
    check(f.player.reads==0 && f.player.body.reads==0,"automatic path never polls live coordinates or velocity");
    stop(f,getTimer());var before:int=f.keys.length;setTimeout(function():void{try{check(f.keys.length==before,"disabled timeline cannot emit stale timer commands");finished();}catch(e:Error){ExternalInterface.call("recordTest","FAIL: timer cleanup "+e.message);}},80);
   }catch(e:Error){ExternalInterface.call("recordTest","FAIL: automatic timer "+e.message+" #"+e.errorID);}};setTimeout(poll,20);
  }
  private static function verifyCorpus(display:MovieClip):void{
   var loader:URLLoader=new URLLoader();loader.addEventListener(IOErrorEvent.IO_ERROR,function(e:IOErrorEvent):void{ExternalInterface.call("recordTest","FAIL: corpus load");});
   loader.addEventListener(Event.COMPLETE,function(e:Event):void{
    var library:RouteLibrary=new RouteLibrary(String(loader.data));loader.data="";var codes:Array=[];var cursor:int=0;var steps:int=0;var impulses:int=0;var inferred:int=0;
    var batch:Function=function():void{try{
     if(!library.done){library.step(131072);if(library.done){for(var code:String in library.entries)codes.push(code);ExternalInterface.call("recordProgress","Indexed "+codes.length+" map entries");}}
     else {var limit:int=Math.min(codes.length,cursor+4);while(cursor<limit){var route:Array=RoutePlayerNative.decodeRoute(String(library.entries[codes[cursor]]));var original:String=com.adobe.serialization.json.JSON.encode(route);var plan:Object=RouteKeyTimeline.build(route);var expected:int=0;var last:Number=-1;
      for each(var group:Object in plan.groups){if(group.at<last || !isFinite(group.at))throw new Error("non-monotonic timeline "+codes[cursor]);last=group.at;for each(var source:int in group.sources){if(source!=expected++)throw new Error("lost or reordered source sample "+codes[cursor]);}}
      check(expected==plan.sourceCount,"all original source samples retain their cumulative order in timeline");check(com.adobe.serialization.json.JSON.encode(route)==original,"planner never mutates original route data");
      if(codes[cursor]=="@298424"){
       var rightAt:Number=-1;var jumpAt:Number=-1;for each(group in plan.groups){if(group.jumpImpulse && jumpAt<0)jumpAt=group.at;if(group.at==2458 && group.right && !group.left)rightAt=group.at;}
       check(jumpAt==2243 && rightAt==2458,"@298424 preserves takeoff time and native RIGHT braking against negative VX");
       var found:Boolean=false;for each(group in plan.groups)if(group.at==3236){for each(source in group.sources)if(source==5)found=true;}check(found,"@298424 701ms collision segment is not stretched using low endpoint VX");
      }
      steps+=route.length;impulses+=plan.repeatedImpulses;inferred+=plan.inferredJumps;cursor++;if(cursor%200==0)ExternalInterface.call("recordProgress","Validated "+cursor+" key timelines");
     }}
     if(library.done && cursor==codes.length){check(cursor==2359,"all 2359 maps compiled into native key timelines");ExternalInterface.call("recordTest","PASS: "+count+" timed-key/no-position-check assertions; "+cursor+" routes / "+steps+" steps; "+impulses+" repeated jump impulses / "+inferred+" reconstructed takeoffs");}
     else setTimeout(batch,1);
    }catch(error:Error){ExternalInterface.call("recordTest","FAIL: corpus "+error.message+" #"+error.errorID);}};batch();
   });loader.load(new URLRequest("public/rotas_decodificadas.json"));
  }
 }
}
class NoPositionBody {
 public var reads:int=0;public var writes:int=0;
 public function NoPositionBody(){}
 public function get velocity():Object{reads++;throw new Error("live velocity access forbidden");}
 public function setPosition(...args):Boolean{writes++;throw new Error("position write forbidden");}
}
class NoPositionMouse {
 public var id:int=7;public var nick:String="Self#0001";public var body:Object;public var clip:Boolean=true;public var dead:Boolean=false;public var left:Boolean=false;public var right:Boolean=false;public var down:Boolean=false;public var side:Boolean=true;public var reads:int=0;public var writes:int=0;
 public function NoPositionMouse(){body=new NoPositionBody();}
 public function get x():Number{reads++;throw new Error("arrival check forbidden");}public function set x(value:Number):void{writes++;throw new Error("teleport forbidden");}
 public function get y():Number{reads++;throw new Error("arrival check forbidden");}public function set y(value:Number):void{writes++;throw new Error("teleport forbidden");}
 public function jump(...args):void{}public function crouch(...args):void{}public function stand(...args):void{}
}
