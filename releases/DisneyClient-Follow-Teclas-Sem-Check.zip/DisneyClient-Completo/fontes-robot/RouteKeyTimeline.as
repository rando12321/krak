package disney {
 // Offline reconstruction from recorded packets. Does not read the live player.
 public class RouteKeyTimeline {
  public static function signed16(value:Number):Number{return Number(int(value)<<16>>16)/100;}
  private static function point(p:Object):Object{return {x:int(Number(p.x))*0.3,y:int(Number(p.y))*0.3,vx:signed16(Number(p.vx)),vy:signed16(Number(p.vy)),ml:Boolean(p.ml),mr:Boolean(p.mr),jump:Boolean(p.jump),frame:int(p.frame)<<24>>24};}
  public static function estimateGravity(route:Array):Number{
   var estimates:Array=[];var previous:Object;var previousTime:Number=0;var time:Number=0;
   for each(var step:Array in route){time+=Number(step[2]);if(step[1]=="hole")break;if(step[1]!="walk")continue;var p:Object=point(step[0]);
    if(previous){var dt:Number=(time-previousTime)/1000;var dy:Number=p.y-previous.y;
     if(dt>=0.03 && dt<=0.5 && p.vy>previous.vy && Math.abs(dy-30*(previous.vy+p.vy)*0.5*dt)<=Math.max(2,Math.abs(dy)*0.1)){
      var g:Number=(p.vy-previous.vy)/dt;if(g>=2 && g<=30)estimates.push(g);
     }
    }previous=p;previousTime=time;
   }
   if(estimates.length<6)return 10;estimates.sort(Array.NUMERIC);var i:int=estimates.length>>1;
   return estimates.length%2 ? Number(estimates[i]) : (Number(estimates[i-1])+Number(estimates[i]))/2;
  }
  private static function compare(a:Object,b:Object):Number{return a.at<b.at ? -1 : (a.at>b.at ? 1 : Number(a.order)-Number(b.order));}
  public static function build(route:Array,mirror:Boolean=false):Object{
   var gravity:Number=estimateGravity(route);var operations:Array=[];var time:Number=0;var previous:Object;var previousTime:Number=0;var sourceCount:int=0;var inferred:int=0;var repeated:int=0;
   for(var i:int=0;i<route.length;i++){
    var step:Array=route[i];time+=Number(step[2]);var action:String=String(step[1]);sourceCount=i+1;
    if(action=="walk"){
     var p:Object=point(step[0]);var l:Boolean=mirror ? p.mr : p.ml;var r:Boolean=mirror ? p.ml : p.mr;
     operations.push({at:time,order:i*3,kind:"walk",left:l,right:r,clearJump:!p.jump,source:i});
     var newJump:Boolean=p.jump && (!previous || !previous.jump);
     var impulse:Boolean=p.jump && previous && previous.jump && Math.abs(p.vy+5)<=0.2 && time>previousTime && previous.vy+gravity*(time-previousTime)/1000-p.vy>2;
     if(newJump || impulse){
      var launch:Number=time;
      // A rising packet can arrive after takeoff. Only backdate when the
      // ballistic estimate agrees with the preceding grounded sample.
      if(newJump && p.vy>=-5 && p.vy<=-0.35){
       var age:Number=(p.vy+5)/gravity;var candidate:Number=time-age*1000;
       var launchY:Number=p.y-30*(-5*age+0.5*gravity*age*age);
       if(age>=0.012 && age<=0.45 && candidate>=previousTime && (!previous || (Math.abs(previous.vy)<=0.35 && Math.abs(launchY-previous.y)<=12))){launch=candidate;inferred++;}
      }
      if(impulse)repeated++;
      operations.push({at:Math.max(0,launch),order:i*3+1,kind:"jump",source:-1,first:!previous,left:l,right:r});
     }
     previous=p;previousTime=time;
    }else operations.push({at:time,order:i*3,kind:action,payload:step[0],source:i});
    if(action=="hole")break;
   }
   operations.sort(compare);
   var groups:Array=[];var left:Boolean=false;var right:Boolean=false;var jump:Boolean=false;var cursor:int=0;
   while(cursor<operations.length){
    var at:Number=Number(operations[cursor].at);var actions:Array=[];var sources:Array=[];var hasKeys:Boolean=false;var jumpImpulse:Boolean=false;
    while(cursor<operations.length && Math.abs(Number(operations[cursor].at)-at)<0.0000001){
     var op:Object=operations[cursor++];if(op.source>=0)sources.push(int(op.source));
     if(op.kind=="walk"){left=op.left;right=op.right;if(op.clearJump)jump=false;hasKeys=true;}
     else if(op.kind=="jump"){if(op.first){left=op.left;right=op.right;}jump=true;jumpImpulse=true;hasKeys=true;}
     else actions.push({kind:op.kind,payload:op.payload});
    }
    groups.push({at:at,left:left,right:right,jump:jump,jumpImpulse:jumpImpulse,hasKeys:hasKeys,actions:actions,sources:sources});
   }
   return {groups:groups,duration:time,sourceCount:sourceCount,gravity:gravity,inferredJumps:inferred,repeatedImpulses:repeated};
  }
 }
}
