package disney {
 import ChargeurTransformice_fla.MainTimeline;import ChargeurTransformice_fla.Statements;import flash.display.MovieClip;import flash.events.Event;import flash.events.KeyboardEvent;import flash.events.IOErrorEvent;import flash.geom.Point;import flash.net.URLLoader;import flash.net.URLRequest;import flash.text.TextField;import flash.external.ExternalInterface;import flash.utils.setTimeout;import flash.utils.ByteArray;import flash.display.Sprite;
 public class RgbMouseTests {
  private static var count:int=0;private static function check(ok:Boolean,s:String):void{if(!ok)throw new Error(s);count++;}
  private static function walk(x:Number,delay:Number=100,j:Boolean=true):Array{return [{x:x,y:1102,vx:345,vy:j ? 65036 : 0,mr:true,ml:false,jump:j,frame:2},"walk",delay];}
  private static function fixture(display:MovieClip,steps:Array=null,sealedRoot:Boolean=false):Object{
   var r:MovieClip=sealedRoot ? new SealedRobotRoot() : new MovieClip();display.addChild(r);var calls:Array=[];var jumps:Array=[];var markers:Array=[];var syncs:Array=[];var keys:Array=[];
   var body:Object={velocity:{vx:0,vy:0},setPosition:function(p:Point,angle:Number):Boolean{calls.push({x:p.x,y:p.y});return true;}};
   var p:Object={x:118.5,y:330.6,body:body,clip:true,dead:false,left:false,right:false,down:false,side:true,jump:function(on:Boolean,frame:int=0):void{jumps.push({on:on,frame:frame});},crouch:function(s:Boolean):void{},stand:function(s:Boolean):void{}};
   var map:Object={number:{value:123},container:{mirror:false}};
   if(steps && steps[0][1]=="walk"){p.x=int(Number(steps[0][0].x))/100*30;p.y=int(Number(steps[0][0].y))/100*30;}
   r.Keys={packet_handler_class:{receive:function(bytes:ByteArray):void{syncs.push(bytes);}},packet_handler:"receive",player:"mouse",player_list:"players",player_physics:"body",player_clip:"clip",is_dead:"dead",player_moving_left:"left",player_moving_right:"right",jump:"jump",is_down:"down",crouch:"crouch",crouch2:"stand",static_side:"side",physics_state:"velocity",physics_state_vx:"vx",physics_state_vy:"vy",bot_set_position:"setPosition",b2vec2:"Point",app_domain:{applicationDomain:{getDefinition:function(n:String):Class{return Point;}}},map_class:{current:map,width:800},map_instance:"current",bot_map_code_object:"number",bot_map_code_value:"value",obj_container:"container",bot_reverse:"mirror",bot_map_width:"width",move_class:{free:true},move_free:"free",timer_class:{locked:false},timer_prop:"locked"};
   r.tfm={mouse:p,players:[]};r.Interface={status_field:new TextField()};r.Statements={send_cheese_packet:function():void{markers.push("cheese");},send_hole_packet:function():void{markers.push("hole");}};r.host_url="";r.auto_play=true;r.auto_play_disable_on_move=true;
   var bot:RoutePlayerNative=new RoutePlayerNative(r);var library:Object={};library["@123"]=steps ? steps : [walk(395,442),walk(495,100,false),["cheese",37],["hole",410]];bot.setRoutes(library);bot.setTiming(new RouteTiming(1,false));
   r.stage.addEventListener(KeyboardEvent.KEY_DOWN,function(e:KeyboardEvent):void{if(!NativeMotion.isSynthetic(r) && r.auto_play_disable_on_move && e.keyCode==39)bot.pause();});
   r.stage.addEventListener(KeyboardEvent.KEY_DOWN,function(e:KeyboardEvent):void{if(NativeMotion.isSynthetic(r))keys.push({code:e.keyCode,down:true});});
   r.stage.addEventListener(KeyboardEvent.KEY_UP,function(e:KeyboardEvent):void{if(NativeMotion.isSynthetic(r))keys.push({code:e.keyCode,down:false});});
   return {keys:keys,root:r,bot:bot,body:body,player:p,map:map,calls:calls,jumps:jumps,markers:markers,library:library,syncs:syncs};
  }
  private static function verifyLoader(display:MovieClip,finished:Function):void{
   var f:Object=fixture(display);f.map.number.value=1628732;f.player.x=193.8;f.player.y=381;var bot:RoutePlayerNative=new RoutePlayerNative(f.root);bot.setTiming(new RouteTiming(1,false));bot.loadRoutes();var clock:int=0;var tries:int=0;
   f.root.auto_play=false;var initial:int=int(ExternalInterface.call("routeRequests"));bot.advance(0);
   setTimeout(function():void{try{
    check(int(ExternalInterface.call("routeRequests"))==initial,"disabled Robot startup performs zero route requests");
    f.root.auto_play=true;f.player.body=null;bot.advance(1000);
    setTimeout(function():void{try{
     check(int(ExternalInterface.call("routeRequests"))==initial,"animation/player initialization performs zero route requests");
     f.player.body=f.body;
     var tick:Function=function():void{try{bot.advance(clock);clock+=1000;tries++;
      if(bot.message.indexOf("executando @1628732")>=0 || bot.message.indexOf("ponto ")>=0){check(f.calls.length==0 && f.syncs.length==0,"production route loads and runs without forced coordinates");check(int(ExternalInterface.call("routeRequests"))==initial+1,"only one small per-map request is needed");f.root.auto_play=false;bot.advance(clock);finished();}
      else if(tries>=2000)throw new Error("Production loader did not become ready: "+bot.message);
      else setTimeout(tick,1);
     }catch(error:Error){ExternalInterface.call("recordTest","FAIL: production loader "+error.message+" #"+error.errorID);}};tick();
    }catch(error:Error){ExternalInterface.call("recordTest","FAIL: boot "+error.message);}},100);
   }catch(error:Error){ExternalInterface.call("recordTest","FAIL: boot "+error.message);}},100);
  }
  private static function simulate(display:MovieClip,initialVX:Number,frame:int):void{
   var a:Array=walk(100,3600000,false);a[0].vx=0;
   var b:Array=walk(244,3600000,false);b[0].vx=345;
   var c:Array=walk(416,3600000,false);c[0].mr=false;c[0].vx=0;
   var f:Object=fixture(display,[a,b,c,["hole",3600000]]);f.body.velocity.vx=initialVX;
   f.bot.advance(0);var completed:Boolean=false;
   for(var time:int=frame;time<8000;time+=frame){
    var velocity:Number=f.body.velocity.vx;var dv:Number=12*frame/1000;
    if(f.player.right)velocity=Math.min(3.45,velocity+dv);
    else if(f.player.left)velocity=Math.max(-3.45,velocity-dv);
    else velocity=velocity>0 ? Math.max(0,velocity-dv) : Math.min(0,velocity+dv);
    f.body.velocity.vx=velocity;f.player.x+=velocity*30*frame/1000;
    var before:Number=f.player.x;f.bot.advance(time);
    check(f.player.x==before && f.body.velocity.vx==velocity,"spatial feedback actuates only native controls");
    if(f.bot.message.indexOf("confirmacao")>=0){completed=true;break;}
   }
   check(completed,"spatial mode completes synthetic path despite one-hour delays in every stored step");
   check(f.calls.length==0 && f.syncs.length==0,"spatial simulation sends no forced coordinates or initial sync");
  }
  private static function simulateRecordedLaunch(display:MovieClip,frame:int):void{
   var route:Array=[[{"mr":false,"ml":true,"x":1403,"y":1028,"vx":0,"vy":0,"jump":false,"frame":0},"walk",2006],[{"mr":false,"ml":true,"x":1403,"y":1028,"vx":0,"vy":0,"jump":false,"frame":0},"walk",0],[{"mr":false,"ml":true,"x":1343,"y":1028,"vx":65191,"vy":65036,"jump":true,"frame":9},"walk",237],[{"mr":true,"ml":false,"x":1272,"y":947,"vx":65191,"vy":65243,"jump":true,"frame":9},"walk",215],[{"mr":false,"ml":true,"x":1248,"y":926,"vx":65329,"vy":65328,"jump":true,"frame":9},"walk",77],[{"mr":false,"ml":true,"x":1004,"y":1029,"vx":67,"vy":388,"jump":false,"frame":9},"walk",701]];route.push(["hole",0]);
   var f:Object=fixture(display,route);f.body.velocity.vx=0;
   var launchedAt:Number=NaN;var floor:Number=f.player.y;
   f.root.stage.addEventListener(KeyboardEvent.KEY_DOWN,function(e:KeyboardEvent):void{
    if(e.keyCode==38 && NativeMotion.isSynthetic(f.root) && Math.abs(f.body.velocity.vy)<0.35 && f.player.y>=floor-0.1){f.body.velocity.vy=-5;launchedAt=f.player.x;}
   });
   f.bot.advance(0);var complete:Boolean=false;
   for(var tick:int=frame;tick<=6000;tick+=frame){
    var dt:Number=frame/1000;var vx:Number=f.body.velocity.vx;
    if(f.player.left)vx=Math.max(-3.45,vx-12*dt);
    else if(f.player.right)vx=Math.min(3.45,vx+12*dt);
    else vx=vx>0 ? Math.max(0,vx-12*dt) : Math.min(0,vx+12*dt);
    f.body.velocity.vx=vx;f.player.x+=vx*30*dt;
    f.body.velocity.vy+=10*dt;f.player.y+=f.body.velocity.vy*30*dt;
    if(f.player.y>=floor){f.player.y=floor;f.body.velocity.vy=0;}
    var px:Number=f.player.x;var py:Number=f.player.y;f.bot.advance(tick);
    check(f.player.x==px && f.player.y==py,"recorded-route model is actuated through keys only");
    if(f.bot.message.indexOf("confirmacao")>=0){complete=true;break;}
   }
   check(isFinite(launchedAt) && Math.abs(launchedAt-402.9)<=6,"@298424 launches at recorded location within one simulation frame: "+launchedAt);
   check(complete,"@298424 first six samples complete under native-key physics at "+frame+"ms: "+f.bot.message+" x="+f.player.x+" y="+f.player.y);
   check(f.calls.length==0 && f.syncs.length==0,"recorded-route simulation uses no reposition or sync packets");
   f.root.auto_play=false;f.bot.advance(7000);
  }
  public static function run(display:MovieClip):void{
   try{
    var f:Object=fixture(display,[walk(100,3600000,false),walk(200,3600000,false),["hole",3600000]]);f.bot.advance(0);
    check(f.player.right && f.bot.message.indexOf("ponto 2/3")>=0,"recorded delays never defer native input or waypoint selection");
    check(f.player.x==30 && f.calls.length==0 && f.syncs.length==0,"movement never assigns recorded coordinates or performs initial synchronization");
    var held:int=f.keys.length;f.bot.advance(16);f.bot.advance(32);check(f.keys.length==held,"unchanged held inputs are not repeated each frame");
    f.bot.advance(100000);check(f.player.right && f.bot.message.indexOf("ponto 2/3")>=0 && f.bot.message.indexOf("pausado")<0,"neither elapsed time nor frame gap pauses or skips an unreached point");
    f.player.x=60;f.bot.advance(100016);check(f.bot.message.indexOf("confirmacao")>=0 && !f.player.right,"native arrival advances route and terminal marker without recorded waits");
    check(f.calls.length==0 && f.markers.length==0,"cheese and hole are passive markers rather than forced packets");

    f=fixture(display,[walk(100,0,false),walk(150,0,false),["hole",0]]);f.bot.advance(0);check(f.bot.message.indexOf("ponto 2/3")>=0,"being within 24 pixels does not confirm a point still ahead");
    f.player.x=40;f.bot.advance(16);check(f.bot.message.indexOf("ponto 2/3")>=0,"nearby point still requires longitudinal progress");
    f.player.x=45;f.bot.advance(32);check(f.bot.message.indexOf("confirmacao")>=0,"actual passage confirms the pending point");
    f=fixture(display,[walk(100,0,false),walk(120,0,false),walk(140,0,false),["hole",0]]);f.bot.advance(0);f.player.x=45;f.bot.advance(16);
    check(f.bot.message.indexOf("confirmacao")>=0,"dense points crossed in one physical segment are consumed in order in one frame");

    f=fixture(display,[walk(100,0,false),walk(200,0,false),["hole",0]]);f.body.velocity.vx=9;f.bot.advance(0);
    check(f.player.left && f.body.velocity.vx==9,"live overspeed is corrected by braking input without writing velocity");
    var collision:Array=walk(200,0,false);collision[0].vx=64075;f=fixture(display,[walk(100,0,false),collision,["hole",0]]);f.bot.advance(0);
    check(f.player.right && !f.player.left,"negative after-collision snapshot VX cannot pull the mouse away from an unvisited point ahead");
    f=fixture(display,[walk(1000,0,false),walk(1100,0,false),["hole",0]]);f.map.container.mirror=true;f.player.x=500;f.bot.advance(0);
    check(f.player.left && f.player.x==500,"mirrored route changes input direction without moving the body");

    f=fixture(display,[walk(100,0,false),walk(200,0,false),["hole",0]]);f.bot.advance(0);f.bot.setFocused(false);f.bot.advance(16);
    check(!f.player.left && !f.player.right,"focus loss releases native controls");f.bot.setFocused(true);f.bot.advance(32);
    check(f.bot.message.indexOf("reative")>=0 && !f.player.right,"manual focus suspension does not silently resume old keys");
    f.root.auto_play=false;f.bot.advance(48);f.root.auto_play=true;f.bot.advance(64);
    check(f.bot.message.indexOf("pausado")<0 && f.player.right,"reactivation starts without an added startup delay");
    f.root.auto_play=false;f.bot.advance(80);check(!f.player.right && f.calls.length==0,"disable cancels spatial steering");
    f=fixture(display,[walk(100,0,false),walk(200,0,false),["hole",0]]);f.bot.advance(0);f.player.dead=true;f.bot.advance(16);
    check(!f.player.right,"death releases held input");f.player.dead=false;f.bot.advance(32);check(f.calls.length==0 && f.syncs.length==0,"respawn neither teleports nor sends a native sync packet");
    f=fixture(display,[walk(100,0,false),["hole",0]],true);f.bot.advance(0);check(f.calls.length==0 && !NativeMotion.isSynthetic(f.root),"spatial playback works with sealed document root");

    var feedback:RouteFeedback=new RouteFeedback();var readPlayer:Object={x:999,y:999};var velocity:Object={xx:0,yy:0};var position:Object={xx:5,yy:7};
    var readBody:Object={getVelocity:function():Object{return velocity;},getTransform:function():Object{return {position:position};}};
    var readKeys:Object={get_linear_velocity:"getVelocity",get_x_form:"getTransform",pos_x:"xx",pos_y:"yy"};var state:Object=feedback.observe(readPlayer,readBody,readKeys,0);
    check(state.x==150 && state.y==210 && readPlayer.x==999,"feedback reads physical rather than visual coordinates without writing them");
    var target:Object={x:150,y:210,vx:3.45,vy:0,mr:true,ml:false,jump:false};var c:Object=feedback.controls(target);
    check(c.right && !c.left,"live VX below desired magnitude produces ordinary right input");velocity.xx=7;feedback.observe(readPlayer,readBody,readKeys,16);c=feedback.controls(target);
    check(c.left && !c.right && velocity.xx==7,"native braking input leaves measured VX unchanged");
    velocity.xx=3.4;feedback.observe(readPlayer,readBody,readKeys,32);c=feedback.controls(target);check(c.right && !c.left,"hysteresis avoids noise near desired velocity");
    velocity.xx=7;velocity.yy=-4;target.jump=true;feedback.observe(readPlayer,readBody,readKeys,48);c=feedback.controls(target);
    check(c.left && c.jump && velocity.yy==-4,"native air control does not force VY or gravity");
    velocity.xx=0;velocity.yy=0;feedback.observe(readPlayer,readBody,readKeys,64);c=feedback.controls({x:210,y:210,vx:-14.61,vy:0,mr:true,ml:false,jump:false});
    check(c.right,"after-collision velocity sign cannot reverse spatial approach away from target");
    c=feedback.controls({x:151,y:210,vx:0,vy:0,mr:false,ml:false,jump:false});check(c.right,"small outstanding displacement is not trapped by the velocity deadband");
    var presses:int=0;
    // Incoming state, ballistic launch reconstruction and phase regressions.
    feedback.reset();readPlayer={x:30,y:330.6};velocity={xx:3.45,yy:0};
    readBody={getVelocity:function():Object{return velocity;}};
    var incoming:Object={x:30,y:330.6,vx:3.45,vy:0,ml:false,mr:true,jump:false};
    var reversal:Object={x:36,y:330.6,vx:3.45,vy:0,ml:true,mr:false,jump:false};
    feedback.observe(readPlayer,readBody,readKeys,0);
    c=feedback.controls(reversal,incoming);check(c.right && !c.left,"future braking flag does not reverse the incoming segment before arrival");
    var takeoff:Object={x:60,y:330.6,vx:3.45,vy:-5,ml:false,mr:true,jump:true};
    c=feedback.controls(takeoff,incoming);check(!c.jump,"UP waits for the recorded ground takeoff instead of firing a full segment early");
    readPlayer.x=60;feedback.observe(readPlayer,readBody,readKeys,16);c=feedback.controls(takeoff,incoming);check(c.jump && c.right,"takeoff issues UP together with the existing horizontal input");
    var rising:Object={x:80.7,y:306.6,vx:3.45,vy:-3,ml:false,mr:true,jump:true};
    feedback.changeInputs();readPlayer.x=30;feedback.observe(readPlayer,readBody,readKeys,32);c=feedback.controls(rising,incoming);check(!c.jump,"elevated sample reconstructs its takeoff instead of jumping at segment start");
    readPlayer.x=60;feedback.observe(readPlayer,readBody,readKeys,48);c=feedback.controls(rising,incoming);check(c.jump,"elevated sample triggers at its reconstructed ballistic launch position");
    feedback.reset();readPlayer={x:0,y:0};velocity={xx:0,yy:-3};feedback.observe(readPlayer,readBody,readKeys,0);
    readPlayer.y=-10;feedback.observe(readPlayer,readBody,readKeys,100);
    check(!feedback.checkpoint({x:0,y:-8,vy:3},0),"descending checkpoint cannot be consumed while ascending through the same coordinate");
    velocity.yy=3;readPlayer.y=-12;feedback.observe(readPlayer,readBody,readKeys,200);readPlayer.y=-8;feedback.observe(readPlayer,readBody,readKeys,300);
    check(feedback.checkpoint({x:0,y:-8,vy:3},200),"descending checkpoint is accepted on the matching flight phase");
    var delayedJump:Array=walk(300,100,true);delayedJump[0].vy=65036;
    f=fixture(display,[walk(100,0,false),delayedJump,["hole",0]]);f.bot.advance(0);
    presses=0;for each(var eventKey:Object in f.keys)if(eventKey.code==38 && eventKey.down)presses++;
    check(presses==0 && f.player.right,"executor does not bypass launch calculation with a premature UP event");
    f.player.x=90;f.bot.advance(16);presses=0;for each(eventKey in f.keys)if(eventKey.code==38 && eventKey.down)presses++;
    check(presses==1,"executor commits UP once at the actual takeoff waypoint");
    feedback.reset();readPlayer={x:0,y:0};feedback.observe(readPlayer,{}, {},0);readPlayer.x=6;state=feedback.observe(readPlayer,{}, {},200);
    check(Math.abs(state.vx-1)<0.00001 && feedback.source=="estimada","missing native getter uses marked position-derived estimate in matching units");
    feedback.reset();state=feedback.observe(readPlayer,{}, {},500);check(state.vx==0 && feedback.source=="aguardando","player reset discards old estimates");

    feedback.reset();readPlayer={x:0,y:0};feedback.observe(readPlayer,{}, {},0);
    check(!feedback.checkpoint({x:6,y:0},0,{x:0,y:0}),"broad proximity cannot approve future point before segment progress");
    readPlayer.x=10;feedback.observe(readPlayer,{}, {},100);check(feedback.checkpoint({x:4,y:0},0,{x:0,y:0}),"actual swept visit confirms first point");var firstHit:Number=feedback.hitAt;feedback.crossedAt(firstHit);
    check(feedback.checkpoint({x:6,y:0},feedback.since(),{x:4,y:0}) && feedback.hitAt>firstHit,"same-frame next point uses later part of real movement");
    var secondHit:Number=feedback.hitAt;feedback.crossedAt(secondHit);check(feedback.checkpoint({x:8,y:0},feedback.since(),{x:6,y:0}) && feedback.hitAt>secondHit,"dense visits are temporally ordered");
    check(!feedback.checkpoint({x:4,y:0},feedback.hitAt+0.001,{x:8,y:0}),"old pass cannot satisfy later return point");
    feedback.reset();readPlayer.x=0;feedback.observe(readPlayer,{}, {},0);readPlayer.x=200;feedback.observe(readPlayer,{}, {},100);check(!feedback.checkpoint({x:100,y:0},0),"large external reposition is not a fake swept visit");

    var ground:Array=walk(100,3600000,false);ground[0].vx=0;var elevated:Array=walk(100,3600000,true);elevated[0].y=982;elevated[0].vx=0;
    f=fixture(display,[ground,elevated,["cheese",3600000],["hole",3600000]]);f.bot.advance(0);presses=0;for each(var key:Object in f.keys)if(key.code==38 && key.down)presses++;
    check(presses==1 && f.bot.message.indexOf("ponto 2/4")>=0,"spatial target activates jump before requiring its elevated coordinate");f.body.velocity.vy=-5;
    for(var time:int=16;time<=600;time+=16){f.body.velocity.vy+=10*0.016;f.player.y+=f.body.velocity.vy*30*0.016;var physicalY:Number=f.player.y;f.bot.advance(time);check(f.player.y==physicalY,"native jump model is never repositioned by controller");}
    check(f.bot.message.indexOf("confirmacao")>=0 && f.markers.length==0,"native jump reaches point and passes cheese/hole markers without recorded delays");
    presses=0;for each(key in f.keys)if(key.code==38 && key.down)presses++;check(presses==1,"jump key is not spammed per frame");

    f=fixture(display,[walk(100,0,false),["hole",0]]);f.root.Keys.player_id="pid";f.player.pid=7;f.bot.advance(0);
    var victory:ByteArray=new ByteArray();victory.writeByte(8);victory.writeByte(6);victory.writeByte(0);victory.writeInt(7);victory.position=1;NativeMotion.observe(f.root,victory);f.bot.advance(16);
    check(f.bot.message.indexOf("vitoria confirmada")>=0 && victory.position==1,"native local victory and packet cursor remain intact");
    MainTimeline.instance=display as MainTimeline;var old:Statements=new Statements();old.current_timeout=-1;old.play_map();old.play_sequence();old.step(null,"walk");old.player_victory();old.player_death();old.kill_player();old.send_cheese_packet();old.send_hole_packet();old.send_mort_packet();old.move_player(1,2);old.handle_preview_btn();
    check(old.current_timeout==-1 && old.new_cheese_packet(1,true)==null,"retired forced movement and packet functions remain inert");
    simulateRecordedLaunch(display,16);simulateRecordedLaunch(display,33);simulateRecordedLaunch(display,50);
    simulate(display,0,16);simulate(display,1,16);simulate(display,-0.5,33);
    var loader:URLLoader=new URLLoader();loader.addEventListener(IOErrorEvent.IO_ERROR,function(e:IOErrorEvent):void{ExternalInterface.call("recordTest","FAIL: full route library could not load");});
    loader.addEventListener(Event.COMPLETE,function(e:Event):void{
     var catalog:RouteLibrary=new RouteLibrary(String(loader.data));loader.data="";var codes:Array=[];var cursor:int=0;var totalSteps:int=0;
     var batch:Function=function():void{try{
      if(!catalog.done){catalog.step(131072);if(catalog.done){for(var name:String in catalog.entries)codes.push(name);ExternalInterface.call("recordProgress","Indexed "+codes.length+" map entries");}}
      else {var limit:int=Math.min(codes.length,cursor+4);while(cursor<limit){var route:Array=RoutePlayerNative.decodeRoute(String(catalog.entries[codes[cursor]]));totalSteps+=route.length;cursor++;if(cursor%200==0)ExternalInterface.call("recordProgress","Validated "+cursor+" routes");}}
      if(catalog.done && cursor==codes.length){check(cursor==2359,"all 2359 maps parsed incrementally with native ActionScript decoder");verifyLoader(display,function():void{ExternalInterface.call("recordTest","PASS: "+count+" native Robot checks; "+cursor+" routes / "+totalSteps+" steps validated");});}else setTimeout(batch,1);
     }catch(error:Error){ExternalInterface.call("recordTest","FAIL: full library "+error.message+" #"+error.errorID);}};batch();
    });loader.load(new URLRequest("public/rotas_decodificadas.json"));

   }catch(error:Error){ExternalInterface.call("recordTest","FAIL: "+error.message+" #"+error.errorID);}
  }
 }
}

class SealedRobotRoot extends flash.display.MovieClip {
 public var Keys:Object;public var tfm:Object;public var Interface:Object;public var Statements:Object;
 public var auto_play:Boolean=false;public var auto_play_disable_on_move:Boolean=false;public var host_url:String="";
 public var current_map_code:String="";public var current_map_code_int:int=0;public var player_has_cheese:Boolean=false;
}
