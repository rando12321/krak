# Robot com controle preditivo por teclas internas

Revisao atual: veja ../CONTROLE-PREDITIVO-LEIA-ME.txt e VALIDACAO-PREDITIVA.json.
As rotas nao foram alteradas. O controle usa feedback de posicao e velocidade,
frenagem e estimativa de decolagem, mantendo os teleportes automaticos desativados.
Os relatorios ESPACIAL e SEM-TELEPORTE abaixo sao de revisoes anteriores.

# Robot ESPACIAL e observador de conexao

A fonte canonica do executor e `fontes-autoplay/RoutePlayer.as`. O build gera
`RoutePlayerNative.as`; `RouteFeedback.as` le estado real e decide as teclas.
`fontes-conexao/ConnectionDiagnostics.as` e a fonte canonica do observador.
Nesta revisao, NativeMotion.place/synchronizeCurrent sao no-ops e followSample usa apenas movement. O Follow nao envia sincronizacao inicial. Os leitores/senders nativos foram preservados. Veja ../SEM-TELEPORTE-LEIA-ME.txt.

Use as fontes completas extraidas de DisneyClient-Follow.zip para compilar:

```sh
python fontes-robot/build.py --ffdec /caminho/ffdec
```

Requer Python, Java 21 e FFDec 26.4.0. Preserve `loader-base.swf`. O build gera
a SWF de producao e oito fixtures; nao inicia nem publica o servidor.

Para os testes, use Node, Playwright, Chromium e o runtime web Ruffle 0.7.1:

```sh
RUFFLE_DIR=/caminho/ruffle node fontes-robot/run_tests.cjs
python fontes-conexao/test_diagnostics.py
```

Para incluir a suite de musica, inicie `python fontes-musica/serve_fixture.py`
em outra janela e informe sua URL em MUSIC_API_BASE ao executar run_tests.cjs.
TEST_CASE=robot ou TEST_CASE=connection seleciona uma suite. O servidor de teste
Node usa credenciais ficticias; nao e o backend de producao.

Veja VALIDACAO-ESPACIAL.json, TESTES-ESPACIAL.txt e ../fontes-conexao/
VALIDACAO-LOGS.json. A validacao e local e nao garante ausencia de DC no jogo.
