ATUALIZAÇÃO MÚSICA: !p no SERVER abre o mini player. É obrigatório atualizar backend e instalar yt-dlp/FFmpeg. Consulte MUSICA-YOUTUBE-LEIA-ME.txt.

ATUALIZAÇÃO MÚSICA: !p no SERVER abre o mini player. É obrigatório atualizar backend e instalar yt-dlp/FFmpeg. Consulte MUSICA-YOUTUBE-LEIA-ME.txt.

ATUALIZAÇÃO INTERFACE (UPLOAD 8): Follow > Players, avisos locais no SERVER e opacidade do menu. Veja INTERFACE-PLAYERS-SERVER-LEIA-ME.txt e fontes-interface/VALIDACAO.json. Movimentação da base preservada.

ATUALIZAÇÃO FOLLOWAUTOBEST: consulte FOLLOWAUTOBEST-LEIA-ME.txt para o novo comando. Cinco fixtures; 157 verificações automatizadas em simulação, sem login no servidor real.

ATUALIZAÇÃO Y/TOCA: Fly agora usa Y e os controladores bloqueiam movimento após vitória local. Esta entrega restaura a base 02:49 e adiciona Fly. Consulte FLY-E-BASE-0249-LEIA-ME.txt. Anti-DC AOB: zero correspondências, nenhum patch aplicado.

ATUALIZAÇÃO: esta entrega restaura a base 02:49 e adiciona Fly. Consulte FLY-E-BASE-0249-LEIA-ME.txt. Anti-DC AOB: zero correspondências, nenhum patch aplicado.

ASTRO MENU — VISUAL ATUALIZADO E ROTAS SEM INTERPOLACAO

VISUAL
Tema escuro com contraste maior, destaque verde-agua, marca ASTRO no painel,
ASTRO MENU fixo no topo e botao Menu centralizado. A animacao RGB antiga nao
e mais iniciada. O painel se ajusta ao tamanho da janela e continua arrastavel.
Botoes de abas, fechamento e abertura preservam os eventos originais.
Campos numericos/texto continuam editaveis, com bordas e cores legiveis.

A aba Bot passa a se chamar Robot. A area foi reorganizada: ativacao, parada
por tecla, status com duas linhas, REC/SAVE/DELETE e lista de mapas. O antigo
campo Delay reduzido e o PREVIEW aposentado nao aparecem. O recorte interno
antigo foi removido dessa area; o recorte externo da janela e a rolagem foram
preservados. Ao trocar de aba, a rolagem retorna ao inicio.

SEM INTERPOLACAO
A funcao followFrame e o calculo de coordenadas intermediarias foram removidos
do controlador. Posicao fisica e visual so recebem a coordenada do registro
walk quando vence seu delay. Entre registros, a fisica e as teclas nativas
continuam funcionando; o rato nao e congelado na ultima posicao.
Mantem o mesmo NativeMotion.followSample compartilhado com /follow, sem
sobrescrever VX/VY ou impor frame gravado. Microajustes e microparadas pedidos
anteriormente permanecem nos trechos elegiveis. Nenhum dado do JSON foi alterado.

OUTRAS GARANTIAS DE ESCOPO
Robot antigo permanece retirado (23 corpos inertes, duas inscricoes removidas,
dez leituras de flags antigas eliminadas). Toca depende da confirmacao nativa,
sem pacotes forcados de coleta/vitoria/morte. Rodadas e renascimentos continuam
reiniciando o controlador. Foco/edicao de texto suspendem as teclas e o relogio.
Chat, emoji, login, protocolo e /follow foram preservados.

TESTES
43 verificacoes Robot, 27 Follow e 17 visuais/interacao no Ruffle. Verificou
que nenhuma coordenada e antecipada/interpolada, que os botoes mantem callbacks,
campos preservam valores/tipo de edicao, rolagem funciona e trocar de aba a zera.
Verificador do SWF exige ausencia de followFrame, mesmo driver no Follow/Robot,
corpos legados inertes e limites de pilha/escopo validos.
2359 entradas e 179813 passos do JSON foram lidos/validados.
A previa visual usa componentes simulados com o MenuBootstrap real em Ruffle;
nao e uma captura de partida autenticada. A validacao no Adobe/VPS e pendente.
Nao se afirma que esta mudanca resolva o DC do servidor.

FONTES / COMPILAR
fontes-visual/AstroVisual.as e a fonte canonica do visual; a copia em fontes-robot
e gerada pelo build. RoutePlayer.as em fontes-autoplay e a fonte do Robot.
python fontes-robot/build.py --ffdec /caminho/ffdec
Requer Python, Java21 e FFDec26.4.0 oficial. Nunca sobrescreva loader-base.swf.
RUFFLE_DIR=/caminho/ruffle node fontes-robot/run_tests.cjs
Testes: Node/Playwright/Chromium/Ruffle0.7.1. TEST_CASE=visual permite repetir
somente a verificacao visual; VISUAL_SCREENSHOT define o caminho da captura.

INSTALAR
Feche Flash e iniciador; substitua o pacote preservando sua .env, reinicie
INICIAR_CLIENT.bat e gere uma URL nova. IP mantido: 207.180.3.127:8080.
