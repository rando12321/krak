package disney {
 import flash.display.MovieClip;import flash.events.KeyboardEvent;import flash.geom.Point;import flash.text.TextField;import flash.utils.ByteArray;import flash.external.ExternalInterface;
 public class RgbMouseTests {
  private static var count:int=0;
  private static function check(ok:Boolean,text:String):void{if(!ok)throw new Error(text);count++;}
  private static function walk(x:int,l:Boolean,r:Boolean,j:Boolean,delay:int):Array{return [{x:x,y:1102,vx:345,vy:65036,mr:r,ml:l,jump:j,frame:2},"walk",delay];}
  public static function run(display:MovieClip):void{try{
   var root:MovieClip=new MovieClip();display.addChild(root);root.stage.focus=root.stage;
   var writes:int=0;var syncs:int=0;var keys:Array=[];
   var body:Object={velocity:{vx:7,vy:-3},setPosition:function(p:Point,a:Number):Boolean{writes++;throw new Error("forbidden route reposition");}};
   var player:Object={x:30,y:330.6,body:body,clip:true,dead:false,left:false,right:false,down:false,side:true,jump:function(...args):void{},crouch:function(...args):void{},stand:function(...args):void{}};
   var map:Object={number:{value:123},container:{mirror:false}};
   root.Keys={player:"mouse",player_physics:"body",player_clip:"clip",is_dead:"dead",player_moving_left:"left",player_moving_right:"right",jump:"jump",is_down:"down",crouch:"crouch",crouch2:"stand",static_side:"side",physics_state:"velocity",physics_state_vx:"vx",physics_state_vy:"vy",bot_set_position:"setPosition",b2vec2:"Point",app_domain:{applicationDomain:{getDefinition:function(n:String):Class{return Point;}}},map_class:{current:map,width:800},map_instance:"current",bot_map_code_object:"number",bot_map_code_value:"value",obj_container:"container",bot_reverse:"mirror",bot_map_width:"width",move_class:{free:true},move_free:"free",timer_class:{locked:false},timer_prop:"locked",packet_handler_class:{receive:function(bytes:ByteArray):void{syncs++;}},packet_handler:"receive"};
   root.tfm={mouse:player};root.Interface={status_field:new TextField()};root.auto_play=true;
   root.stage.addEventListener(KeyboardEvent.KEY_DOWN,function(e:KeyboardEvent):void{if(NativeMotion.isSynthetic(root))keys.push({code:e.keyCode,down:true});});
   root.stage.addEventListener(KeyboardEvent.KEY_UP,function(e:KeyboardEvent):void{if(NativeMotion.isSynthetic(root))keys.push({code:e.keyCode,down:false});});
   var route:Array=[walk(100,false,true,false,0),walk(200,true,false,true,0),walk(300,false,false,false,10),["hole",100]];
   var before:String=com.adobe.serialization.json.JSON.encode(route);
   var bot:RoutePlayerNative=new RoutePlayerNative(root);bot.setRoutes({"@123":route});bot.setTiming(new RouteTiming(1,false));
   bot.advance(0);bot.advance(249);check(keys.length==0,"original startup wait is preserved");
   bot.advance(300);check(player.right && !player.left,"first recorded step emits RIGHT");check(bot.message.indexOf("1/4")>=0,"first step advances exactly one index");
   check(writes==0 && syncs==1,"Robot initial sync is preserved once while route samples never reposition");
   bot.advance(301);bot.advance(316);bot.advance(332);check(player.right && !player.left && bot.message.indexOf("1/4")>=0,"33ms gate cannot skip or prematurely consume the next step");
   bot.advance(333);check(player.left && !player.right,"second recorded step emits LEFT");check(bot.message.indexOf("2/4")>=0,"second step advances exactly one index");
   var jumpDowns:int=0;for each(var key:Object in keys)if(key.code==38 && key.down)jumpDowns++;check(jumpDowns==1,"second step preserves the recorded jump edge");
   bot.advance(343);bot.advance(365);check(bot.message.indexOf("2/4")>=0,"next step remains pending until minimum interval expires");
   bot.advance(366);check(!player.left && !player.right,"third recorded neutral step is processed rather than skipped");check(bot.message.indexOf("3/4")>=0,"third step advances exactly one index");
   var jumpUps:int=0;for each(key in keys)if(key.code==38 && !key.down)jumpUps++;check(jumpUps==1,"third step preserves the recorded jump release");
   check(player.x==30 && player.y==330.6 && writes==0,"recorded x/y targets never snap the actual player or body");
   check(body.velocity.vx==7 && body.velocity.vy==-3,"route never overwrites native VX or VY");check(syncs==1,"only the original initial sync was retained; route samples add no syncs");
   bot.advance(465);check(bot.message.indexOf("3/4")>=0,"terminal delay is preserved after pacing");bot.advance(466);check(bot.message.indexOf("confirmacao")>=0,"terminal marker waits for native hole confirmation");
   bot.advance(10000);check(player.x==30 && writes==0 && syncs==1,"terminal wait cannot teleport to finish or jump ahead");
   check(com.adobe.serialization.json.JSON.encode(route)==before,"original route JSON remains unchanged");
   root.auto_play=false;bot.advance(10001);check(!player.left && !player.right,"disable releases keys immediately");
   root.auto_play=true;bot.advance(11000);bot.advance(11300);check(player.right && writes==0 && syncs==2,"reactivation replays first step without teleport");
   player.dead=true;bot.advance(11301);check(!player.right,"death releases held keys");player.dead=false;bot.advance(11400);bot.advance(11650);check(player.right && writes==0 && syncs==3,"respawn restarts without a teleport correction");
   root.auto_play=false;bot.advance(11651);
   ExternalInterface.call("recordTest","PASS: "+count+" original-33ms route-step-only removal checks");
  }catch(error:Error){ExternalInterface.call("recordTest","FAIL: "+error.message+" #"+error.errorID);}}
 }
}
