import asyncio
import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'DisneyClient'))
# api/__init__ imports the legacy database package. Load music in a small package
# namespace so the tests never read .env or connect to a real database.
import types
package = types.ModuleType('music_test_api');package.__path__ = [str(ROOT/'DisneyClient/api')];sys.modules['music_test_api']=package
spec=importlib.util.spec_from_file_location('music_test_api.music',ROOT/'DisneyClient/api/music.py');music=importlib.util.module_from_spec(spec);sys.modules[spec.name]=music;spec.loader.exec_module(music)

class URLs(unittest.TestCase):
    def test_public_links(self):
        for u in ['https://www.youtube.com/watch?v=abcdefghijk','https://youtu.be/abcdefghijk?t=4','https://music.youtube.com/watch?v=abcdefghijk&si=xyz','https://youtube.com/shorts/abcdefghijk']:
            self.assertEqual(music.video_id(u),'abcdefghijk')
    def test_reject_unsafe_links(self):
        for u in ['http://youtu.be/abcdefghijk','https://youtube.com.evil.test/watch?v=abcdefghijk','https://127.0.0.1/watch?v=abcdefghijk','https://user@youtube.com/watch?v=abcdefghijk','https://youtube.com:443/watch?v=abcdefghijk','https://youtube.com/watch?v=short','https://youtube.com/watch?v=abcdefghijk&v=abcdefghijk','https://youtu.be/abcdefghijk/extra','https://youtube.com/playlist?list=x','https://youtube.com/watch?v=abcdefghijk#x']:
            with self.subTest(u=u),self.assertRaises(ValueError):music.video_id(u)

class Jobs(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        async def worker(job,folder):
            await asyncio.sleep(.01);(folder/'audio.mp3').write_bytes(b'ID3'+bytes(range(256))*4);job['title']='Teste'
        self.store=music.MusicJobs(Path(self.tmp.name)/'music',worker)
    async def asyncTearDown(self):
        await self.store.close();self.tmp.cleanup()
    async def test_ready_and_owner(self):
        job=await self.store.create(7,'https://youtu.be/abcdefghijk');await job['task'];self.assertEqual(job['state'],'ready');self.assertEqual(self.store.owned(job['id'],7),job)
        with self.assertRaises(web.HTTPNotFound):self.store.owned(job['id'],8)
        self.assertNotIn('path',self.store.status(job));self.assertNotIn('user',self.store.status(job))
    async def test_cancel_and_replace(self):
        async def slow(job,folder):await asyncio.sleep(30)
        self.store.worker=slow;a=await self.store.create(7,'https://youtu.be/abcdefghijk');await asyncio.sleep(.01);b=await self.store.create(7,'https://youtu.be/abcdefghijk');self.assertEqual(a['state'],'cancelled');await self.store.cancel(b);self.assertEqual(b['state'],'cancelled')
    async def test_replace_deletes_ready_mp3(self):
        old=await self.store.create(7,'https://youtu.be/abcdefghijk');await old['task'];path=old['path']
        other=await self.store.create(8,'https://youtu.be/abcdefghijk');await other['task']
        await self.store.create(7,'https://youtu.be/abcdefghijk')
        self.assertFalse(path.exists());self.assertTrue(other['path'].exists())
    async def test_disconnect_lease_deletes_mp3(self):
        job=await self.store.create(7,'https://youtu.be/abcdefghijk');await job['task'];path=job['path'];job['seen']-=61
        await self.store.prune();self.assertFalse(path.exists());self.assertNotIn(job['id'],self.store.jobs)
    async def test_active_lease_keeps_mp3(self):
        job=await self.store.create(7,'https://youtu.be/abcdefghijk');await job['task'];job['created']-=120
        await self.store.prune();self.assertTrue(job['path'].exists())
    async def test_timeout(self):
        self.store.timeout=.01
        async def slow(job,folder):await asyncio.sleep(30)
        self.store.worker=slow;j=await self.store.create(7,'https://youtu.be/abcdefghijk');await j['task'];self.assertEqual(j['state'],'error');self.assertFalse((self.store.folder/j['id']).exists())
    async def test_error_is_sanitized(self):
        async def broken(job,folder):raise ValueError('SECRET_SIGNED_URL')
        self.store.worker=broken;j=await self.store.create(7,'https://youtu.be/abcdefghijk');await j['task'];self.assertNotIn('SECRET',j['error'])
    async def test_empty_output_rejected(self):
        async def empty(job,folder):(folder/'audio.mp3').touch()
        self.store.worker=empty;j=await self.store.create(7,'https://youtu.be/abcdefghijk');await j['task'];self.assertEqual(j['state'],'error')
    async def test_rate_limit(self):
        for i in range(6):await self.store.create(7,'https://youtu.be/abcdefghijk')
        with self.assertRaises(web.HTTPTooManyRequests):await self.store.create(7,'https://youtu.be/abcdefghijk')
    async def test_concurrent_replace_is_serialized(self):
        async def slow(job,folder):await asyncio.sleep(30)
        self.store.worker=slow
        await self.store.create(7,'https://youtu.be/abcdefghijk')
        await asyncio.gather(self.store.create(7,'https://youtu.be/abcdefghijk'), self.store.create(7,'https://youtu.be/abcdefghijk'))
        self.assertEqual(sum(j['state'] in {'queued','preparing'} for j in self.store.jobs.values()),1)
    async def test_dependencies_missing_fails_before_download(self):
        self.store.production=True
        with patch.object(music.importlib.util,'find_spec',return_value=None),self.assertRaises(web.HTTPServiceUnavailable):
            await self.store.create(7,'https://youtu.be/abcdefghijk')
    async def test_expiry(self):
        j=await self.store.create(7,'https://youtu.be/abcdefghijk');await j['task'];j['created']-=1801;await self.store.prune();self.assertNotIn(j['id'],self.store.jobs)
    async def test_real_local_ffmpeg_conversion(self):
        import json
        import shutil
        if not shutil.which('ffmpeg') or not shutil.which('ffprobe') or importlib.util.find_spec('yt_dlp') is None:self.skipTest('yt-dlp and ffmpeg required')
        import yt_dlp
        from yt_dlp.postprocessor.ffmpeg import FFmpegExtractAudioPP
        wav=Path(self.tmp.name)/'tone.wav'
        process=await asyncio.create_subprocess_exec('ffmpeg','-v','error','-f','lavfi','-i','sine=frequency=440:duration=0.3','-ar','48000',str(wav))
        self.assertEqual(await process.wait(),0)
        opts=yt_dlp.parse_options(['--ignore-config','--extract-audio','--audio-format','mp3','--audio-quality','128K','--postprocessor-args','ExtractAudio+ffmpeg_o:-ar 44100 -ac 2']).ydl_opts
        opts.update(quiet=True,no_warnings=True)
        with yt_dlp.YoutubeDL(opts) as ydl:
            processor=FFmpegExtractAudioPP(ydl,preferredcodec='mp3',preferredquality='128')
            _,info=processor.run({'filepath':str(wav),'ext':'wav','title':'Test','duration':.3})
        probe=await asyncio.create_subprocess_exec('ffprobe','-v','error','-select_streams','a:0','-show_entries','stream=sample_rate,channels','-of','json',info['filepath'],stdout=asyncio.subprocess.PIPE)
        data=await probe.communicate();stream=json.loads(data[0])['streams'][0]
        self.assertEqual(stream['sample_rate'],'44100');self.assertEqual(stream['channels'],2)
    async def test_http_auth_status_range_cancel(self):
        async def auth(request):
            token=request.query.get('access_token')
            if token not in {'TEST7','TEST8'}:raise web.HTTPUnauthorized()
            return {'user_id':int(token[-1])}
        app=web.Application();app['music_jobs']=self.store;app.router.add_view('/music',music.Music);app.router.add_get('/music/audio/{ident}.mp3',music.audio)
        with patch.object(music,'authorize',auth):
            async with TestClient(TestServer(app)) as c:
                r=await c.post('/music',data={'action':'prepare','url':'https://youtu.be/abcdefghijk'});self.assertEqual(r.status,401)
                r=await c.post('/music?access_token=TEST7',data={'action':'prepare','url':'https://youtu.be/abcdefghijk'});d=await r.json();await self.store.jobs[d['id']]['task']
                r=await c.get('/music?access_token=TEST8&id='+d['id']);self.assertEqual(r.status,404)
                r=await c.get('/music?access_token=TEST7&id='+d['id']);ready=await r.json();self.assertEqual(ready['state'],'ready');self.assertEqual(ready['audio_url'],'http://207.180.3.127:8080/music/audio/'+d['id']+'.mp3');self.assertTrue(ready['requires_auth']);self.assertNotIn('TEST7',ready['audio_url'])
                self.store.jobs[d['id']]['seen']-=30
                r=await c.post('/music?access_token=TEST7',data={'action':'touch','id':d['id']});self.assertEqual(r.status,200);self.assertLess(music.time.monotonic()-self.store.jobs[d['id']]['seen'],1)
                r=await c.post('/music?access_token=TEST8',data={'action':'touch','id':d['id']});self.assertEqual(r.status,404)
                r=await c.get('/music/audio/'+d['id']+'.mp3?access_token=TEST7',headers={'Range':'bytes=0-9'});self.assertEqual(r.status,206);self.assertEqual(len(await r.read()),10);self.assertEqual(r.content_type,'audio/mpeg')
                r=await c.get('/music/audio/'+d['id']+'.mp3?access_token=TEST8');self.assertEqual(r.status,404)
                r=await c.post('/music?access_token=TEST7',data={'action':'cancel','id':d['id']});self.assertEqual((await r.json())['state'],'cancelled');self.assertFalse(self.store.jobs[d['id']]['path'].exists())
                r=await c.get('/music/audio/'+d['id']+'.mp3?access_token=TEST7');self.assertEqual(r.status,404)
class Launcher(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        spec=importlib.util.spec_from_file_location('music_vps_launcher',ROOT/'DisneyClient/musica_vps.py');cls.launch=importlib.util.module_from_spec(spec);spec.loader.exec_module(cls.launch)
    def test_public_address(self):
        self.assertEqual(self.launch.public_url('http://207.180.3.127:8080/'),'http://207.180.3.127:8080')
    def test_bind_address_is_not_public_url(self):
        for url in ['http://0.0.0.0:8080','ftp://207.180.3.127','http://user:pass@example.com','http://example.com/audio.mp3']:
            with self.assertRaises(ValueError):self.launch.public_url(url)
    def test_check_does_not_import_backend(self):
        with patch.object(self.launch,'dependencies',return_value={'Python':True}),patch('builtins.print'):
            self.assertEqual(self.launch.main(['--check']),0)
    def test_launch_uses_complete_parser_backend_supervisor(self):
        with patch.object(self.launch,'dependencies',return_value={'Python':True}),patch('builtins.print'),patch.object(self.launch.subprocess,'call',return_value=0) as call:
            self.assertEqual(self.launch.main([]),0)
            args=call.call_args.args[0]
            self.assertEqual(args[0],sys.executable)
            self.assertEqual(Path(args[1]),ROOT/'iniciar_client.py')
            self.assertEqual(call.call_args.kwargs['cwd'],str(ROOT))
    def test_missing_dependency_fails_before_startup(self):
        with patch.object(self.launch,'dependencies',return_value={'ffmpeg':False}),patch('builtins.print'):
            self.assertEqual(self.launch.main([]),2)
if __name__=='__main__':unittest.main()
