"""Start the existing client backend and authenticated MP3 service on the VPS.

Run instead of server.py, not alongside it on the same port.
"""
import argparse
import importlib.util
import os
import shutil
import sys
import subprocess
from pathlib import Path
from urllib.parse import urlsplit


def dependencies():
    checks = {'Python 3.11+': sys.version_info >= (3, 11)}
    for name in ('aiohttp', 'aiofiles', 'asyncmy', 'dotenv', 'ujson', 'cryptography', 'yt_dlp'):
        checks[name] = importlib.util.find_spec(name) is not None
    checks['ffmpeg'] = shutil.which('ffmpeg') is not None
    checks['ffprobe'] = shutil.which('ffprobe') is not None
    return checks


def public_url(value):
    parsed = urlsplit(value)
    if parsed.scheme not in {'http', 'https'} or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path not in {'', '/'}:
        raise ValueError('MUSIC_PUBLIC_URL deve ser um endereco HTTP/HTTPS sem caminho ou credenciais')
    if parsed.hostname in {'0.0.0.0', '::'}:
        raise ValueError('Use o IP publico na URL. 0.0.0.0 serve apenas para escutar conexoes')
    return value.rstrip('/')


def main(argv=None):
    parser = argparse.ArgumentParser(description='Servidor de MP3 para !p no ASTRO client')
    parser.add_argument('--check', action='store_true', help='Verificar dependencias sem abrir servidor/banco')
    args = parser.parse_args(argv)
    checks = dependencies()
    for name, available in checks.items():
        print(('[OK] ' if available else '[FALTA] ') + name)
    if not all(checks.values()):
        print('Instale Python 3.11+, execute py -3.11 -m pip install -r requirements.txt e coloque FFmpeg/ffprobe no PATH.')
        return 2
    if args.check:
        return 0
    # The existing supervisor starts BOTH parser and backend and injects the
    # parser endpoint/token into the backend environment. Starting create_app
    # alone loses that configuration and leaves the game SWF unavailable.
    project = Path(__file__).resolve().parent.parent
    launcher = project / 'iniciar_client.py'
    if not launcher.is_file() or not (project / 'DisneyParser' / 'main.py').is_file():
        print('Extraia o pacote completo: faltam iniciar_client.py ou DisneyParser/main.py.')
        return 2
    print('Iniciando parser + backend + musica. Deixe esta janela aberta.', flush=True)
    try:
        return subprocess.call([sys.executable, str(launcher)], cwd=str(project))
    except KeyboardInterrupt:
        return 0



if __name__ == '__main__':
    raise SystemExit(main())
