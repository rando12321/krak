// Requires Node + playwright, Chromium, and official @ruffle-rs/ruffle web files.
const http=require('http'),fs=require('fs'),path=require('path');
const {chromium}=require('playwright');
const root=path.resolve(__dirname,'..');
const ruffle=process.env.RUFFLE_DIR;
if(!ruffle)throw new Error('Set RUFFLE_DIR to the extracted @ruffle-rs/ruffle directory.');
const library=path.join(root,'DisneyClient/public/rotas_decodificadas.json');
const fixtures=process.env.FIXTURES_DIR||path.join(__dirname,'fixtures');
const server=http.createServer((req,res)=>{
 const route=new URL(req.url,'http://localhost').pathname;
 if(route==='/'){
  res.setHeader('Content-Type','text/html');res.end(`<body><script>window.recordTest=x=>window.result=x;window.routeRequests=()=>performance.getEntriesByType('resource').filter(x=>x.name.includes('/public/rotas/')&&x.name.endsWith('.json')).length;window.recordProgress=x=>console.log(x);window.RufflePlayer={config:{autoplay:'on',unmuteOverlay:'hidden'}};</script><script src="/ruffle/ruffle.js"></script><script>addEventListener('load',()=>{const player=RufflePlayer.newest().createPlayer();document.body.append(player);player.ruffle().load({url:new URLSearchParams(location.search).get('case')==='trajectory'?'/TrajectoryTests.swf':new URLSearchParams(location.search).get('case')==='performance'?'/PerformanceTests.swf':new URLSearchParams(location.search).get('case')==='music'?'/MusicTests.swf':new URLSearchParams(location.search).get('case')==='interface'?'/InterfaceTests.swf':new URLSearchParams(location.search).get('case')==='best'?'/AutoBestTests.swf':new URLSearchParams(location.search).get('case')==='fly'?'/FlyTests.swf':new URLSearchParams(location.search).get('case')==='visual'?'/VisualTests.swf':new URLSearchParams(location.search).get('case')==='follow'?'/FollowRegression.swf':'/RobotTests.swf',allowScriptAccess:true});});</script>`);return;
 }
 if(route==='/music'||route.startsWith('/music/audio/')){if(!process.env.MUSIC_API_BASE){res.writeHead(503).end();return;}const upstream=http.request(new URL(req.url,process.env.MUSIC_API_BASE),{method:req.method,headers:req.headers},response=>{res.writeHead(response.statusCode,response.headers);response.pipe(res);});upstream.on('error',()=>{res.writeHead(502).end();});req.pipe(upstream);return;}
 let file;
 if(route==='/public/rotas_decodificadas.json')file=library;
 else if(/^\/public\/rotas\/[0-9]+\.json$/.test(route))file=path.join(root,'DisneyClient',route);
 else if(route==='/RobotTests.swf'||route==='/FollowRegression.swf'||route==='/VisualTests.swf'||route==='/FlyTests.swf'||route==='/AutoBestTests.swf'||route==='/InterfaceTests.swf'||route==='/TrajectoryTests.swf'||route==='/PerformanceTests.swf'||route==='/MusicTests.swf')file=path.join(fixtures,path.basename(route));
 else if(route.startsWith('/ruffle/')){
  const base=path.resolve(ruffle);file=path.resolve(base,route.slice('/ruffle/'.length));
  if(!file.startsWith(base+path.sep)){res.writeHead(403).end();return;}
 }else{res.writeHead(404).end();return;}
 const ext=path.extname(file);res.setHeader('Content-Type',ext==='.wasm'?'application/wasm':ext==='.js'?'application/javascript':ext==='.json'?'application/json':'application/x-shockwave-flash');
 const stream=fs.createReadStream(file);stream.on('error',()=>{res.writeHead(404).end();});stream.pipe(res);
});
(async()=>{
 let browser;
 try{
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--autoplay-policy=no-user-gesture-required']});
  for(const target of (process.env.TEST_CASE ? [process.env.TEST_CASE] : ['robot','follow','visual','fly','best','interface','performance','trajectory',...(process.env.MUSIC_API_BASE?['music']:[])])){
   const page=await browser.newPage();page.on('console',m=>{if(m.text().startsWith('Indexed')||m.text().startsWith('Validated'))console.log(m.text());});
   await page.goto('http://127.0.0.1:'+server.address().port+'/?case='+target);
   await page.waitForFunction(()=>window.result,null,{timeout:600000});
   const result=await page.evaluate(()=>window.result);console.log(target+': '+result);if(target==='visual' && process.env.VISUAL_SCREENSHOT){await page.evaluate(()=>{const p=document.querySelector('ruffle-player');if(p){p.style.width='800px';p.style.height='600px';}});await page.waitForTimeout(100);await page.screenshot({path:process.env.VISUAL_SCREENSHOT});}if(target==='interface' && process.env.INTERFACE_SCREENSHOT){await page.evaluate(()=>{const p=document.querySelector('ruffle-player');if(p){p.style.width='800px';p.style.height='600px';}});await page.waitForTimeout(100);await page.screenshot({path:process.env.INTERFACE_SCREENSHOT});}await page.close();
   if(!result.startsWith('PASS:'))throw new Error(result);
  }
 }catch(error){console.error(String(error));process.exitCode=1;}
 finally{if(browser)await browser.close();server.close();}
})();
