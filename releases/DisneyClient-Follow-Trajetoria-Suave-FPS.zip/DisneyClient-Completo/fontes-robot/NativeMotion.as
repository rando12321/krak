package disney {
 import flash.display.MovieClip;import flash.events.KeyboardEvent;import flash.events.Event;import flash.utils.Dictionary;import flash.utils.ByteArray;
 public class NativeMotion {
  private static var drivers:Dictionary=new Dictionary(true);
  private var completed:Boolean=false;private var completedPlayer:Object;private var completedBody:Object;private var completedRound:String="";private var completedMap:Object;
  private var packetObserver:Function;private var syntheticDepth:int=0;private var root:MovieClip;private var owner:Object;private var player:Object;private var left:Boolean=false;private var right:Boolean=false;private var jumping:Boolean=false;private var jumpKeyDown:Boolean=false;
  public function NativeMotion(value:MovieClip){root=value;}
  public static function get(value:MovieClip):NativeMotion{if(!drivers[value])drivers[value]=new NativeMotion(value);return drivers[value];}
  public static function isSynthetic(value:MovieClip):Boolean{var driver:NativeMotion=drivers[value] as NativeMotion;return driver!=null && driver.syntheticDepth>0;}
  public function observeWith(callback:Function):void{packetObserver=callback;}
  public var observationFailures:uint=0;
  public static function observe(value:MovieClip,bytes:ByteArray):void{
   var driver:NativeMotion=drivers[value] as NativeMotion;if(!driver || !bytes)return;
   var cursor:uint=bytes.position;
   try{bytes.position=0;driver.lifecycle(bytes);}catch(lifecycleError:Error){driver.observationFailures++;}
   try{if(driver.packetObserver!=null){bytes.position=0;driver.packetObserver(bytes);}}
   catch(error:Error){driver.observationFailures++;}
   finally{bytes.position=cursor;}
  }
  private function round():String{return "current_round_code" in root ? String(root["current_round_code"]) : "";}
  private function map():Object{var k:Object=root["Keys"];return k && k.map_class && k.map_instance ? k.map_class[k.map_instance] : null;}
  public function finished():Boolean{
   if(!completed)return false;var k:Object=root["Keys"];var game:Object=root["tfm"];var local:Object=k && game ? game[k.player] : null;var body:Object=local && k.player_physics ? local[k.player_physics] : null;
   // Removing the body/clip during victory is not a respawn.
   var ready:Boolean=local && body && (!k.is_dead || !local[k.is_dead]) && (!k.player_clip || local[k.player_clip]);
   if(ready && (local!==completedPlayer || body!==completedBody || round()!=completedRound || map()!==completedMap))completed=false;
   return completed;
  }
  private function lifecycle(bytes:ByteArray):void{
   if(bytes.bytesAvailable<2)return;var c:int=bytes.readUnsignedByte();var cc:int=bytes.readUnsignedByte();
   var k:Object=root["Keys"];var game:Object=root["tfm"];var local:Object=k && game ? game[k.player] : null;
   if(c==5 && cc==2){completed=false;return;}
   if(c==144 && cc==2){bytes.readUTF();if(bytes.bytesAvailable>=4 && local && k.player_id && int(local[k.player_id])==bytes.readInt())completed=false;return;}
   if(c!=8 || cc!=6 || bytes.bytesAvailable<5 || !local || !k.player_id)return;
   bytes.readUnsignedByte();if(bytes.readInt()!=int(local[k.player_id]))return;
   completed=true;completedPlayer=local;completedBody=k.player_physics ? local[k.player_physics] : null;completedRound=round();completedMap=map();
   if(root.stage)root.stage.dispatchEvent(new Event("astroMotionTerminal"));
   if(owner)release(owner);
  }
  private function read(o:Object,p:*):*{try{if(o && p!=null && p in o)return o[p];}catch(e:Error){}return null;}
  private function put(o:Object,p:*,v:*):void{if(o && p!=null && p in o)o[p]=v;}
  private function invoke(o:Object,p:*,args:Array):void{var fn:Function=read(o,p) as Function;if(fn!=null)fn.apply(o,args);}
  public function inputBusy():Boolean{return owner!=null;}
  public function busyExcept(token:Object):Boolean{return owner!=null && owner!==token;}
  public function key(code:uint,down:Boolean):void{
   if(!root.stage)return;syntheticDepth++;
   try{root.stage.dispatchEvent(new KeyboardEvent(down ? KeyboardEvent.KEY_DOWN : KeyboardEvent.KEY_UP,true,false,0,code));}finally{syntheticDepth--;}
  }
  public function movement(token:Object,l:Boolean,r:Boolean,j:Boolean):void{
   if(finished()){release(token);return;}
   var k:Object=root["Keys"];var local:Object=root["tfm"] ? root["tfm"][k.player] : null;
   var freshOwner:Boolean=owner!==token || player!==local;
   if(freshOwner){if(owner)release(owner);owner=token;player=local;}
   if(left && !l){key(37,false);left=false;}if(right && !r){key(39,false);right=false;}
   if(!left && l){key(37,true);left=true;}if(!right && r){key(39,true);right=true;}
   if(jumping!=j){key(38,j);jumpKeyDown=j;}
   jumping=j;
   if(player){put(player,read(k,"player_moving_left"),l);put(player,read(k,"player_moving_right"),r);}
  }

  public function place(token:Object,x:Number,y:Number):void{
   if(finished())return;
   if(!isFinite(x)||!isFinite(y))throw new Error("Invalid coordinates",2401);
   var k:Object=root["Keys"];var local:Object=root["tfm"][k.player];var body:Object=local[k.player_physics];
   if(!body || !(body[k.bot_set_position] is Function))throw new Error("Native physics unavailable",2402);
   var vectorClass:Class=k.app_domain.applicationDomain.getDefinition(String(k.b2vec2)) as Class;
   if(body[k.bot_set_position](new vectorClass(x/30,y/30),0)===false)throw new Error("Native physics locked",2403);
   local.x=x;local.y=y;
  }
  // Single movement path for live Follow and the Robot's virtual route target.
  // Default keyboard jump path: the game owns velocity and animation frame.
  public function followSample(token:Object,l:Boolean,r:Boolean,j:Boolean,x:Number,y:Number):void{
   movement(token,l,r,j);place(token,x,y);
  }
  // Same native initialization as Follow, at the current local position only.
  // Caller owns lifecycle gating; invoke the mapped handler, not a socket API.
  public function synchronizeCurrent():void{
   if(finished())return;
   var k:Object=root["Keys"];var local:Object=k && root["tfm"] ? root["tfm"][k.player] : null;
   if(!local || (k.is_dead && local[k.is_dead]) || !local[k.player_physics] || !local[k.player_clip])throw new Error("Player not ready for sync",2408);
   var x:Number=Number(local.x);var y:Number=Number(local.y);
   if(!isFinite(x) || !isFinite(y) || Math.abs(x)>32767 || Math.abs(y)>32767)throw new Error("Invalid sync position",2408);
   if(!k.packet_handler_class || !k.packet_handler || !(k.packet_handler_class[k.packet_handler] is Function))throw new Error("Native sync mapping unavailable",2408);
   k.packet_handler_class[k.packet_handler](LegacyOptionsV5.encodePosition(Math.round(x),Math.round(y)));
  }
  public function crouch(token:Object,down:Boolean):void{if(finished())return;if(owner!==token)movement(token,false,false,false);var k:Object=root["Keys"];var p:Object=root["tfm"][k.player];put(p,read(k,"is_down"),down);invoke(p,read(k,down ? "crouch" : "crouch2"),[read(p,read(k,"static_side"))]);}
  public function release(token:Object):void{
   if(owner!==token)return;
   if(left)key(37,false);if(right)key(39,false);if(jumpKeyDown)key(38,false);
   var k:Object=root["Keys"];
   try{put(player,read(k,"player_moving_left"),false);put(player,read(k,"player_moving_right"),false);invoke(player,read(k,"jump"),[false]);if(read(player,read(k,"is_down"))){put(player,read(k,"is_down"),false);invoke(player,read(k,"crouch2"),[read(player,read(k,"static_side"))]);}}finally{left=false;right=false;jumping=false;jumpKeyDown=false;owner=null;player=null;}
  }
 }
}
