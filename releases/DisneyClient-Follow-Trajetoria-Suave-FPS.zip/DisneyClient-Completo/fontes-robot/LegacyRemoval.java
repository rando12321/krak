import com.jpexs.decompiler.flash.*;import com.jpexs.decompiler.flash.tags.*;import com.jpexs.decompiler.flash.abc.*;import com.jpexs.decompiler.flash.abc.types.*;import com.jpexs.decompiler.flash.abc.types.traits.*;import com.jpexs.decompiler.flash.abc.avm2.*;import com.jpexs.decompiler.flash.abc.avm2.instructions.*;import java.io.*;import java.util.*;
class LegacyRemoval {
 static final Set<String> DISABLED=Set.of("step","play_sequence","play_map","handle_preview_btn","player_victory","player_death","move_player","kill_player","send_cheese_packet","send_hole_packet","send_mort_packet","player_pos_packet","new_cheese_packet","new_victory_packet");
 static final Set<String> FLAGS=Set.of("no_delay","insta_death","insta_death2","insta_win");
 static String name(ABC a,int index){String n=a.constants.getString(a.constants.getMultiname(index).name_index);return n==null?"":n;}
 static AVM2Instruction op(int code){return new AVM2Instruction(0,code,new int[]{});}
 static void stub(ABC a,MethodBody b){int type=a.method_info.get(b.method_info).ret_type;boolean v=type!=0&&name(a,type).equals("void");AVM2Code c=new AVM2Code();c.code=new ArrayList<>();if(!v)c.code.add(op(0x20));c.code.add(op(v?0x47:0x48));b.setCode(c);b.exceptions=new ABCException[0];b.max_stack=v?0:1;b.max_scope_depth=b.init_scope_depth;b.setModified();}
 public static void main(String[]args)throws Exception{
  SWF s=new SWF(new FileInputStream(args[0]),false);DoABC2Tag tag=null;for(Tag t:s.getTags())if(t instanceof DoABC2Tag&&((DoABC2Tag)t).getABC().findClassByName("ChargeurTransformice_fla.MainTimeline")>=0)tag=(DoABC2Tag)t;ABC a=tag.getABC();int stubs=0,flags=0,events=0;Set<String> found=new HashSet<>();
  for(String cls:List.of("ChargeurTransformice_fla.Statements","disney.RoutePlayer")){
   int ci=a.findClassByName(cls);if(ci<0)throw new Exception("Missing "+cls);
   var traits=new ArrayList<Trait>();traits.addAll(a.instance_info.get(ci).instance_traits.traits);traits.addAll(a.class_info.get(ci).static_traits.traits);
   for(Trait t:traits)if(t instanceof TraitMethodGetterSetter){String n=name(a,t.name_index);if(cls.equals("disney.RoutePlayer")||DISABLED.contains(n)){stub(a,a.findBody(((TraitMethodGetterSetter)t).method_info));stubs++;if(cls.endsWith("Statements"))found.add(n);}}
  }
  if(!found.equals(DISABLED))throw new Exception("Missing obsolete functions: "+found);
  int main=a.findClassByName("ChargeurTransformice_fla.MainTimeline");
  for(Trait t:a.instance_info.get(main).instance_traits.traits)if(t instanceof TraitMethodGetterSetter){String n=name(a,t.name_index);if(!Set.of("loop_game","handle_packet").contains(n))continue;MethodBody b=a.findBody(((TraitMethodGetterSetter)t).method_info);
   for(int i=b.getCode().code.size()-1;i>=0;i--){var ins=b.getCode().code.get(i);if(ins.definition.instructionCode!=0x66)continue;String prop=name(a,ins.operands[0]);
    if(FLAGS.contains(prop)){b.replaceInstruction(i,op(0x29));b.insertInstruction(i+1,op(0x27));flags++;}
    else if(prop.equals("play_map") && i+1<b.getCode().code.size()){var call=b.getCode().code.get(i+1);if(call.definition.instructionCode==0x4f&&name(a,call.operands[0]).equals("addEventListener")&&call.operands[1]==2){b.replaceInstruction(i+1,op(0x29));b.insertInstruction(i+2,op(0x29));b.insertInstruction(i+3,op(0x29));events++;}}
   }b.setModified();
  }
  if(flags<8||events!=2)throw new Exception("Unexpected legacy sites flags="+flags+" events="+events);
  tag.setModified(true);s.setModified(true);try(var out=new FileOutputStream(args[1])){s.saveTo(out);}System.out.println("Legacy removal: "+stubs+" inert methods, "+flags+" obsolete flag reads removed, "+events+" old event registrations removed");
 }
}
