package disney {
 import flash.display.MovieClip;import flash.geom.Point;import flash.text.TextField;import flash.utils.ByteArray;import flash.external.ExternalInterface;
 public class RgbMouseTests {
  private static var count:int=0;
  private static function check(ok:Boolean,text:String):void{if(!ok)throw new Error(text);count++;}
  private static function walk(x:Number,y:Number,vx:Number,vy:Number,delay:int,jump:Boolean=false):Array{return [{x:x,y:y,vx:vx,vy:vy,ml:false,mr:true,jump:jump,frame:0},"walk",delay];}
  private static function line():Array{return [walk(0,0,345,100,0),walk(345,100,345,100,1000),["hole",100]];}
  private static function fixture(display:MovieClip):Object{
   var root:MovieClip=new MovieClip();display.addChild(root);root.stage.focus=root.stage;var writes:Array=[];var sync:int=0;
   var player:Object={x:0,y:0,body:null,clip:true,dead:false,left:false,right:false,down:false,side:true,jump:function(...args):void{},crouch:function(...args):void{},stand:function(...args):void{}};
   var body:Object={locked:false,velocity:{vx:3.45,vy:1},setPosition:function(p:Point,angle:Number):Boolean{if(body.locked)return false;writes.push({fromX:player.x,fromY:player.y,x:p.x*30,y:p.y*30});return true;}};player.body=body;
   root.Keys={player:"mouse",player_physics:"body",player_clip:"clip",is_dead:"dead",player_moving_left:"left",player_moving_right:"right",jump:"jump",is_down:"down",crouch:"crouch",crouch2:"stand",static_side:"side",physics_state:"velocity",physics_state_vx:"vx",physics_state_vy:"vy",bot_set_position:"setPosition",b2vec2:"Point",app_domain:{applicationDomain:{getDefinition:function(n:String):Class{return Point;}}},map_class:{current:{number:{value:123},container:{reverse:false}},width:800},map_instance:"current",bot_map_code_object:"number",bot_map_code_value:"value",obj_container:"container",bot_reverse:"reverse",bot_map_width:"width",move_class:{free:true},move_free:"free",timer_class:{locked:false},timer_prop:"locked",packet_handler_class:{receive:function(bytes:ByteArray):void{sync++;}},packet_handler:"receive"};
   root.tfm={mouse:player};root.Interface={status_field:new TextField()};root.host_url="";root.auto_play=true;
   return {root:root,player:player,body:body,writes:writes,motion:NativeMotion.get(root),owner:{}};
  }
  private static function runModel(display:MovieClip,frame:int):void{
   var f:Object=fixture(display);f.player.x=51.75;f.player.y=20;var corrector:RouteTrajectoryCorrection=new RouteTrajectoryCorrection();corrector.configure(RoutePlayerNative.validate(line()),false,800,10);corrector.frame(f.player,f.body,f.root.Keys,f.motion,f.owner,500,0);
   var initial:Number=Math.abs(103.5*f.player.y-30*f.player.x)/Math.sqrt(103.5*103.5+30*30);
   for(var t:int=frame;t<=480;t+=frame){f.player.x+=3.45*30*frame/1000;f.player.y+=30*frame/1000;corrector.frame(f.player,f.body,f.root.Keys,f.motion,f.owner,500+t,t);
    check(corrector.lastStep<=0.500001,"each frame displacement is bounded even at high FPS");
    check(f.body.velocity.vx==3.45 && f.body.velocity.vy==1,"smooth correction leaves native VX/VY unchanged");
   }
   var error:Number=Math.abs(103.5*f.player.y-30*f.player.x)/Math.sqrt(103.5*103.5+30*30);
   check(error<initial*0.5,"gradual correction reduces lateral drift in independent moving-body model at "+frame+"ms: "+error);
   check(corrector.distance<=24*0.48+0.0001,"total distance respects 24px/s independently of FPS");
   check(corrector.count>0 && f.writes.length==corrector.count,"only successful bounded body writes count as corrections");
   for each(var w:Object in f.writes){var dx:Number=w.x-w.fromX;var dy:Number=w.y-w.fromY;check(Math.sqrt(dx*dx+dy*dy)<=0.500001,"recorded setter call never jumps directly to a recorded waypoint");}
  }
  public static function run(display:MovieClip):void{try{
   var c:RouteTrajectoryCorrection=new RouteTrajectoryCorrection();c.configure(RoutePlayerNative.validate(line()),false,800,10);var p:Object=c.nearest(51.75,20,500);check(p && p.distance<6,"nearest point is found on current interpolated corridor");
   check(c.nearest(10000,10000,500)==null,"large divergence never requests a catch-up teleport");check(c.nearest(0,0,900)==null,"global old waypoint is not selected outside the local time window");
   c.configure(RoutePlayerNative.validate(line()),true,800,10);p=c.nearest(748.25,15,500);check(p && Math.abs(p.x-748.25)<0.01 && Math.abs(p.y-15)<0.01,"mirrored curve reflects position and horizontal tangents once");
   var arc:Array=[walk(0,0,345,65036,0,true),walk(69,-80,345,65236,200,true),["hole",100]];c.configure(RoutePlayerNative.validate(arc),false,800,10);p=c.nearest(10.35,-13.5,100);check(p && p.distance<0.01,"Hermite interpolation preserves the ballistic arc rather than a straight waypoint chord");
   var takeoff:Array=[walk(0,0,345,0,0,false),walk(69,0,345,65036,200,true),["hole",100]];c.configure(RoutePlayerNative.validate(takeoff),false,800,10);p=c.nearest(10.35,0,100);check(p && Math.abs(p.y)<0.01,"endpoint jump impulse is not smeared backwards over grounded approach");
   var discontinuity:Array=[walk(0,0,345,0,0),walk(1000,0,345,0,100),["hole",100]];c.configure(RoutePlayerNative.validate(discontinuity),false,800,10);check(c.nearest(150,0,50)==null,"inconsistent recorded teleport/collision segment is not treated as a safe straight path");
   runModel(display,16);runModel(display,1);
   var f:Object=fixture(display);f.player.x=51.75;f.player.y=20;c.configure(RoutePlayerNative.validate(line()),false,800,10);c.frame(f.player,f.body,f.root.Keys,f.motion,f.owner,500,0);c.frame(f.player,f.body,f.root.Keys,f.motion,f.owner,500,5000);check(c.lastStep<=0.5,"long frame stall cannot accumulate a large correction budget");
   f.body.velocity.vx=0;f.body.velocity.vy=0;var n:int=f.writes.length;c.frame(f.player,f.body,f.root.Keys,f.motion,f.owner,516,5016);check(f.writes.length==n,"stationary contact is not pushed through a wall or floor");
   f=fixture(display);var bot:RoutePlayerNative=new RoutePlayerNative(f.root);bot.setRoutes({"@123":line()});bot.setTiming(new RouteTiming(1,false));bot.advanceFrame(0);bot.advanceFrame(300);check(bot.completedSourceSteps==1 && bot.nextDeadline==1300,"first step and source deadline remain independent of correction");
   f.player.x=10.35;f.player.y=8;bot.advanceFrame(400);check(bot.smoothCorrectionCount==1 && bot.lastSmoothCorrection<=0.5,"frame path invokes bounded correction between recorded steps");check(bot.nextDeadline==1300 && bot.completedSourceSteps==1,"correction never changes deadline or waits for point arrival");
   f.player.x=500;f.player.y=500;n=f.writes.length;bot.advanceFrame(1300);check(bot.completedSourceSteps==2 && f.writes.length==n,"due source step advances without snapping a far-away body to the waypoint");f.root.auto_play=false;bot.advanceFrame(1301);n=f.writes.length;bot.advanceFrame(1400);check(f.writes.length==n,"disabled replay cannot keep correcting");
   f=fixture(display);bot=new RoutePlayerNative(f.root);bot.setRoutes({"@123":line()});bot.setTiming(new RouteTiming(1,false));bot.advanceFrame(0);bot.advanceFrame(300);f.player.x=10.35;f.player.y=8;f.body.locked=true;bot.advanceFrame(400);check(bot.nextDeadline==1300 && bot.smoothCorrectionCount==0 && bot.message.indexOf("erro")<0,"locked-world correction is skipped without pausing or shifting replay clock");f.body.locked=false;bot.advanceFrame(416);check(bot.smoothCorrectionCount==1 && bot.nextDeadline==1300,"small correction resumes after lock without catch-up burst");f.root.auto_play=false;bot.advanceFrame(417);
   ExternalInterface.call("recordTest","PASS: "+count+" smooth interpolation, bounded correction, clock and collision-guard checks");
  }catch(error:Error){ExternalInterface.call("recordTest","FAIL after "+count+" checks: "+error.message+" #"+error.errorID);}}
 }
}
