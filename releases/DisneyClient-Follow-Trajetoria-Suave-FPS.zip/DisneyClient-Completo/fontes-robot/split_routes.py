"""Generate bounded per-map JSON files; the Flash client never loads the full catalog."""
import argparse,json,pathlib,re,hashlib

def split(source,output):
    data=json.loads(source.read_text(encoding='utf-8-sig'))
    if not isinstance(data,dict) or not data:raise ValueError('Nonempty route dictionary required')
    output.mkdir(parents=True,exist_ok=True)
    biggest=0
    for code,steps in data.items():
        if not re.fullmatch(r'@(?:[0-9]+|a|v)',code) or not isinstance(steps,list):raise ValueError('Invalid map route')
        encoded=json.dumps(steps,ensure_ascii=False,separators=(',',':')).encode()
        name=output/(code[1:]+'.json');temporary=name.with_suffix('.json.tmp');temporary.write_bytes(encoded);temporary.replace(name)
        biggest=max(biggest,len(encoded))
    metadata={'entries':len(data),'largest_route_bytes':biggest,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()}
    (output/'manifest.json').write_text(json.dumps(metadata,indent=2)+'\n')
    return metadata
if __name__=='__main__':
    root=pathlib.Path(__file__).resolve().parents[1]
    p=argparse.ArgumentParser();p.add_argument('--input',type=pathlib.Path,default=root/'DisneyClient/public/rotas_decodificadas.json');p.add_argument('--output',type=pathlib.Path,default=root/'DisneyClient/public/rotas');a=p.parse_args();print(json.dumps(split(a.input,a.output)))
