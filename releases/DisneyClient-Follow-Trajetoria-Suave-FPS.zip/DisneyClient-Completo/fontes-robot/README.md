# Robot com microcorrecao interpolada

Fonte canonica: fontes-autoplay/RoutePlayer.as; RoutePlayerNative.as e gerada.
RouteTrajectoryCorrection.as constroi a curva e aplica ajustes limitados de
posicao por quadro. Os passos enviam teclas, sem snap no ponto gravado.
O interpolador nao altera o indice nem os prazos do executor.

Veja ../TRAJETORIA-SUAVE-LEIA-ME.txt e ../VALIDACAO-TRAJETORIA-SUAVE.json.
Limites: 0,5px por aplicacao, 24px/s, corredor local ate 18px, janela de 80ms.
A guarda de contato e conservadora por velocidade, nao uma consulta completa
da geometria; nao ha garantia de trajetoria perfeita nem ausencia de DC.

Build: python fontes-robot/build.py --ffdec /caminho/ffdec
Teste: RUFFLE_DIR=/caminho/ruffle node fontes-robot/run_tests.cjs
TEST_CASE=trajectory seleciona o teste especifico de interpolacao.
