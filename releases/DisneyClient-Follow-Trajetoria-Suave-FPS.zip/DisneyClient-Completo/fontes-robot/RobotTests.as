package disney {
 import flash.display.MovieClip;import flash.events.KeyboardEvent;import flash.geom.Point;import flash.text.TextField;import flash.utils.ByteArray;import flash.utils.getTimer;import flash.utils.setTimeout;import flash.external.ExternalInterface;
 public class RgbMouseTests {
  private static var count:int=0;
  private static function check(ok:Boolean,text:String):void{if(!ok)throw new Error(text);count++;}
  private static function walk(x:int,l:Boolean,r:Boolean,j:Boolean,delay:int):Array{return [{x:x,y:1102,vx:345,vy:65036,mr:r,ml:l,jump:j,frame:2},"walk",delay];}
  public static function run(display:MovieClip):void{try{
   var root:MovieClip=new MovieClip();display.addChild(root);root.stage.focus=root.stage;
   var writes:int=0;var syncs:int=0;var keys:Array=[];
   var body:Object={velocity:{vx:7,vy:-3},setPosition:function(p:Point,a:Number):Boolean{writes++;throw new Error("forbidden route reposition");}};
   var player:Object={x:30,y:330.6,body:body,clip:true,dead:false,left:false,right:false,down:false,side:true,jump:function(...args):void{},crouch:function(...args):void{},stand:function(...args):void{}};
   var map:Object={number:{value:123},container:{mirror:false}};
   root.Keys={player:"mouse",player_physics:"body",player_clip:"clip",is_dead:"dead",player_moving_left:"left",player_moving_right:"right",jump:"jump",is_down:"down",crouch:"crouch",crouch2:"stand",static_side:"side",physics_state:"velocity",physics_state_vx:"vx",physics_state_vy:"vy",bot_set_position:"setPosition",b2vec2:"Point",app_domain:{applicationDomain:{getDefinition:function(n:String):Class{return Point;}}},map_class:{current:map,width:800},map_instance:"current",bot_map_code_object:"number",bot_map_code_value:"value",obj_container:"container",bot_reverse:"mirror",bot_map_width:"width",move_class:{free:true},move_free:"free",timer_class:{locked:false},timer_prop:"locked",packet_handler_class:{receive:function(bytes:ByteArray):void{syncs++;}},packet_handler:"receive"};
   root.tfm={mouse:player};root.Interface={status_field:new TextField()};root.auto_play=true;
   root.stage.addEventListener(KeyboardEvent.KEY_DOWN,function(e:KeyboardEvent):void{if(NativeMotion.isSynthetic(root))keys.push({code:e.keyCode,down:true});});
   root.stage.addEventListener(KeyboardEvent.KEY_UP,function(e:KeyboardEvent):void{if(NativeMotion.isSynthetic(root))keys.push({code:e.keyCode,down:false});});
   var route:Array=[walk(100,false,true,false,0),walk(200,true,false,true,10),walk(300,false,false,false,5),["hole",100]];
   var before:String=com.adobe.serialization.json.JSON.encode(route);
   var bot:RoutePlayerNative=new RoutePlayerNative(root);bot.setRoutes({"@123":route});bot.setTiming(new RouteTiming(1,false));
   bot.advance(0);bot.advance(249);check(keys.length==0,"original startup wait is preserved");
   bot.advance(300);check(player.right && !player.left,"first recorded step emits RIGHT");check(bot.message.indexOf("1/4")>=0,"first step advances exactly one index");
   check(writes==0 && syncs==1,"Robot initial sync is preserved once while route samples never reposition");
   bot.advance(309);check(player.right && bot.message.indexOf("1/4")>=0,"source deadline is not anticipated");
   bot.advance(310);check(player.left && !player.right && bot.message.indexOf("2/4")>=0,"10ms direction/jump transition is no longer held back by 33ms");
   var jumpDowns:int=0;for each(var key:Object in keys)if(key.code==38 && key.down)jumpDowns++;check(jumpDowns==1,"native UP edge remains exact at its recorded transition");
   bot.advance(315);check(!player.left && !player.right && bot.message.indexOf("3/4")>=0,"5ms neutral transition retains its absolute source deadline");
   check(player.x==30 && player.y==330.6 && writes==0 && syncs==1,"all steps advance by source time without position correction or arrival gate");
   check(body.velocity.vx==7 && body.velocity.vy==-3,"native velocity is never assigned by Robot");
   bot.advance(414);check(bot.message.indexOf("3/4")>=0,"terminal delay is not shortened");bot.advance(415);check(bot.message.indexOf("confirmacao")>=0,"terminal deadline remains 415ms from original epoch");
   root.auto_play=false;bot.advance(416);
   var dense:Array=[];for(var i:int=0;i<100;i++)dense.push(walk(100+i,i%2==1,i%2==0,false,i==0 ? 0 : 10));dense.push(["hole",100]);
   var denseBot:RoutePlayerNative=new RoutePlayerNative(root);denseBot.setRoutes({"@123":dense});denseBot.setTiming(new RouteTiming(1,true));root.auto_play=true;denseBot.advance(0);denseBot.advance(300);
   for(var tick:int=317;tick<1290;tick+=17){denseBot.advance(tick);var expected:int=Math.min(100,1+int((tick-300)/10));check(denseBot.completedSourceSteps==expected,"irregular frames do not drop due source records");check(denseBot.nextDeadline==(expected<100 ? 300+expected*10 : 1390),"frame lateness never shifts the following deadline");check(denseBot.message.indexOf("microparada")<0,"random rests do not alter the source clock");}
   denseBot.advance(1291);check(denseBot.completedSourceSteps==100 && denseBot.nextDeadline==1390,"100 short intervals retain their exact accumulated duration");denseBot.advance(1390);check(denseBot.message.indexOf("confirmacao")>=0,"source-time terminal marker remains fixed after irregular updates");root.auto_play=false;denseBot.advance(1391);
   var decoded:Object=RoutePlayerNative.decodeMovement(walk(100,false,true,true,0)[0]);var beforeJump:Object={jump:true,vy:-2};var fresh:Object={jump:true,vy:-5};check(RoutePlayerNative.freshJump(beforeJump,fresh,300,10),"new VY impulse can be recognized while jump flag stays true");
   var impulse:Array=[walk(100,false,true,true,0),walk(200,false,true,true,300),["hole",100]];impulse[0][0].vy=65036;impulse[1][0].vy=65036;
   var impulseBot:RoutePlayerNative=new RoutePlayerNative(root);impulseBot.setRoutes({"@123":impulse});impulseBot.setTiming(new RouteTiming(1,false));root.auto_play=true;impulseBot.advance(0);var n:int=0;for each(key in keys)if(key.code==38 && key.down)n++;impulseBot.advance(300);impulseBot.advance(600);var m:int=0;for each(key in keys)if(key.code==38 && key.down)m++;check(m-n==2,"second recorded impulse releases and represses UP instead of losing the jump");root.auto_play=false;impulseBot.advance(601);

   var timed:RoutePlayerNative=new RoutePlayerNative(root);timed.setRoutes({"@123":[walk(100,false,true,false,0),walk(200,true,false,false,45),walk(300,false,false,false,45),["hole",50]]});timed.setTiming(new RouteTiming(1,false));root.auto_play=true;timed.useTimers(true);var start:int=getTimer();timed.advance(start);var polls:int=0;
   var bootstrap:Function=function():void{try{if(getTimer()<start+260){setTimeout(bootstrap,20);return;}var epoch:int=getTimer();timed.advance(epoch);var poll:Function=function():void{try{polls++;if(timed.message.indexOf("confirmacao")<0){if(polls>200)throw new Error("timer stalled: "+timed.message);setTimeout(poll,20);return;}check(timed.completedSourceSteps==4 && getTimer()>=epoch+140,"single native timer runs the source sequence without manual frame ticks");root.auto_play=false;timed.advance(getTimer());check(writes==0,"timed callbacks never correct the player position");ExternalInterface.call("recordTest","PASS: "+count+" absolute-clock precision and native-key checks");}catch(e:Error){ExternalInterface.call("recordTest","FAIL: "+e.message+" #"+e.errorID);}};setTimeout(poll,20);}catch(e:Error){ExternalInterface.call("recordTest","FAIL: "+e.message+" #"+e.errorID);}};setTimeout(bootstrap,20);
  }catch(error:Error){ExternalInterface.call("recordTest","FAIL after "+count+" checks: "+error.message+" #"+error.errorID);}}
 }
}
