package disney {
 import flash.display.MovieClip;import flash.display.DisplayObject;import flash.display.InteractiveObject;import flash.events.Event;import flash.events.KeyboardEvent;import flash.events.IOErrorEvent;import flash.events.SecurityErrorEvent;import flash.net.URLLoader;import flash.net.URLRequest;import flash.text.TextField;import flash.utils.Dictionary;import flash.utils.getTimer;import flash.utils.ByteArray;import flash.utils.setTimeout;import flash.utils.clearTimeout;
 public class RoutePlayerNative {
  private var cheeseConfirmed:Boolean=false;private var cheeseWaitUntil:int=-1;private var cheeseWaitStarted:int=0;private var managed:Boolean=false;private var managedOn:Boolean=false;private var worldSpace:Boolean=false;
  private static var instances:Dictionary=new Dictionary(true);
  private var correction:RouteTrajectoryCorrection;private var correctionFrame:Boolean=false;
  private var focused:Boolean=true;private var suspendedAt:int=-1;private var roundToken:String="";private var restartPending:Boolean=false;private var waitingSpawn:Boolean=false;private var restUntil:int=0;private var restAt:int=0;private var lastState:Object;private var timing:RouteTiming;private var synchronized:Boolean=false;
  private var remote:Boolean=true;private var loadingCode:String="";private var failedCode:String="";private var cacheOrder:Array=[];private var root:MovieClip;private var motion:NativeMotion;private var routes:Object;private var loadError:String="";private var loader:URLLoader;
  private var map:Object;private var player:Object;private var body:Object;private var code:String="";private var aliveBefore:Boolean=false;
  private var sequence:Array;private var index:int=0;private var due:Number=0;private var recordedElapsed:Number=0;private var lastWalkRecordedAt:Number=0;private var gravity:Number=10;private var automatic:Boolean=false;private var wake:uint=0;private var version:uint=0;private var settle:int=0;private var enabled:Boolean=false;private var attempted:Boolean=false;private var running:Boolean=false;private var paused:Boolean=false;
  private var mirror:Boolean=false;private var width:Number=800;private var pauseMessage:String="Robot: pausado; reative para reiniciar";private var hasSample:Boolean=false;private var won:Boolean=false;private var entering:Boolean=false;private var holeWaitUntil:int=0;private var retryAt:int=0;private var failure:String="";public var message:String="Robot: aguardando jogo";
  public function RoutePlayerNative(value:MovieClip,external:Boolean=false){managed=external;root=value;correction=new RouteTrajectoryCorrection();timing=new RouteTiming(uint(getTimer())^uint(Math.random()*2147483647));motion=NativeMotion.get(value);if(!managed)motion.observeWith(packet);routes={};}
  public function setManagedActive(value:Boolean):void{if(!managed)return;managedOn=value;if(!value){cancelLoad();reset(getTimer());enabled=false;}}
  public function setWorldSpace(value:Boolean):void{worldSpace=value;}
  public static function attach(value:MovieClip):void{
   if(!value || !value.stage || instances[value])return;var r:RoutePlayerNative=new RoutePlayerNative(value);instances[value]=r;r.loadRoutes();r.automatic=true;
   value.stage.addEventListener(Event.ACTIVATE,function(e:Event):void{r.setFocused(true);});
   value.stage.addEventListener(Event.DEACTIVATE,function(e:Event):void{r.setFocused(false);});
   value.stage.addEventListener(Event.ENTER_FRAME,function(e:Event):void{r.advanceFrame(getTimer());},false,1000);
   value.stage.addEventListener(KeyboardEvent.KEY_DOWN,function(e:KeyboardEvent):void{
    if(NativeMotion.isSynthetic(value))return;
    if(value.stage.focus is TextField && TextField(value.stage.focus).type=="input")return;
    if(value["auto_play_disable_on_move"] && [37,38,39,40,65,68,83,87].indexOf(e.keyCode)>=0)r.pause();
   });
  }
  // Compatibility entry point: arming the loader performs no I/O or catalog parsing.
  public function loadRoutes():void{remote=true;failedCode="";loadError="";}
  private function cancelLoad():void{if(loader){try{loader.close();}catch(e:Error){}loader=null;}loadingCode="";}
  private function requestRoute(which:String):void{
   if(loadingCode==which || failedCode==which)return;cancelLoad();loadingCode=which;loadError="";
   var current:URLLoader=new URLLoader();loader=current;
   current.addEventListener(Event.COMPLETE,function(e:Event):void{
    if(loader!==current)return;
    try{var text:String=String(current.data);if(text.length>262144)throw new Error("Route file too large",2520);routes[which]=decodeRoute(text);current.data="";cacheOrder.push(which);while(cacheOrder.length>4){var old:String=String(cacheOrder.shift());if(old!=which)delete routes[old];}loader=null;loadingCode="";}
    catch(error:Error){failedCode=which;loadError="rota invalida #"+error.errorID;loader=null;loadingCode="";}
   });
   var fail:Function=function(e:Event):void{if(loader!==current)return;failedCode=which;loadError="nao foi possivel carregar public/rotas/"+which.substr(1)+".json";loader=null;loadingCode="";};
   current.addEventListener(IOErrorEvent.IO_ERROR,fail);current.addEventListener(SecurityErrorEvent.SECURITY_ERROR,fail);
   try{current.load(new URLRequest(String(root["host_url"])+"public/rotas/"+which.substr(1)+".json"));}catch(error:Error){fail(new Event("error"));}
  }
  public function setRoutes(value:Object):void{
   if(!value || value is Array)throw new Error("Route dictionary required",2501);
   var total:int=0;for(var name:String in value){if(!/^@(?:[0-9]+|a|v)$/.test(name) || !(value[name] is Array))throw new Error("Invalid map route",2502);total++;}
   if(total==0)throw new Error("Empty route dictionary",2503);cancelLoad();remote=false;routes=value;loadError="";
  }
  private function status(text:String):void{message=text;var ui:Object=root["Interface"];if(ui && ui["status_field"])ui["status_field"].text=text;}
  private function release():void{correction.resetSampling();motion.release(this);}
  public function pause():void{if(!enabled)return;cancelWake();release();running=false;paused=true;pauseMessage="Robot: pausado pela tecla; reative para reiniciar";status(pauseMessage);}
  private function reset(now:int):void{cancelWake();correction.reset();cheeseConfirmed=false;cheeseWaitUntil=-1;release();running=false;attempted=false;paused=false;failure="";won=false;entering=false;holeWaitUntil=0;sequence=null;index=0;recordedElapsed=0;lastWalkRecordedAt=0;gravity=10;hasSample=false;synchronized=false;timing.reset(now);restUntil=0;lastState=null;waitingSpawn=false;restartPending=false;suspendedAt=-1;retryAt=0;settle=now+250;}
  public function setFocused(value:Boolean):void{focused=value;if(!value){cancelWake();release();}}
  public function setTiming(policy:RouteTiming):void{timing=policy ? policy : new RouteTiming(1,false);}
  private function hasMovement(route:Array):Boolean{for each(var step:Array in route){if(step[1]=="hole")return false;if(step[1]=="walk")return true;}return false;}
  private static function integer(value:*,minimum:Number,maximum:Number):Boolean{return value is Number && isFinite(Number(value)) && Number(value)==Math.floor(Number(value)) && Number(value)>=minimum && Number(value)<=maximum;}
  public static function decodeRoute(text:String):Array{return validate(com.adobe.serialization.json.JSON.decode(text) as Array);}
  public static function validate(route:Array):Array{
   if(!route || route.length==0 || route.length>100000)throw new Error("Invalid route",2001);var result:Array=[];
   for each(var step:Array in route){
    if(!step || (step.length!=2 && step.length!=3))throw new Error("Invalid step shape",2002);
    var action:String=String(step[step.length-2]);var delay:* =step[step.length-1];
    if(!integer(delay,0,3600000))throw new Error("Invalid delay",2002);
    if(["walk","cheese","hole","crouch","duck","emote"].indexOf(action)<0)throw new Error("Unknown action",2003);
    if(step.length==2 && action!="cheese" && action!="hole")throw new Error("Missing payload",2004);
    var payload:Object=step.length==3 ? step[0] : null;
    if(action=="walk"){
     if(!payload || payload is Array)throw new Error("Invalid movement",2004);
     if(!integer(payload.x,-2147483648,4294967295) || !integer(payload.y,-2147483648,4294967295) || !integer(payload.vx,-32768,65535) || !integer(payload.vy,-32768,65535) || !integer(payload.frame,-128,255))throw new Error("Invalid native numbers",2004);
     if(!(payload.mr is Boolean)||!(payload.ml is Boolean)||!(payload.jump is Boolean))throw new Error("Invalid direction flags",2004);
    }
    if((action=="crouch" || action=="duck") && !integer(payload,0,1))throw new Error("Invalid crouch",2004);
    result.push([payload,action,Number(delay)]);
   }return result;
  }
  public function packet(bytes:ByteArray):void{
   if(!enabled || bytes.bytesAvailable<2)return;
   var c:int=bytes.readUnsignedByte();var cc:int=bytes.readUnsignedByte();
   if(c==5 && cc==2){restartPending=true;return;}
   var k:Object=root["Keys"];var local:Object=k && root["tfm"] ? root["tfm"][k.player] : null;
   if(c==144 && cc==6 && bytes.bytesAvailable>=4){var cheeseId:int=bytes.readInt();if(local && k.player_id && cheeseId==int(local[k.player_id]))cheeseConfirmed=true;return;}
   if(c==144 && cc==2){bytes.readUTF();if(bytes.bytesAvailable>=4 && local && k.player_id && int(local[k.player_id])==bytes.readInt())restartPending=true;return;}
   if(!attempted || (!running && !entering) || c!=8 || cc!=6 || bytes.bytesAvailable<5)return;
   bytes.readUnsignedByte();var id:int=bytes.readInt();
   if(local && k.player_id && k.player_id in local && int(local[k.player_id])==id){won=true;entering=true;running=false;restUntil=0;release();}
  }
  private function waitForSpawn(text:String):Boolean{waitingSpawn=true;restUntil=0;release();status("Robot: aguardando renascer para ressincronizar | "+text+" | "+code);return false;}
  private function nativeRest():Boolean{
   try{var k:Object=root["Keys"];if(!k.is_jumping || !(k.is_jumping in player) || !(player[k.is_jumping] is Boolean) || player[k.is_jumping])return false;
    var getter:Function=k.get_linear_velocity && k.get_linear_velocity in body ? body[k.get_linear_velocity] as Function : null;
    var velocity:Object=getter!=null ? getter.apply(body,[]) : body[k.physics_state];
    return velocity && k.physics_state_vy in velocity && isFinite(Number(velocity[k.physics_state_vy])) && Math.abs(Number(velocity[k.physics_state_vy]))<=0.02;
   }catch(error:Error){return false;}
  }
  private function canMicroRest(next:Array):Boolean{
   if(!lastState || !next || next[1]!="walk" || Number(next[2])<80 || !nativeRest())return false;
   var p:Object=lastState;var q:Object=decodeMovement(next[0]);if(mirror){q.x=width-q.x;var right:Boolean=q.mr;q.mr=q.ml;q.ml=right;}
   return !p.jump && !q.jump && p.vy==0 && q.vy==0 && p.mr!=p.ml && q.mr==p.mr && q.ml==p.ml && Math.abs(p.y-q.y)<=0.5 && Math.abs(Number(player.x)-p.x)<=4 && Math.abs(Number(player.y)-p.y)<=1;
  }
  public function advanceFrame(now:int):void{correctionFrame=true;try{advance(now);}finally{correctionFrame=false;}}
  public function get smoothCorrectionCount():int{return correction.count;}
  public function get lastSmoothCorrection():Number{return correction.lastStep;}
  public function useTimers(value:Boolean):void{automatic=value;if(!value)cancelWake();}
  public function get nextDeadline():Number{return running ? due : -1;}
  public function get completedSourceSteps():int{return index;}
  private function cancelWake():void{version++;if(wake){clearTimeout(wake);wake=0;}}
  private function arm(now:int):void{
   if(!automatic || !running || !focused || suspendedAt>=0)return;
   var expected:uint=version;var delay:int=Math.max(1,Math.ceil(due-now));
   wake=setTimeout(function():void{if(expected!=version)return;wake=0;advance(getTimer());},delay);
  }
  public function advance(now:int):void{cancelWake();tick(now);arm(automatic ? getTimer() : now);}
  private function tick(now:int):void{try{update(now);}catch(error:Error){release();if(error.errorID==2601 || error.errorID==2602 || error.errorID==2603){running=false;paused=true;pauseMessage="Robot: pausado | "+error.message+" | "+code;status(pauseMessage);return;}if(error.errorID==2408){retryAt=now+500;status("Robot: aguardando sincronizacao nativa #2408");return;}if(error.errorID==2403){retryAt=now+500;due+=500;status("Robot: fisica bloqueada; aguardando proximo quadro");return;}running=false;attempted=true;failure="Robot: erro #"+error.errorID+"; reative para tentar novamente";status(failure);}}
  private function update(now:int):void{
   var oldUi:Object=root["Interface"];var preview:DisplayObject=oldUi ? oldUi["preview_button"] as DisplayObject : null;
   if(preview){preview.visible=false;if(preview is InteractiveObject)InteractiveObject(preview).mouseEnabled=false;}

   var active:Boolean=managed ? managedOn : Boolean(root["auto_play"]);
   if(!active){cancelLoad();release();running=false;enabled=false;attempted=false;paused=false;failure="";status("Robot: desligado");return;}
   var k:Object=root["Keys"];var game:Object=root["tfm"];if(!k || !game){status("Robot: aguardando jogo");return;}
   if(!enabled){failedCode="";loadError="";enabled=true;if(!managed)FollowControllerV13Shared.stopForRobot(root);reset(now);}
   for each(var symbol:String in ["bot_map_code_object","bot_map_code_value","bot_reverse","bot_map_width","player_physics","bot_set_position","b2vec2"]){if(!k[symbol]){release();status("Robot: simbolo ausente: "+symbol);return;}}
   var nextMap:Object=k.map_class ? k.map_class[k.map_instance] : null;var nextPlayer:Object=game[k.player];var nextBody:Object=nextPlayer ? nextPlayer[k.player_physics] : null;
   if(!nextMap || !nextPlayer){if(entering && nextMap===map){release();status(won ? "Robot: vitoria confirmada; aguardando renascer" : "Robot: aguardando confirmacao da toca");return;}reset(now);map=null;player=null;body=null;aliveBefore=false;status("Robot: aguardando mapa/jogador");return;}
   var numberObject:Object=nextMap[k.bot_map_code_object];var number:Number=numberObject ? Number(numberObject[k.bot_map_code_value]) : NaN;
   if(!isFinite(number)||number<=0||number!=Math.floor(number)){release();status("Robot: aguardando codigo @ do mapa");return;}
   var nextCode:String="@"+number.toFixed(0);var alive:Boolean=Boolean(nextBody) && Boolean(nextPlayer[k.player_clip]) && !nextPlayer[k.is_dead];
   var token:String="current_round_code" in root ? String(root["current_round_code"]) : "";
   if(restartPending || token!=roundToken || nextMap!==map || nextCode!=code || (alive && (!aliveBefore || nextPlayer!==player || nextBody!==body)))reset(now);
   roundToken=token;map=nextMap;player=nextPlayer;body=nextBody;code=nextCode;aliveBefore=alive;root["current_map_code"]=code;root["current_map_code_int"]=int(number);
   if(entering){release();running=false;if(won)status("Robot: vitoria confirmada; aguardando proxima rodada");else if(now>holeWaitUntil)status("Robot: toca nao confirmada; reative para tentar novamente");else status("Robot: aguardando confirmacao nativa da toca");return;}
   if(motion.finished()){release();running=false;status("Robot: toca confirmada; aguardando renascer");return;}
   if(!alive){release();running=false;attempted=false;status("Robot: aguardando renascer | "+code);return;}
   if(waitingSpawn){release();return;}
   if(!focused || root.stage.focus is TextField && TextField(root.stage.focus).type=="input"){
    if(suspendedAt<0){suspendedAt=now;release();}status("Robot: aguardando foco/edicao de texto");return;
   }
   if(suspendedAt>=0){var suspended:int=Math.max(0,now-suspendedAt);due+=suspended;if(restUntil>0){restAt+=suspended;restUntil+=suspended;}suspendedAt=-1;if(lastState && restUntil==0)motion.movement(this,lastState.ml,lastState.mr,lastState.jump);}
   if(paused){status(pauseMessage);return;}
   if(failure!=""){status(failure);return;}
   width=Number(k.map_class[k.bot_map_width]);if(!isFinite(width)||width<1||width>100000)throw new Error("Invalid map width",2504);
   mirror=!worldSpace && Boolean(map[k.obj_container][k.bot_reverse]);
   if(now<settle || !k.move_class || !k.move_class[k.move_free] || (k.timer_class && k.timer_class[k.timer_prop])){
    if(running)reset(now);status("Robot: aguardando liberacao da rodada | "+code);return;
   }
   if(now<retryAt)return;
   if(!routes){status("Robot: "+(loadError!="" ? loadError : "carregando rotas_decodificadas.json"));return;}
   if(!attempted){
    var saved:Object=routes[code];if(!saved){if(remote){requestRoute(code);status("Robot: "+(loadError!="" ? loadError : "carregando rota "+code));}else status("Robot: sem rota para "+code);return;}
    sequence=saved is String ? decodeRoute(String(saved)) : validate(saved as Array);if(!synchronized && hasMovement(sequence)){motion.synchronizeCurrent();if(game[k.player]!==player || k.map_class[k.map_instance]!==map || player[k.is_dead] || !player[k.player_clip] || !player[k.player_physics])throw new Error("Lifecycle changed during sync",2408);body=player[k.player_physics];synchronized=true;}index=0;attempted=true;running=true;gravity=estimateRouteGravity(sequence);correction.configure(sequence,mirror,width,gravity);recordedElapsed=Number(sequence[0][2]);due=(automatic ? getTimer() : now)+recordedElapsed;
   }
   if(!running){status("Robot: rota finalizada | "+code+" | aguardando proximo mapa");return;}
   if(automatic)now=getTimer();
   var count:int=0;
   while(running && now>=due && count<256){
    var step:Array=sequence[index];
    if(!apply(step,k,now))return;index++;count++;
    if(entering)break;
    if(index>=sequence.length){running=false;release();break;}
    recordedElapsed+=Number(sequence[index][2]);
    due+=Number(sequence[index][2]);
    if(automatic)now=getTimer();
   }
   if(entering){status("Robot: aguardando confirmacao nativa da toca");return;}
   if(correctionFrame && running && hasSample && cheeseWaitUntil<0)correction.frame(player,body,k,motion,this,recordedElapsed-(due-now),now);
   status(running ? "Robot: executando "+code+" | "+index+"/"+sequence.length : "Robot: rota finalizada | "+code);
  }
  public static function freshJump(before:Object,p:Object,elapsed:Number,g:Number=10):Boolean{
   if(!p.jump)return false;if(!before || !before.jump)return true;
   return elapsed>0 && Math.abs(Number(p.vy)+5)<=0.2 && Number(before.vy)+g*elapsed/1000-Number(p.vy)>2;
  }
  public static function estimateRouteGravity(route:Array):Number{
   var values:Array=[];var previous:Object;var previousTime:Number=0;var time:Number=0;
   for each(var step:Array in route){time+=Number(step[2]);if(step[1]=="hole")break;if(step[1]!="walk")continue;var p:Object=decodeMovement(step[0]);
    if(previous){var dt:Number=(time-previousTime)/1000;var dy:Number=p.y-previous.y;
     if(dt>=0.03 && dt<=0.5 && p.vy>previous.vy && Math.abs(dy-30*(previous.vy+p.vy)*0.5*dt)<=Math.max(2,Math.abs(dy)*0.1)){var g:Number=(p.vy-previous.vy)/dt;if(g>=2 && g<=30)values.push(g);}
    }previous=p;previousTime=time;
   }
   if(values.length<6)return 10;values.sort(Array.NUMERIC);var i:int=values.length>>1;return values.length%2 ? Number(values[i]) : (Number(values[i-1])+Number(values[i]))/2;
  }
  public static function decodeMovement(p:Object):Object{
   // ByteArray conversion deliberately matches Statements.step from the loader:
   // unsigned JSON integers round-trip through signed int32/int16 wire fields.
   var b:ByteArray=new ByteArray();b.writeInt(Number(p.x));b.writeInt(Number(p.y));b.writeShort(Number(p.vx));b.writeShort(Number(p.vy));b.position=0;
   return {x:b.readInt()/100*30,y:b.readInt()/100*30,vx:b.readShort()/100,vy:b.readShort()/100,frame:int(p.frame)<<24>>24,mr:Boolean(p.mr),ml:Boolean(p.ml),jump:Boolean(p.jump)};
  }
  private function apply(step:Array,k:Object,now:int):Boolean{
   var action:String=String(step[1]);
   if(action=="walk"){
    var p:Object=decodeMovement(step[0]);
    if(mirror){p.x=width-p.x;p.vx=-p.vx;var oldRight:Boolean=p.mr;p.mr=p.ml;p.ml=oldRight;}
    var dx:Number=p.x-Number(player.x);var dy:Number=p.y-Number(player.y);var error:Number=Math.sqrt(dx*dx+dy*dy);
    if(!isFinite(error))throw new Error("Posicao local indisponivel",2601);
    if(!hasSample && error>96)return waitForSpawn("inicio da rota distante "+Math.round(error)+"px");
    // Recorded control flags represent braking even when VX still points the other way.
    if(lastState && lastState.jump && freshJump(lastState,p,recordedElapsed-lastWalkRecordedAt,gravity))motion.movement(this,p.ml,p.mr,false);
    motion.movement(this,p.ml,p.mr,p.jump);lastState=p;lastWalkRecordedAt=recordedElapsed;hasSample=true;
   }else if(action=="crouch" || action=="duck")motion.crouch(this,Number(step[0])!=0);
   else if(action=="cheese"){
    if(managed){
     var actual:Boolean=cheeseConfirmed || (k.player_cheese && Boolean(player[k.player_cheese]));
     if(!actual){if(cheeseWaitUntil<0){cheeseWaitStarted=now;cheeseWaitUntil=now+1500;}if(now>=cheeseWaitUntil)throw new Error("Queijo nao confirmado",2604);status("Robot: aguardando queijo nativo");return false;}
     if(cheeseWaitUntil>=0){due+=Math.max(0,now-cheeseWaitStarted);cheeseWaitUntil=-1;}
    }
   }
   else if(action=="hole"){entering=true;running=false;holeWaitUntil=now+3000;release();}
   return true;
  }
 }
}
