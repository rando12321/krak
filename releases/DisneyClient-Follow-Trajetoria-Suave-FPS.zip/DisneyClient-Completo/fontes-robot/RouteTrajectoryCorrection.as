package disney {
 // Continuous, bounded position nudges toward a local interpolated corridor.
 // No source-index gate, deadline changes, velocity writes or waypoint snaps.
 public class RouteTrajectoryCorrection {
  public static const MAX_STEP:Number=0.5;
  public static const MAX_RATE:Number=24;
  public static const MAX_ERROR:Number=18;
  private var segments:Array=[];private var previousPose:Object;private var lastNow:Number=-1;private var phase:Number=0;
  public var count:int=0;public var distance:Number=0;public var lastStep:Number=0;public var skipped:int=0;
  public function reset():void{segments=[];phase=0;count=0;distance=0;skipped=0;resetSampling();}
  public function resetSampling():void{previousPose=null;lastNow=-1;lastStep=0;}
  private static function signed(value:Number):Number{return Number(int(value)<<16>>16)/100*30;}
  private static function point(p:Object,t:Number,mirror:Boolean,width:Number):Object{return {t:t,x:mirror ? width-int(Number(p.x))*0.3 : int(Number(p.x))*0.3,y:int(Number(p.y))*0.3,vx:(mirror ? -1 : 1)*signed(Number(p.vx)),vy:signed(Number(p.vy)),jump:Boolean(p.jump)};}
  public function configure(route:Array,mirror:Boolean,width:Number,gravity:Number=10):void{
   reset();var previous:Object;var time:Number=0;
   for each(var step:Array in route){time+=Number(step[2]);if(step[1]=="hole")break;if(step[1]!="walk")continue;var p:Object=point(step[0],time,mirror,width);
    if(previous && time>previous.t){var dt:Number=(time-previous.t)/1000;var dx:Number=p.x-previous.x;var dy:Number=p.y-previous.y;var endVY:Number=p.vy;
     var impulse:Boolean=p.jump && (!previous.jump || (Math.abs(p.vy+150)<=6 && previous.vy+gravity*30*dt-p.vy>60));
     if(impulse)endVY=Math.abs(previous.vy)<=10.5 && Math.abs(dy)<=1 ? 0 : previous.vy+gravity*30*dt;
     var safe:Boolean=dt<=1 && dx*dx+dy*dy<=62500 && Math.abs(dx-(previous.vx+p.vx)*0.5*dt)<=Math.max(3,Math.abs(dx)*0.25) && Math.abs(dy-(previous.vy+endVY)*0.5*dt)<=Math.max(4,Math.abs(dy)*0.15);
     var segment:Object={a:previous,b:p,dt:dt,endVY:endVY,safe:safe};
     if(safe)for(var q:int=1;q<=3;q++){var sample:Object=evaluate(segment,previous.t+(time-previous.t)*q/4);if(sample.x<Math.min(previous.x,p.x)-6 || sample.x>Math.max(previous.x,p.x)+6 || sample.y<Math.min(previous.y,p.y)-6 || sample.y>Math.max(previous.y,p.y)+6)segment.safe=false;}
     segments.push(segment);
    }previous=p;
   }
  }
  private static function evaluate(s:Object,time:Number):Object{
   var u:Number=Math.max(0,Math.min(1,(time-s.a.t)/(s.b.t-s.a.t)));var u2:Number=u*u;var u3:Number=u2*u;var h0:Number=2*u3-3*u2+1;var h1:Number=u3-2*u2+u;var h2:Number=-2*u3+3*u2;var h3:Number=u3-u2;
   return {x:h0*s.a.x+h1*s.dt*s.a.vx+h2*s.b.x+h3*s.dt*s.b.vx,y:h0*s.a.y+h1*s.dt*s.a.vy+h2*s.b.y+h3*s.dt*s.endVY};
  }
  public function nearest(x:Number,y:Number,time:Number):Object{
   var lo:int=0;var hi:int=segments.length;
   while(lo<hi){var mid:int=(lo+hi)>>1;if(segments[mid].b.t<time)lo=mid+1;else hi=mid;}
   var best:Object;var bestDistance:Number=1e100;
   for(var i:int=Math.max(0,lo-1);i<Math.min(segments.length,lo+2);i++){
    var s:Object=segments[i];if(!s.safe)continue;
    var from:Number=Math.max(s.a.t,time-80,phase);var to:Number=Math.min(s.b.t,time+80);if(from>to)continue;
    var a:Object=evaluate(s,from);var at:Number=from;
    for(var n:int=1;n<=8;n++){
     var bt:Number=from+(to-from)*n/8;var b:Object=evaluate(s,bt);var dx:Number=b.x-a.x;var dy:Number=b.y-a.y;var length:Number=dx*dx+dy*dy;var u:Number=length>0 ? Math.max(0,Math.min(1,((x-a.x)*dx+(y-a.y)*dy)/length)) : 0;
     var t:Number=at+(bt-at)*u;var p:Object=evaluate(s,t);var ex:Number=p.x-x;var ey:Number=p.y-y;var d:Number=ex*ex+ey*ey;
     if(d<bestDistance){bestDistance=d;best={x:p.x,y:p.y,t:t,distance:Math.sqrt(d),segment:s};}
     a=b;at=bt;
    }
   }
   if(!best || best.distance>MAX_ERROR)return null;
   var reference:Object=evaluate(best.segment,Math.max(best.segment.a.t,Math.min(best.segment.b.t,time)));
   best.x=best.x*0.8+reference.x*0.2;best.y=best.y*0.8+reference.y*0.2;return best;
  }
  private static function read(o:Object,key:*):*{try{if(o && key!=null && key in o)return o[key];}catch(e:Error){}return null;}
  private static function component(o:Object,key:*,fallback:*):Number{var v:* =read(o,key);if(v==null)v=read(o,fallback);return v is Number && isFinite(Number(v)) ? Number(v) : NaN;}
  public function frame(player:Object,body:Object,k:Object,motion:NativeMotion,owner:Object,time:Number,now:Number):Boolean{
   lastStep=0;if(lastNow<0){lastNow=now;return false;}var milliseconds:Number=now-lastNow;if(milliseconds<8)return false;lastNow=now;
   if(milliseconds<=0 || !segments.length)return false;var dt:Number=Math.min(33,milliseconds)/1000;
   try{
    var x:Number=Number(player.x);var y:Number=Number(player.y);var transform:Function=read(body,k.get_x_form) as Function;
    if(transform!=null){var t:Object=transform.apply(body,[]);var pos:Object=t ? t.position : null;var px:Number=component(pos,k.pos_x,"x");var py:Number=component(pos,k.pos_y,"y");if(isFinite(px) && isFinite(py)){x=px*30;y=py*30;}}
    if(!isFinite(x)||!isFinite(y))return false;
    var getter:Function=read(body,k.get_linear_velocity) as Function;var velocity:Object=getter!=null ? getter.apply(body,[]) : read(body,k.physics_state);
    var vx:Number=component(velocity,k.pos_x,k.physics_state_vx)*30;var vy:Number=component(velocity,k.pos_y,k.physics_state_vy)*30;
    if(!isFinite(vx) || !isFinite(vy)){if(previousPose && now>previousPose.time && now-previousPose.time<=100){vx=(x-previousPose.x)*1000/(now-previousPose.time);vy=(y-previousPose.y)*1000/(now-previousPose.time);}else{vx=0;vy=0;}}
    previousPose={x:x,y:y,time:now};var target:Object=nearest(x,y,time);if(!target){skipped++;return false;}
    var dx:Number=target.x-x;var dy:Number=target.y-y;
    // Do not push a resting body through a wall or floor to follow a recording.
    if(Math.abs(vx)<10.5)dx=0;if(Math.abs(vy)<10.5)dy=0;
    var error:Number=Math.sqrt(dx*dx+dy*dy);if(error<=0.5)return false;
    var amount:Number=Math.min(MAX_STEP,MAX_RATE*dt,error*(1-Math.exp(-4*dt)));var scale:Number=amount/error;
    var nx:Number=x+dx*scale;var ny:Number=y+dy*scale;
    motion.place(owner,nx,ny);previousPose={x:nx,y:ny,time:now};phase=Math.max(phase,target.t);count++;distance+=amount;lastStep=amount;return true;
   }catch(ignored:Error){skipped++;return false;}
  }
 }
}
