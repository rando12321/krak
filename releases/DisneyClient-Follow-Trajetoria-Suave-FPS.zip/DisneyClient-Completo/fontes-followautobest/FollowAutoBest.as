package disney {
 import flash.display.*;import flash.events.*;import flash.text.*;import flash.utils.*;
 public class FollowAutoBest {
  private static var instances:Dictionary=new Dictionary(true);
  private var root:MovieClip;private var motion:NativeMotion;private var replay:RoutePlayerNative;
  public var enabled:Boolean=false;public var message:String="AutoBest: desligado";public var targetName:String="";public var phase:String="observando";
  private var hasCheese:Boolean=false;private var targetId:int=-1;private var target:Object;private var traceRoute:Array=[];private var lastSample:int=0;private var started:Boolean=false;private var overflow:Boolean=false;
  private var activity:Object={};private var profiles:Object={};private var asked:Object={};private var pending:String="";private var pendingAt:int=0;private var nextQuery:int=0;private var queryPause:int=0;private var nextScan:int=0;
  private var code:String="";private var round:String="";private var map:Object;private var focused:Boolean=true;private var hud:TextField;private var replaySince:int=0;
  public function FollowAutoBest(value:MovieClip){root=value;motion=NativeMotion.get(value);replay=new RoutePlayerNative(value,true);}
  public static function attach(value:MovieClip):void{
   if(!value || !value.stage || instances[value])return;var a:FollowAutoBest=new FollowAutoBest(value);instances[value]=a;
   value.stage.addEventListener(KeyboardEvent.KEY_DOWN,a.keyDown,true,4000);value.stage.addEventListener(KeyboardEvent.KEY_DOWN,a.keyDown,false,4000);
   value.stage.addEventListener(Event.ENTER_FRAME,function(e:Event):void{a.tick();},false,-50);
   value.stage.addEventListener(Event.DEACTIVATE,function(e:Event):void{a.focused=false;a.replay.setFocused(false);});value.stage.addEventListener(Event.ACTIVATE,function(e:Event):void{a.focused=true;});
  }
  public static function receive(value:MovieClip,bytes:ByteArray):Boolean{
   var a:FollowAutoBest=instances[value] as FollowAutoBest;if(!a || !bytes)return false;var cursor:uint=bytes.position;
   var suppress:Boolean=false;try{bytes.position=0;suppress=a.packet(bytes);}catch(error:Error){if(a.enabled)a.status("AutoBest: pacote incompativel; aguardando dados nativos");}finally{bytes.position=cursor;}return suppress;
  }
  private function status(value:String):void{message=value;if(!root.stage)return;if(!hud){hud=new TextField();hud.name="astroAutoBestStatus";hud.defaultTextFormat=new TextFormat("_sans",11,0x90E9D6);hud.background=true;hud.backgroundColor=0x102438;hud.height=32;hud.wordWrap=true;hud.selectable=false;hud.mouseEnabled=false;root.stage.addChild(hud);}hud.width=Math.max(100,Math.min(740,root.stage.stageWidth-16));hud.x=8;hud.y=Math.max(44,root.stage.stageHeight-82);hud.text=value;}
  public function keyDown(e:KeyboardEvent):void{
   var f:TextField=root.stage.focus as TextField;if(e.keyCode!=13 || !f || f.type!=TextFieldType.INPUT)return;
   if(/^\s*\/(?:profile|perfil)(?:\s|$)/i.test(f.text)){queryPause=getTimer()+30000;pending="";return;}
   if(!/^\s*\/followautobest\s*$/i.test(f.text))return;
   f.text="";root.stage.focus=root.stage;toggle();e.preventDefault();e.stopImmediatePropagation();
  }
  public function toggle():void{
   enabled=!enabled;LocalServerLog.emit(root,"Follow AutoBest: "+(enabled?"ativado":"desativado"));cancelReplay();clearTarget();activity={};asked={};pending="";nextQuery=0;nextScan=0;map=null;code="";round="";
   if(enabled){root["auto_play"]=false;FollowControllerV13Shared.stopForRobot(root);status("AutoBest: ligado; aguardando jogadores ativos e perfis");}else status("AutoBest: desligado");
  }
  private function cancelReplay():void{replay.setManagedActive(false);}
  private function clearTarget():void{target=null;targetId=-1;targetName="";traceRoute=[];lastSample=0;started=false;overflow=false;hasCheese=false;phase="observando";}
  private function keys():Object{return root["Keys"];}
  private function game():Object{return root["tfm"];}
  private function local():Object{var k:Object=keys();var g:Object=game();return k && g ? g[k.player] : null;}
  private function list():Object{var k:Object=keys();var g:Object=game();return k && g && k.player_list ? g[k.player_list] : null;}
  private function nameOf(p:Object):String{var k:Object=keys();return p && k && k.player_name ? String(p[k.player_name]).toLowerCase() : "";}
  private function alive(p:Object):Boolean{var k:Object=keys();return p && p!==local() && k && k.is_dead && !p[k.is_dead] && (!k.player_clip || p[k.player_clip]) && (!(p is DisplayObject) || DisplayObject(p).parent!=null);}
  private function currentMap():String{
   var k:Object=keys();var m:Object=k && k.map_class && k.map_instance ? k.map_class[k.map_instance] : null;var n:Object=m && k.bot_map_code_object ? m[k.bot_map_code_object] : null;
   var v:Number=n && k.bot_map_code_value ? Number(n[k.bot_map_code_value]) : NaN;return isFinite(v)&&v>0&&v==Math.floor(v)?"@"+v.toFixed(0):"";
  }
  private function currentRound():String{return "current_round_code" in root ? String(root["current_round_code"]) : "";}
  private function requestProfile(nick:String,now:int):Boolean{
   var k:Object=keys();var st:Object=root["Statements"];if(!k || !(k.packet_out_class is Class) || !k.packet_out_bytes || !k.cipher || !st || !(st["send_packet"] is Function))return false;
   var cls:Class=k.packet_out_class as Class;var packet:Object=new cls(6,26);var data:ByteArray=packet[k.packet_out_bytes] as ByteArray;if(!data)return false;
   data.writeUTF("profile "+nick);packet[k.cipher]=true;pending=nick.toLowerCase();pendingAt=now;nextQuery=now+2000;asked[pending]=now;
   try{st["send_packet"](packet);return true;}catch(error:Error){pending="";return false;}
  }
  public static function parseProfile(bytes:ByteArray):Object{
   var nick:String=bytes.readUTF().toLowerCase();if(!/^[^\s#]+#\d{4}$/.test(nick))throw new Error("Invalid profile nickname");
   bytes.readInt();bytes.readInt();bytes.readUnsignedByte();bytes.readUnsignedByte();bytes.readUTF();bytes.readUTF();
   var stats:Array=[];for(var i:int=0;i<10;i++){var v:int=bytes.readInt();if(v<0)throw new Error("Invalid profile stats");stats.push(v);}return {name:nick,firsts:stats[2]};
  }
  public function packet(bytes:ByteArray,now:int=-1):Boolean{
   if(now<0)now=getTimer();if(bytes.bytesAvailable<2)return false;if(enabled && phase=="reproduzindo"){var pos:uint=bytes.position;bytes.position=0;try{replay.packet(bytes);}finally{bytes.position=pos;}}var c:int=bytes.readUnsignedByte();var cc:int=bytes.readUnsignedByte();
   if(c==8 && cc==16){var profile:Object=parseProfile(bytes);var own:Boolean=pending!="" && profile.name==pending && now-pendingAt<=10000;profiles[profile.name]={firsts:profile.firsts,time:now};if(own)pending="";return own;}
   if(!enabled)return false;
   if(c==5 && cc==2){cancelReplay();clearTarget();activity={};map=null;code="";return false;}
   var k:Object=keys();var g:Object=game();if(!k || !g)return false;
   if(c==144 && cc==2){bytes.readUTF();var born:int=bytes.readInt();if(born==targetId && phase=="observando"){traceRoute=[];started=false;overflow=false;hasCheese=false;lastSample=0;}if(local() && born==int(local()[k.player_id]) && phase=="aguardando renascer"){cancelReplay();clearTarget();}return false;}
   if(c==4 && cc==4){if(bytes.bytesAvailable<24)return false;var id:int=bytes.readInt();bytes.readInt();var sample:Object={mr:bytes.readBoolean(),ml:bytes.readBoolean(),x:bytes.readInt(),y:bytes.readInt(),vx:bytes.readShort(),vy:bytes.readShort(),jump:bytes.readBoolean(),frame:bytes.readByte()};
    var people:Object=list();var p:Object=people ? people[id] : null;if(!p || p===local())return false;
    activity[String(id)]={time:now,name:nameOf(p),sample:sample};
    if(id==targetId && p===target && phase=="observando")append(sample,"walk",now);return false;
   }
   if(c==144 && cc==6 && bytes.bytesAvailable>=4){var cheeseId:int=bytes.readInt();if(cheeseId==targetId && phase=="observando" && started)append(null,"cheese",now);return false;}
   if(c==8 && cc==6 && bytes.bytesAvailable>=5){bytes.readUnsignedByte();var won:int=bytes.readInt();
    if(local() && k.player_id && won==int(local()[k.player_id]) && phase=="reproduzindo"){cancelReplay();phase="aguardando renascer";status("AutoBest: toca local confirmada; aguardando renascer");return false;}
    if(won==targetId && phase=="observando" && started && !overflow){if(!hasCheese){traceRoute=[];started=false;status("AutoBest: percurso parcial sem queijo; aguardando nova tentativa");return false;}append(null,"hole",now);phase="pronto";status("AutoBest: percurso completo de "+targetName+"; preparando reproducao");}return false;
   }return false;
  }
  private function append(payload:Object,action:String,now:int):void{
   if(overflow)return;
   if(traceRoute.length>=10000){overflow=true;traceRoute=[];status("AutoBest: percurso muito longo; aguardando nova tentativa do alvo");return;}
   if(!started && action!="walk")return;
   if(action=="cheese")hasCheese=true;traceRoute.push([payload,action,started?Math.max(0,now-lastSample):0]);lastSample=now;started=true;
  }
  private function scan(now:int):void{
   var people:Object=list();if(!people)return;var currentValid:Boolean=target && alive(target) && people[targetId]===target && activity[String(targetId)] && now-activity[String(targetId)].time<15000;
   if(target && !currentValid && phase=="observando"){clearTarget();status("AutoBest: alvo saiu, morreu ou parou; procurando outro");}
   var best:Object=null;var bestId:int=-1;var bestFirsts:Number=-1;var query:String="";var population:int=0;
   for(var key:String in people){var p:Object=people[key];if(!alive(p))continue;var a:Object=activity[key];if(!a || a.name!=nameOf(p) || now-a.time>15000)continue;
    var name:String=nameOf(p);if(!/^[^\s#]+#\d{4}$/.test(name))continue;population++;
    var stat:Object=profiles[name];if(stat && now-stat.time<600000){var firsts:Number=Number(stat.firsts);if(firsts>bestFirsts || firsts==bestFirsts && (name==targetName || (!currentValid && (best==null || name<nameOf(best))))){best=p;bestId=int(key);bestFirsts=firsts;}}
    else if(query=="" && (!(name in asked) || now-Number(asked[name])>=60000))query=String(p[keys().player_name]);
   }
   if(pending!="" && now-pendingAt>10000)pending="";
   if(pending=="" && query!="" && now>=nextQuery && now>=queryPause){if(!requestProfile(query,now)){nextQuery=now+5000;status("AutoBest: consulta de perfil indisponivel nesta versao");}}
   if(phase!="observando")return;
   if(best && (!currentValid || (!profiles[targetName] || bestFirsts>Number(profiles[targetName].firsts)))){clearTarget();target=best;targetId=bestId;targetName=nameOf(best);var first:Object=activity[String(bestId)];append(first.sample,"walk",now);status("AutoBest: gravando "+targetName+" | "+bestFirsts+" firsts");}
   else if(!target)status(population ? "AutoBest: consultando firsts dos jogadores ativos" : "AutoBest: procurando movimentos de jogadores na sala");
   // Bound room metadata and old profiles. Never grow a permanent player log.
   for(var aid:String in activity)if(now-Number(activity[aid].time)>60000)delete activity[aid];
   for(var pname:String in profiles)if(now-Number(profiles[pname].time)>600000)delete profiles[pname];
   for(var askedName:String in asked)if(now-Number(asked[askedName])>600000)delete asked[askedName];
  }
  public function tick(now:int=-1):void{
   if(!enabled)return;if(now<0)now=getTimer();try{
    var current:String=currentMap();var token:String=currentRound();var k:Object=keys();var nextMap:Object=k && k.map_class ? k.map_class[k.map_instance] : null;
    if(current==""){cancelReplay();clearTarget();activity={};map=null;code="";status("AutoBest: aguardando mapa");return;}
    if(current!=code || token!=round || nextMap!==map){cancelReplay();clearTarget();activity={};code=current;round=token;map=nextMap;nextScan=0;}
    if(now>=nextScan){nextScan=now+500;scan(now);}
    var busy:Boolean=Boolean(root["auto_play"]) || motion.busyExcept(replay);var editing:Boolean=root.stage.focus is TextField && TextField(root.stage.focus).type==TextFieldType.INPUT;
    if(phase=="pronto"){
     if(busy || !focused || editing || motion.finished()){status("AutoBest: percurso pronto; aguardando rato livre");return;}
     var routes:Object={};routes[code]=traceRoute;replay.setWorldSpace(true);replay.setRoutes(routes);replay.setTiming(new RouteTiming(1,false));replay.setManagedActive(true);phase="reproduzindo";replaySince=now;
    }
    if(phase=="reproduzindo"){
     replay.setFocused(focused && !editing && !busy);replay.advanceFrame(now);status("AutoBest: "+targetName+" | "+replay.message);
     if(replay.message.indexOf("erro #2604")>=0){cancelReplay();clearTarget();status("AutoBest: queijo nao confirmado; procurando novo percurso");}
     else if(replay.message.indexOf("aguardando renascer para ressincronizar")>=0 || replay.message.indexOf("erro #")>=0 || replay.message.indexOf("pausado |")>=0){cancelReplay();clearTarget();status("AutoBest: inicio incompativel; aguardando outro percurso completo");}
     else if(motion.finished()){cancelReplay();phase="aguardando renascer";}
     else if(replay.message.indexOf("toca nao confirmada")>=0){cancelReplay();clearTarget();status("AutoBest: toca nao confirmada; procurando novo percurso");}
    }
   }catch(error:Error){cancelReplay();clearTarget();status("AutoBest: aguardando dados do jogo #"+error.errorID);}
  }
 }
}
